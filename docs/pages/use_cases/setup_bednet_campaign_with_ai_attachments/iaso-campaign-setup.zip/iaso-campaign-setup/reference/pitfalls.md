# Pitfalls learned on real campaigns

Each of these broke phones in the field at least once. Read them before changing anything
that is already in use.

## 1. Never remove a question from, or change a question's type in, a deployed entity reference form

The app stores entities in a local table whose column types are fixed when the first
entity is saved, and checks each entity against the form version that created it. If a
question disappears or changes type (select_one → calculate, select_one → select_multiple…),
opening an entity crashes the app (`NullPointerException: choice must not be null`),
**even for entities created afterwards**. A new form version does not repair entities
created with the bad version, and wiping app data is not reliable either.

Instead: keep the question and its type, and hide it (`relevant` = `false()`, note that
its value is then no longer saved) or make it read-only with a default. Removing a choice
from a list, adding questions, and changing labels, hints or constraints are safe.

## 2. Never remove a form from a project once phones used it

Phones that received submissions or entities for that form crash when they meet them.
Hide a form from users by other means (workflow conditions, a new project) instead.

## 3. The API replaces lists wholesale

`PATCH` on project `feature_flags`, org unit type `project_ids`, form `project_ids` and
entity type `fields_*` replaces the whole value. A payload with only the new item wipes
the others. Read, merge, write; or use the helpers of `scripts/iaso.py`.

## 4. `MOBILE_ENTITY_LIMITED_SEARCH` + `MOBILE_ENTITY_NO_CREATION` = "There are no entity types"

With both flags, the search button of the app opens an empty entity-type picker. For a
distribution-only app use `MOBILE_ENTITY_NO_CREATION` alone: the search opens the full list
of the entities the user downloaded (their area only), with a search bar, and no creation.

## 5. The household reference form must be in every project that works on households

The app downloads only the entities whose reference form belongs to its project. A
distribution app without the registration form shows no households.

## 6. An entity registered at an org unit level the app does not download blocks synchronisation

The sync fails at step "Entities" with `Entity[...] cannot be inserted because it has an
instance attached to an invalid OU [<id>]`, for every user whose area contains it. Give
each project all the levels where its entities can be registered (and those above), and
delete test entities registered at the wrong level.

## 7. Test data counts

Test households, test submissions and test users end up in the dashboards and payments.
Delete them (soft delete, audited) before launch: `DELETE /api/entities/<id>/`.

## 8. Workflow conditions only see entity values

They cannot depend on the user, the app or the org unit, except `_app_id` in app versions
that include it (3.0.5+). Comparisons are on strings (`"0"`, not `0`). A missing value is
`null`; an older app version that does not provide a value makes the condition false.

## 9. Fields hidden with `relevant = false()` are not saved

If a dashboard or a workflow needs the value, keep it visible, or compute it in a
`calculate` field, which is always saved.

## 10. Duplicate search: block only on unique codes

`prevent_add_if_duplicate_found = true` is right for a QR ticket, wrong for a name
(homonyms would block registration). The search only covers the entities already on the
phone, of the same entity type.

## 11. The QR value scanned on the search screen goes into the form field of the same name

That is why the household form has a read-only `qr_code` barcode field: the agent
cannot replace the scanned ticket. Read-only fields still receive the value.

## 12. Payment rules belong in one place

Rates, one-off allowances (e.g. transport paid once, not per day), caps on number of
days: agree them in writing before the campaign, and encode them in one place (the
payment page or export), not partly in forms.

## 13. Validate XLSForms with a known pyxform

Use pyxform 2.0.x with Python ≤ 3.12 (newer Python versions broke it): `scripts/validate_forms.sh`.

## 14. Project names that all start the same

Phones cut project names in lists. "Net campaign 2027 – Enumeration" and "Net campaign
2027 – Distribution" both show as "Net campaign 20…", and agents open the wrong app. Put the
word that differs first ("Enumeration – net campaign 2027"). Renaming a project later is safe
(`PATCH /api/projects/<id>/ {"name": "..."}`); phones show the new name after a synchronisation.

## 15. Users without the Entities permission

On a project with the `ENTITY` feature flag, a user without the `iaso_entities` permission
sees no households, groups or workers in the app, even with the right projects and org units.
Give it to every user of these projects (`user_permissions: ["iaso_entities"]`, or the
"Entities" box in the web interface; in the CSV user import, put `iaso_entities` in the `permissions` column).

## 16. Mobile app builds

An APK signed with your upload key cannot update a Play Store installation when Play App
Signing is on: distribute the "universal APK" downloaded from the Play Console instead.
Replacing a differently signed installation requires uninstalling, which loses unsent data.

## 17. Tokens

IASO API tokens are valid for years. Treat them like a password, use a dedicated user, and
deactivate that user (or change its permissions) when the setup is done.

## 18. Entity field labels: frozen on the phone

The entity screen shows the fields of `fields_detail_info_view` with the label of the
reference form's question, in the **form's default language** (`default_language`), not the
phone's. A field without a label (a `calculate`, for example) shows its raw name: give a
label to every field shown, `calculate` included (the kit's forms do).

The app stores these labels at the **first synchronisation** of the entity type and never
updates them: a new form version does not change the labels on phones already set up (their
app data must be cleared). Settle the labels and the default language before setting up the
field phones.
