# Rapports mobiles (feature flag `REPORTS`)

Un rapport mobile est une page HTML qui s'exécute **dans l'app IASO, hors ligne**, sur les
données stockées sur le téléphone : les propres soumissions de l'agent et tout ce que l'app
a téléchargé pour sa zone. Les chefs d'équipe et les superviseurs l'utilisent sur le
terrain sans réseau : avancement du jour, ménages à revisiter, solde de stock, présence de
leur équipe.

À ne pas confondre avec les pages web de `reference/pages.md`, qui s'exécutent dans un
navigateur sur les données du serveur. Une campagne a généralement besoin des deux.

Trois modèles sont fournis :

| Modèle | Pour le projet | Utilise |
|---|---|---|
| `templates/mobile_reports/campaign_progress/` | Dénombrement / Distribution | ménages dénombrés, servis, MII, absents/en refus, routine, aujourd'hui ou toute la campagne, par formation sanitaire ; carte des ménages avec les noms des lieux (MapLibre GL, dans le zip) |
| `templates/mobile_reports/attendance/` | Travailleurs et présence | travailleurs (formulaire 08) et présences (09) : statut du jour (validé, à valider, pas encore saisi, n'a pas travaillé), journées déclarées et validées sur la campagne |
| `templates/mobile_reports/stock/` | Stock | solde sur le téléphone, totaux par mouvement, derniers mouvements |

Quel rapport pour quelle application, avec ou sans carte : décidez-le avec l'utilisateur au
début (`SKILL.md` § 2b).

## Fonctionnement dans l'app

1. Le projet a le feature flag **`REPORTS`**. L'app affiche alors un bouton **Report**
   (Rapport) sur son écran d'accueil (et sur l'écran des entités).
2. Lors de la synchronisation, à l'étape "Reports", l'app télécharge le rapport de son
   projet (`GET /api/mobile/reports/?app_id=...`). **Un seul rapport par projet** : IASO
   garde un rapport par projet, avec ses versions, et sert sa version publiée. Pour
   proposer deux rapports, utilisez deux projets, ou un seul rapport avec des onglets.
3. Le fichier est un **zip avec `index.html` à sa racine**. L'app reconnaît le zip à son
   type de contenu `application/zip` ; IASO enregistre chaque fichier téléversé avec un nom
   en `.zip` pour qu'il soit servi avec ce type.
   Il est décompressé sur le téléphone et ouvert à l'adresse `https://appassets.androidplatform.net/reports/index.html`,
   de sorte que les liens relatifs vers les fichiers du zip (`app.js`, `style.css`, `leaflet.js`…) fonctionnent.
4. Avant de l'ouvrir, l'app construit pour le rapport un cache de toutes les soumissions
   présentes sur le téléphone (barre de progression "Generating cache"). Sur un téléphone
   contenant des milliers de soumissions, la première ouverture prend du temps.
5. **Pas d'internet** : tout ce qui est chargé depuis un CDN manquera sur le terrain. Mettez
   chaque bibliothèque et chaque police dans le zip. Pour les cartes, voir « Cartes » plus bas.
6. Le bouton **Print** (Imprimer) imprime la page (impression Android, ou imprimante de
   reçus Bluetooth sur les appareils compatibles).

## Le pont JavaScript : `window.Android`

Toutes les méthodes renvoient une **chaîne JSON** (à parser), ou `null`. Appelez-les de
manière synchrone, comme le font les rapports existants, sauf si les données sont
volumineuses (voir "Appels asynchrones").

| Appel | Renvoie |
|---|---|
| `Android.loadForms()` | toutes les soumissions présentes sur le téléphone pour ce projet, sous forme de tableau d'éléments (ci-dessous) |
| `Android.loadFormsForForms("form_a,form_b")` | idem, uniquement ces formulaires — **`form_id`s XLSForm**, pas les identifiants numériques IASO, pour que le rapport fonctionne dans n'importe quel compte |
| `Android.loadFormsForOrgUnits("12,34")` | idem, uniquement ces unités d'organisation (identifiants ou noms) |
| `Android.loadFormsForEntityTypes("Household")` | idem, uniquement les soumissions liées à des entités de ces types (nom ou code) |
| `Android.loadFormsForSources("local")` | idem, par source : `local` (faites sur ce téléphone), `imported` (téléchargées), `transferred` |
| `Android.loadForms(orgUnits, entityTypes, startDate, endDate, forms, sources, callback)` | tous les filtres à la fois ; passez `null` pour ceux qui ne servent pas ; dates au format `YYYY-MM-DD` (sur la date de création/mise à jour) |
| `Android.currentOrgUnit()` | `{id, name, type_id, type_name}` — l'unité d'organisation sélectionnée par l'utilisateur dans l'app |
| `Android.currentUser()` | `{id, user_name, email, phone_number, organization, org_units: [{id, name, type_id, type_name}]}` |
| `Android.info()` | `{app_id, is_debug, version, version_name}` |
| `Android.getStockValueAt("YYYY-MM-DD", "<orgUnitId>", "SKU A,SKU B")` | `{"<SKU name>": value}` au **début** de ce jour (passez la date de demain pour "maintenant") ; SKU facultatifs |
| `Android.loadStockLedgerItems(orgUnits, skus, forms, startDate, endDate)` | mouvements de stock : `[{id, questionName, submissionId, orgUnitId, parentOrgUnitId, periodId, periodName, formName, formId, value, impact, synced, createdAt, createdBy}]`, `impact` = `ADD`, `SUBTRACT` ou `RESET` |

Un élément de soumission renvoyé par `loadForms` :

```json
{
  "id": "uuid of the submission", "entityId": "uuid of the entity or empty",
  "entityTypeId": "...", "entityTypeName": "Household",
  "formId": "IASO form id", "formFormId": "household_registration", "formName": "Household registration",
  "formVersionId": "...", "createdAt": 1729000000000, "updatedAt": 1729000000000,
  "orgUnitId": "123", "orgUnitName": "Health facility A", "parentOrgUnitId": "45",
  "periodId": null, "periodName": null, "source": "local",
  "values": { "head_name": "...", "nets_needed": "3", "registration_date": 1729000000000 }
}
```

Formats des valeurs dans `values`, selon le type de question :

- `select_one` : le **code** du choix (`"absent"`), pas le libellé ; `select_multiple` : un tableau de codes ;
- `date`, `dateTime` : un horodatage en millisecondes ; `time` : des secondes depuis minuit ;
- `integer` / `decimal` : des nombres ; `calculate` et `text` : des chaînes — convertissez avec `Number()` ;
- `geopoint` : une chaîne `"latitude longitude altitude précision"` ;
- groupes répétés : une chaîne, inutilisable telle quelle ;
- la position GPS de la soumission (feature flag `TAKE_GPS_ON_FORM`) est dans `latitude` et
  `longitude` au niveau de l'élément, **seulement pour les soumissions faites sur ce
  téléphone**. Pour une carte, préférez une question `geopoint` (`household_gps` dans les
  formulaires du kit).

Les soumissions **téléchargées** (entités de la zone, synchronisées depuis le serveur) n'ont
pas tout à fait le même format : `createdAt` et `updatedAt` sont du texte
(`"2027-03-14 08:12:00"`, en UTC), les questions `date` aussi (`"2027-03-14"`), et il n'y a
ni `latitude`/`longitude` ni `parentOrgUnitId`. Les modèles acceptent les deux formats de date
(fonction `dayOf`).

Reliez les formulaires avec `entityId` : une distribution et son ménage le partagent.

### Bouton Retour

L'app appelle `document.onBack()` lorsque l'utilisateur appuie sur Retour. Renvoyez `true`
pour rester dans le rapport (par ex. fermer une vue détaillée) ; toute autre valeur le ferme :

```js
document.onBack = function () { if (detailOpen) { closeDetail(); return true; } return false; };
```

### Appels asynchrones

Avec un argument `callback`, la méthode rend la main immédiatement et le résultat arrive
sous forme de message :

```js
window.addEventListener("message", function (e) {
  var msg = typeof e.data === "string" ? JSON.parse(e.data) : e.data;   // {"id": "<callback>", "data": [...]}
  if (msg.id === "households") show(msg.data);
});
Android.loadForms(null, null, null, null, "household_registration", null, "households");
```

Un seul appel asynchrone à `loadForms` peut s'exécuter à la fois. Les appels synchrones
sont plus simples et conviennent pour quelques milliers de soumissions.

## Cartes

Les utilisateurs s'attendent souvent à une carte des ménages, avec le nom des lieux. Le modèle
`campaign_progress` en a une (réglages `MAP` dans sa configuration) ; reprenez ses choix pour
toute autre carte :

- **MapLibre GL dans le zip** (`maplibre-gl.js`, `maplibre-gl.css`, licence BSD à côté) ; les
  ménages sont une couche de cercles, sans image ni police à télécharger.
- **Les noms des lieux sont dessinés par le rapport**, à partir des données (le nom de l'unité
  d'organisation au-dessus de ses ménages), pas lus dans le fond de carte : ils restent
  visibles hors ligne et nomment les lieux de la campagne, que le fond de carte ignore souvent.
- **Fond de carte : le serveur de tuiles de Bluesquare, `https://martin.bluesquare.org`**
  (fond vectoriel Protomaps tiré d'OpenStreetMap). Styles :
  `https://martin.bluesquare.org/styles/<light|dark|white|grayscale|black>.json`. Il est chargé
  quand le téléphone a du réseau ; sans réseau, le rapport l'indique et garde les ménages et
  les noms sur un fond uni. Testé dans l'application.
- **Pas le serveur de staging, ni un autre serveur de tuiles sans vérification.** Le rapport
  tourne à l'origine `https://appassets.androidplatform.net` : le style, les sprites, les
  polices (glyphs) et les tuiles vectorielles sont chargés par `fetch` et exigent chacun un
  en-tête CORS qui autorise cette origine. `martin.bluesquare.org` les envoie tous ; ailleurs,
  chacun peut échouer séparément, et la carte reste blanche alors que les tuiles existent et
  s'affichent dans un navigateur. Pour vérifier un serveur :
  `curl -sI -H "Origin: https://appassets.androidplatform.net" <url>` sur le style, le sprite,
  une police et une tuile doit renvoyer `Access-Control-Allow-Origin`.
- **Pour un usage entièrement hors ligne**, un fond de carte doit être dans le zip (par
  exemple des tuiles raster de la zone, petites zones seulement : limite de 100 Mo), ou
  renoncez au fond : les points et les noms des lieux suffisent souvent aux chefs d'équipe.
- **Testez sur un vrai téléphone**, avec du réseau puis en mode avion : un navigateur de
  bureau ne reproduit ni l'origine ni le cache de la WebView.

## Développer et tester

1. Copiez un dossier de modèle et adaptez-le. Gardez la logique en JavaScript simple qui
   s'exécute dans une WebView Android (aucune étape de build nécessaire) ; gardez la page
   légère et lisible sur un petit écran, dans la ou les langues de la campagne.
2. Conservez le **repli sur des données de démonstration** des modèles : sans
   `window.Android`, le rapport affiche des éléments fictifs, ce qui permet de le vérifier
   dans un navigateur de bureau :
   ```bash
   python3 -m http.server 8000 --directory templates/mobile_reports/campaign_progress
   ```
   puis ouvrez `http://localhost:8000/` (utilisez la largeur téléphone des outils de
   développement du navigateur).
3. Faites ressembler les éléments fictifs aux vrais : même `formFormId`, mêmes clés
   `values` et mêmes formats de valeurs que ci-dessus.
4. Empaquetez-le : `scripts/build_mobile_report.sh <folder> report.zip` (avertit en cas de
   fichiers chargés depuis internet).
5. Testez sur un téléphone après publication (ci-dessous) : synchronisez, ouvrez Report,
   comparez avec les soumissions présentes sur le téléphone.

## Publier

Publiez avec l'API d'IASO, par `scripts/iaso.py`. Il faut un serveur IASO qui a l'API de
téléversement des rapports mobiles (la première version d'IASO publiée après le 28 octobre 2026, BLSQ/iaso#3471) et un utilisateur avec la permission
*Rapports* (`iaso_reports`) :

```bash
python3 scripts/iaso.py mobile-report-upload <app_id> report.zip --name "Avancement de la campagne" --version "v1"
```

- Le premier téléversement crée le rapport du projet et publie cette version. Les suivants
  ajoutent une version au même rapport et la publient (`--no-publish` pour la téléverser
  sans changer ce que reçoivent les téléphones). Par défaut, `--version` vaut la date et
  l'heure.
- IASO refuse un fichier qui n'est pas un zip, un zip sans `index.html` à sa racine
  (souvent un zip du dossier au lieu de son contenu : utilisez
  `scripts/build_mobile_report.sh`), ou un zip de plus de 100 Mo.
- Listez les versions, et revenez à une version précédente si la nouvelle pose problème :
  ```bash
  python3 scripts/iaso.py mobile-report-versions <app_id>
  python3 scripts/iaso.py mobile-report-publish <app_id> <version_id>
  ```
- La même chose est possible dans l'interface web d'IASO : *Admin > Projets*, modifiez le
  projet, onglet **Rapport mobile** (rapport actuel, versions, téléversement, publication).

Les téléphones reçoivent la version publiée à leur synchronisation suivante. Vérifiez ce
qu'ils vont télécharger : `python3 scripts/iaso.py get "/api/mobile/reports/?app_id=<app_id>"`
(nom, version, URL du fichier). Seule une version publiée est servie.

Ajoutez ensuite le feature flag `REPORTS` au projet (la commande de téléversement prévient
s'il manque) : `python3 scripts/iaso.py feature-flags <project_id> --add REPORTS`.
Pour retirer le rapport, retirez ce flag.

### Serveurs IASO plus anciens

Sur un serveur sans l'API de téléversement, `mobile-report-upload` s'arrête et le signale.
Le rapport se publie alors dans l'**admin Django** d'IASO, que seul le personnel de
Bluesquare peut ouvrir : envoyez-leur le zip, le projet (`app_id`) et le nom du rapport. Ils
ajoutent une **Report version** (`/admin/iaso/reportversion/add/` : nom, le zip, statut
`published`), puis un **Report** (`/admin/iaso/report/add/` : nom, projet, cette version
comme version publiée). Sur ces serveurs, l'app reçoit la version publiée du rapport quel
que soit son statut, et le premier rapport si un projet en a plusieurs.
