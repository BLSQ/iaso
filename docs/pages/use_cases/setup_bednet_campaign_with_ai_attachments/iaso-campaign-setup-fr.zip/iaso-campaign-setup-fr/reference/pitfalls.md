# Pièges rencontrés sur de vraies campagnes

Chacun de ces pièges a déjà fait planter des téléphones sur le terrain au moins une fois.
Lisez-les avant de modifier quoi que ce soit qui est déjà en service.

## 1. Ne jamais supprimer une question d'un formulaire de référence d'entité déployé, ni changer son type

L'app stocke les entités dans une table locale dont les types de colonnes sont figés à
l'enregistrement de la première entité, et vérifie chaque entité par rapport à la version
de formulaire qui l'a créée. Si une question disparaît ou change de type (select_one →
calculate, select_one → select_multiple…), l'ouverture d'une entité fait planter l'app
(`NullPointerException: choice must not be null`), **même pour les entités créées
ensuite**. Une nouvelle version du formulaire ne répare pas les entités créées avec la
mauvaise version, et effacer les données de l'app n'est pas fiable non plus.

À la place : gardez la question et son type, et masquez-la (`relevant` = `false()` ; notez
que sa valeur n'est alors plus enregistrée) ou rendez-la en lecture seule avec une valeur
par défaut. Supprimer un choix d'une liste, ajouter des questions, et modifier des libellés,
des indications ou des contraintes sont des opérations sans risque.

## 2. Ne jamais retirer un formulaire d'un projet une fois que des téléphones l'ont utilisé

Les téléphones qui ont reçu des soumissions ou des entités de ce formulaire plantent
lorsqu'ils les rencontrent. Masquez plutôt le formulaire aux utilisateurs par d'autres
moyens (conditions de workflow, nouveau projet).

## 3. L'API remplace les listes en entier

Un `PATCH` sur les `feature_flags` d'un projet, les `project_ids` d'un type d'unité
d'organisation, les `project_ids` d'un formulaire et les `fields_*` d'un type d'entité
remplace la valeur entière. Un payload ne contenant que le nouvel élément efface les
autres. Lisez, fusionnez, écrivez ; ou utilisez les fonctions utilitaires de `scripts/iaso.py`.

## 4. `MOBILE_ENTITY_LIMITED_SEARCH` + `MOBILE_ENTITY_NO_CREATION` = "There are no entity types"

Avec ces deux flags, le bouton de recherche de l'app ouvre un sélecteur de types d'entité
vide. Pour une app de distribution seule, utilisez `MOBILE_ENTITY_NO_CREATION` seul : la
recherche ouvre la liste complète des entités téléchargées par l'utilisateur (sa zone
uniquement), avec une barre de recherche, et sans création.

## 5. Le formulaire de référence des ménages doit être dans chaque projet qui travaille sur les ménages

L'app ne télécharge que les entités dont le formulaire de référence appartient à son
projet. Une app de distribution sans le formulaire d'enregistrement n'affiche aucun ménage.

## 6. Une entité enregistrée à un niveau d'unité d'organisation que l'app ne télécharge pas bloque la synchronisation

La synchronisation échoue à l'étape "Entities" avec `Entity[...] cannot be inserted because it has an
instance attached to an invalid OU [<id>]`, pour chaque utilisateur dont la zone la
contient. Donnez à chaque projet tous les niveaux où ses entités peuvent être enregistrées
(et ceux au-dessus), et supprimez les entités de test enregistrées au mauvais niveau.

## 7. Les données de test comptent

Les ménages de test, les soumissions de test et les utilisateurs de test se retrouvent
dans les tableaux de bord et les paiements. Supprimez-les (suppression logique, tracée)
avant le lancement : `DELETE /api/entities/<id>/`.

## 8. Les conditions de workflow ne voient que les valeurs de l'entité

Elles ne peuvent pas dépendre de l'utilisateur, de l'app ou de l'unité d'organisation,
sauf `_app_id` dans les versions de l'app qui l'incluent (3.0.5+). Les comparaisons se
font sur des chaînes (`"0"`, pas `0`). Une valeur manquante vaut `null` ; une ancienne
version de l'app qui ne fournit pas une valeur rend la condition fausse.

## 9. Les champs masqués avec `relevant = false()` ne sont pas enregistrés

Si un tableau de bord ou un workflow a besoin de la valeur, laissez le champ visible, ou
calculez-la dans un champ `calculate`, qui est toujours enregistré.

## 10. Recherche de doublons : ne bloquer que sur des codes uniques

`prevent_add_if_duplicate_found = true` convient pour un ticket QR, pas pour un nom
(les homonymes bloqueraient l'enregistrement). La recherche ne porte que sur les entités
déjà présentes sur le téléphone, du même type d'entité.

## 11. La valeur QR scannée sur l'écran de recherche va dans le champ du formulaire portant le même nom

C'est pourquoi le formulaire ménage a un champ code-barres `qr_code` en lecture seule :
l'agent ne peut pas remplacer le ticket scanné. Les champs en lecture seule reçoivent
quand même la valeur.

## 12. Les règles de paiement doivent être à un seul endroit

Taux, indemnités ponctuelles (par ex. transport payé une seule fois, pas par jour),
plafonds de nombre de jours : convenez-en par écrit avant la campagne, et encodez-les à un
seul endroit (la page de paiement ou l'export), pas en partie dans les formulaires.

## 13. Valider les XLSForms avec une version connue de pyxform

Utilisez pyxform 2.0.x avec Python ≤ 3.12 (les versions plus récentes de Python l'ont cassé) : `scripts/validate_forms.sh`.

## 14. Des noms de projets qui commencent tous pareil

Les téléphones tronquent les noms de projets dans les listes. « Campagne MII 2027 – Dénombrement » et
« Campagne MII 2027 – Distribution » s'affichent tous deux « Campagne MII 20… », et les agents ouvrent
la mauvaise application. Mettez en premier le mot qui change (« Dénombrement – campagne MII 2027 »).
Renommer un projet plus tard est sans risque (`PATCH /api/projects/<id>/ {"name": "..."}`) ; les
téléphones affichent le nouveau nom après une synchronisation.

## 15. Des utilisateurs sans la permission Entités

Sur un projet qui a le feature flag `ENTITY`, un utilisateur sans la permission `iaso_entities`
ne voit ni ménage, ni groupement, ni travailleur dans l'application, même avec les bons projets et
les bonnes unités d'organisation. Donnez-la à tous les utilisateurs de ces projets
(`user_permissions: ["iaso_entities"]`, ou la case « Entities » / « Entités » dans l'interface web ;
dans l'import CSV des utilisateurs, mettez `iaso_entities` dans la colonne `permissions`).

## 16. Builds de l'application mobile

Un APK signé avec votre clé d'importation (upload key) ne peut pas mettre à jour une
installation Play Store quand Play App Signing est activé : distribuez plutôt
l'"universal APK" téléchargé depuis la Play Console. Remplacer une installation signée
différemment impose de la désinstaller, ce qui fait perdre les données non envoyées.

## 17. Jetons (tokens)

Les jetons d'API IASO sont valables des années. Traitez-les comme un mot de passe,
utilisez un utilisateur dédié, et désactivez cet utilisateur (ou changez ses permissions)
une fois la configuration terminée.

## 18. Libellés des champs d'une entité : figés sur le téléphone

L'écran d'une entité affiche les champs de `fields_detail_info_view` avec le libellé de la
question du formulaire de référence, dans la **langue par défaut du formulaire**
(`default_language`), pas dans celle du téléphone. Un champ sans libellé (un `calculate`
par exemple) s'affiche sous son nom brut : donnez un libellé à chaque champ affiché,
`calculate` compris (les formulaires du kit le font).

L'application enregistre ces libellés à la **première synchronisation** du type d'entité et
ne les met plus à jour : une nouvelle version du formulaire ne change pas les libellés sur
les téléphones déjà configurés (il faut effacer les données de l'application). Choisissez
les libellés et la langue par défaut avant de configurer les téléphones de terrain.
