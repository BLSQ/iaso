# Reports: web pages in IASO

IASO can host web pages for the campaign team: dashboards, attendance and payment
sheets, lists to print. A page is served at `<IASO_URL>/pages/<slug>/`, only to logged-in
users you choose, and reads the data with **their own IASO permissions**. A starting
dashboard is in `templates/pages/campaign_dashboard.html`.

## How a page works

- **Type `RAW`**: the page is one HTML file stored in IASO (`content`). Other types exist:
  `IFRAME` (embeds an external URL), `TEXT`, `POWERBI`, `SUPERSET`.
- **No token in the page.** It is served by IASO on the same domain as the API, so its
  `fetch('/api/...', {credentials: 'include'})` calls carry the session cookie of the
  logged-in user. Each viewer sees only the org units and forms they have access to.
- **Data source**: every form's submissions as a Parquet file,
  `GET /api/instances/?form_ids=<id>&parquet=true`. Columns:
  - one column per form field, by field name (groups are flattened: `people_count`, not
    `registration/people_count`); repeat groups are not expanded;
  - metadata prefixed with `iaso_subm_`: `iaso_subm_id`, `iaso_subm_org_unit_id`,
    `iaso_subm_org_unit_name`, `iaso_subm_entity_id`, `iaso_subm_created_by_username`,
    `iaso_subm_source_created_at`, `iaso_subm_latitude`, `iaso_subm_longitude`…
- **Pyramid**: `GET /api/orgunits/?parquet=true&order=id` with columns `org_unit_id`,
  `org_unit_name`, `org_unit_type_name`, `org_unit_parent_id`. Walk up the parents to group
  submissions by region, district or facility. Shapes for maps:
  add `extra_fields=simplified_geom_geojson` and filter by type with
  `searches=[{"orgUnitTypeId":"<id>"}]`.
- **Reading Parquet in the browser**: `hyparquet` and `hyparquet-compressors` from jsDelivr,
  as in the template (pin the versions).
- **Linking forms**: a distribution and the household it serves share
  `iaso_subm_entity_id`; follow-ups of a worker (attendance) share the worker's entity id.

## Build a page

1. Copy `templates/pages/campaign_dashboard.html` and set its `CONFIG` block: the form ids
   created during the setup, the title, the org unit type names to group by.
2. If you change the indicators, keep the field names of the forms (see `forms/README.md`).
   A field hidden with `relevant = false()` is not saved and will be empty here.
3. Preview it locally with the real data:
   ```bash
   python3 scripts/serve_page.py my_dashboard.html
   ```
   then open `http://localhost:8770/`. The script serves the page and relays the API calls
   with the token of `iaso_config.txt`, so the page runs exactly as it will in IASO, and only reads.
   Check the browser console for errors, and compare a few totals with the IASO web
   interface (Forms → submissions).
4. Check light and dark mode, and a phone-width window: supervisors open it on phones.

## Publish

```bash
python3 scripts/iaso.py post /api/pages/ pages_payload.json
```

with `pages_payload.json`:

```json
{
  "name": "Campaign dashboard",
  "slug": "campaign-dashboard",
  "type": "RAW",
  "needs_authentication": true,
  "content": "<the whole HTML file as one JSON string>",
  "users": [<user ids allowed to open it>]
}
```

Building that JSON by hand is error-prone: let Claude read the HTML file and send it
(`json.dumps` of the file content).

- Who can open it: the users listed in `users` (**user ids**, `user_id` in
  `GET /api/profiles/`, not profile ids), the members of the roles listed in `user_roles`,
  and everyone in the account with the `iaso_page_write` permission. Others are sent to the
  login page.
- Publishing needs the `iaso_page_write` permission and the account module **Embedded links**
  (`EMBEDDED_LINKS` in `scripts/iaso.py whoami`).
- Update: read the page first (`GET /api/pages/<id>/`) and check `updated_at` and `content`
  did not change since you downloaded it — someone may have edited it in the web interface —
  then `PATCH /api/pages/<id>/ {"content": "..."}`. Keep the previous content as a backup file.
- The page appears in the web interface under **Pages** and at `<IASO_URL>/pages/<slug>/`.

## Typical campaign pages

| Page | Reads | Shows |
|---|---|---|
| Campaign dashboard (template provided) | 01, 02, 03, 05 | Enumeration and distribution progress by area, coverage, refusal rate |
| Special groups | 06, 07 | Groups planned / served, nets |
| Stock | 10–14 (and 02) | Received, issued, returned, lost, balance by store |
| Attendance and payment (template provided: `attendance_payment.html`) | 08, 09 | Days worked and validated per worker, amount due per role (rates, one-off allowances, mobile money fees), Excel export for payment |
| Supervision | 15 | Checklist results by area, corrective actions |

For payments, agree the rules in writing first (daily rate per role, allowances paid
once, maximum number of days, fees). In `attendance_payment.html` they all sit in the
`CONFIG` block at the top of the page, so finance can check them, and the Excel payment
sheet recomputes the amounts from its "Rates" and "Mobile money fees" sheets when
someone corrects a rate there. The one-off allowance is paid in the sheet whose period
contains the worker's first validated day, never twice.

## Reports in the mobile app

Reports that run offline on the phone (feature flag `REPORTS`) work differently: see
`reference/mobile-reports.md`.
