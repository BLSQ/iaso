# Mobile reports (feature flag `REPORTS`)

A mobile report is an HTML page that runs **inside the IASO app, offline**, on the data
stored on the phone: the agent's own submissions and everything the app downloaded for
their area. Team leaders and supervisors use it in the field without network: today's
progress, households to revisit, stock balance, attendance of their team.

Different from the web pages of `reference/pages.md`, which run in a browser on the
server's data. A campaign usually needs both.

Three templates are provided:

| Template | For project | Uses |
|---|---|---|
| `templates/mobile_reports/campaign_progress/` | Enumeration / Distribution | households enumerated, served, nets, absent/refused, routine, today or whole campaign, by facility; map of households with place names (MapLibre GL, in the zip) |
| `templates/mobile_reports/attendance/` | Workers & attendance | workers (form 08) and attendance (09): status of the day (validated, to validate, not recorded yet, did not work), days declared and validated over the campaign |
| `templates/mobile_reports/stock/` | Stock | balance on the phone, totals by movement, last movements |

Which report for which app, with or without a map: decide it with the user at the start
(`SKILL.md` § 2b).

## How it works in the app

1. The project has the feature flag **`REPORTS`**. The app then shows a **Report** button
   on its home screen (and on the entities screen).
2. At synchronisation, step "Reports", the app downloads the report of its project
   (`GET /api/mobile/reports/?app_id=...`). **Only one report per project**: IASO keeps
   one report per project, with its versions, and serves its published version. To offer
   two reports, use two projects, or one report with tabs.
3. The file is a **zip with `index.html` at its root**. The app recognises the zip by its
   content type `application/zip`; IASO stores every upload with a `.zip` name so it is
   served with that type.
   It is unzipped on the phone and opened at `https://appassets.androidplatform.net/reports/index.html`,
   so relative links to files in the zip (`app.js`, `style.css`, `leaflet.js`…) work.
4. Before opening it, the app builds a cache of all submissions on the phone for the
   report (progress bar "Generating cache"). On a phone with thousands of submissions the
   first opening takes a while.
5. **No internet**: anything loaded from a CDN will be missing in the field. Put every
   library and font in the zip. For maps, see "Maps" below.
6. The **Print** button prints the page (Android print, or a Bluetooth receipt printer on
   supported devices).

## The JavaScript bridge: `window.Android`

All methods return a **JSON string** (parse it), or `null`. Call them synchronously, as
the existing reports do, unless the data is large (see "Asynchronous calls").

| Call | Returns |
|---|---|
| `Android.loadForms()` | every submission on the phone for this project, as an array of items (below) |
| `Android.loadFormsForForms("form_a,form_b")` | same, only these forms — **XLSForm `form_id`s**, not IASO numeric ids, so the report works in any account |
| `Android.loadFormsForOrgUnits("12,34")` | same, only these org units (ids or names) |
| `Android.loadFormsForEntityTypes("Household")` | same, only submissions linked to entities of these types (name or code) |
| `Android.loadFormsForSources("local")` | same, by source: `local` (made on this phone), `imported` (downloaded), `transferred` |
| `Android.loadForms(orgUnits, entityTypes, startDate, endDate, forms, sources, callback)` | all filters at once; pass `null` for unused ones; dates `YYYY-MM-DD` (on created/updated date) |
| `Android.currentOrgUnit()` | `{id, name, type_id, type_name}` — the org unit the user selected in the app |
| `Android.currentUser()` | `{id, user_name, email, phone_number, organization, org_units: [{id, name, type_id, type_name}]}` |
| `Android.info()` | `{app_id, is_debug, version, version_name}` |
| `Android.getStockValueAt("YYYY-MM-DD", "<orgUnitId>", "SKU A,SKU B")` | `{"<SKU name>": value}` at the **start** of that day (pass tomorrow for "now"); SKUs optional |
| `Android.loadStockLedgerItems(orgUnits, skus, forms, startDate, endDate)` | stock movements: `[{id, questionName, submissionId, orgUnitId, parentOrgUnitId, periodId, periodName, formName, formId, value, impact, synced, createdAt, createdBy}]`, `impact` = `ADD`, `SUBTRACT` or `RESET` |

A submission item returned by `loadForms`:

```json
{
  "id": "uuid of the submission", "entityId": "uuid of the entity or empty",
  "entityTypeId": "...", "entityTypeName": "Household",
  "formId": "IASO form id", "formFormId": "household_registration", "formName": "Household registration",
  "formVersionId": "...", "createdAt": 1729000000000, "updatedAt": 1729000000000,
  "orgUnitId": "123", "orgUnitName": "Health facility A", "parentOrgUnitId": "45",
  "periodId": null, "periodName": null, "source": "local",
  "values": { "head_name": "...", "nets_needed": "3", "registration_date": 1729000000000 }
}
```

Value formats in `values`, by question type:

- `select_one`: the choice **code** (`"absent"`), not the label; `select_multiple`: an array of codes;
- `date`, `dateTime`: a timestamp in milliseconds; `time`: seconds since midnight;
- `integer` / `decimal`: numbers; `calculate` and `text`: strings — convert with `Number()`;
- `geopoint`: a string `"latitude longitude altitude accuracy"`;
- repeat groups: a string, not usable as such;
- the GPS position of the submission (feature flag `TAKE_GPS_ON_FORM`) is in `latitude` and
  `longitude` at the item level, **only for submissions made on this phone**. For a map,
  prefer a `geopoint` question (`household_gps` in the kit's forms).

**Downloaded** submissions (entities of the area, synchronised from the server) do not have
quite the same format: `createdAt` and `updatedAt` are text (`"2027-03-14 08:12:00"`, in UTC),
so are `date` questions (`"2027-03-14"`), and there is no `latitude`/`longitude` nor
`parentOrgUnitId`. The templates accept both date formats (function `dayOf`).

Link forms with `entityId`: a distribution and its household share it.

### Back button

The app calls `document.onBack()` when the user presses Back. Return `true` to stay in the
report (e.g. close a detail view), anything else closes it:

```js
document.onBack = function () { if (detailOpen) { closeDetail(); return true; } return false; };
```

### Asynchronous calls

With a `callback` argument, the method returns immediately and the result arrives as a
message:

```js
window.addEventListener("message", function (e) {
  var msg = typeof e.data === "string" ? JSON.parse(e.data) : e.data;   // {"id": "<callback>", "data": [...]}
  if (msg.id === "households") show(msg.data);
});
Android.loadForms(null, null, null, null, "household_registration", null, "households");
```

Only one asynchronous `loadForms` call can run at a time. Synchronous calls are simpler
and fine for a few thousand submissions.

## Maps

Users often expect a map of the households, with the place names. The `campaign_progress`
template has one (`MAP` settings in its config); reuse its choices for any other map:

- **MapLibre GL in the zip** (`maplibre-gl.js`, `maplibre-gl.css`, BSD licence next to them);
  the households are a circle layer, with no image or font to download.
- **Place names are drawn by the report**, from the data (the org unit name above its
  households), not read from the base map: they stay visible offline and name the campaign's
  places, which the base map often does not know.
- **Base map: Bluesquare's tile server, `https://martin.bluesquare.org`** (Protomaps vector
  base map from OpenStreetMap). Styles:
  `https://martin.bluesquare.org/styles/<light|dark|white|grayscale|black>.json`. It is loaded
  when the phone has a network; without network, the report says so and keeps the households
  and the names on a plain background. Tested in the app.
- **Not the staging server, nor another tile server without checking.** The report runs at the
  origin `https://appassets.androidplatform.net`: the style, the sprites, the fonts (glyphs)
  and the vector tiles are loaded with `fetch` and each needs a CORS header allowing that
  origin. `martin.bluesquare.org` sends them all; elsewhere each can fail separately, and the
  map stays blank while the tiles exist and show in a browser. To check a server:
  `curl -sI -H "Origin: https://appassets.androidplatform.net" <url>` on the style, the
  sprite, a font and a tile must return `Access-Control-Allow-Origin`.
- **For fully offline use**, a base map must be in the zip (for instance raster tiles of the
  area, small areas only: 100 MB limit), or do without: the points and the place names are
  often enough for team leaders.
- **Test on a real phone**, with network then in airplane mode: a desktop browser reproduces
  neither the origin nor the cache of the WebView.

## Develop and test

1. Copy a template folder and adapt it. Keep the logic in plain JavaScript that runs in
   an Android WebView (no build step needed); keep the page light and readable on a
   small screen, in the campaign language(s).
2. Keep the **demo data fallback** of the templates: without `window.Android` the report
   shows fake items, so it can be checked in a desktop browser:
   ```bash
   python3 -m http.server 8000 --directory templates/mobile_reports/campaign_progress
   ```
   then open `http://localhost:8000/` (use the phone width of the browser developer tools).
3. Make the fake items look like the real ones: same `formFormId`, same `values` keys and
   value formats as above.
4. Package it: `scripts/build_mobile_report.sh <folder> report.zip` (warns about files
   loaded from the internet).
5. Test on a phone after publishing (below): synchronise, open Report, compare with the
   submissions on the phone.

## Publish

Publish with the IASO API, through `scripts/iaso.py`. This needs an IASO server with the
mobile report upload API (the first IASO release after 28 October 2026, BLSQ/iaso#3471) and a user with the *Reports* permission
(`iaso_reports`):

```bash
python3 scripts/iaso.py mobile-report-upload <app_id> report.zip --name "Campaign progress" --version "v1"
```

- The first upload creates the project's report and publishes this version. The next
  uploads add a version to the same report and publish it (`--no-publish` to upload it
  without changing what phones get). `--version` defaults to the date and time.
- IASO refuses a file that is not a zip, a zip without `index.html` at its root (often a
  zip of the folder instead of its content: use `scripts/build_mobile_report.sh`), or a
  zip larger than 100 MB.
- List the versions, and go back to an earlier one if a new version is wrong:
  ```bash
  python3 scripts/iaso.py mobile-report-versions <app_id>
  python3 scripts/iaso.py mobile-report-publish <app_id> <version_id>
  ```
- The same is possible in the IASO web interface: *Admin > Projects*, edit the project,
  tab **Mobile report** (current report, versions, upload, publish).

Phones get the published version at their next synchronisation. Check what they will
download: `python3 scripts/iaso.py get "/api/mobile/reports/?app_id=<app_id>"` (name,
version, file URL). Only a published version is served.

Then add the `REPORTS` feature flag to the project (the upload command warns when it is
missing): `python3 scripts/iaso.py feature-flags <project_id> --add REPORTS`.
To withdraw the report, remove the flag.

### Older IASO servers

On a server without the upload API, `mobile-report-upload` stops and says so. The report
is then published in the IASO **Django admin**, which only Bluesquare staff can open: send
them the zip, the project (`app_id`) and the report name. They add a **Report version**
(`/admin/iaso/reportversion/add/`: name, the zip, status `published`), then a **Report**
(`/admin/iaso/report/add/`: name, project, that version as published version). On those
servers the app gets the report's published version whatever its status, and the first
report if a project has several.
