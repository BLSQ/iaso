#!/usr/bin/env python3
"""Previews an IASO page locally, with the real data, before publishing it.

Usage:
  python3 scripts/serve_page.py <page.html> [port]   serve it on http://localhost:8770/
  python3 scripts/serve_page.py --check <page.html>  check it without a browser
  python3 scripts/serve_page.py --stop               stop the preview started above

The page is served at / and every /api/ request is relayed to IASO_URL with the token
of iaso_config.txt added on the way. The browser never sees the token, and the page works exactly
as it will once served by IASO (same-origin calls to /api/...). Only GET is relayed:
a page under development cannot change anything in IASO.

--check is for assistants that cannot open localhost (Claude or ChatGPT in the browser): it
checks the JavaScript syntax of the page (with node, if installed) and reads, with the token, the
data the page reads (the form ids of its CONFIG, the pyramid). Run it before every publication.
"""

import http.server
import os
import pathlib
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

sys.path.insert(0, str(pathlib.Path(__file__).parent))

PID_FILE = pathlib.Path(tempfile.gettempdir()) / "iaso_serve_page.pid"


def stop():
    try:
        pid = int(PID_FILE.read_text())
    except (OSError, ValueError):
        sys.exit("No preview running (no process id recorded).")
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"Preview stopped (process {pid}).")
    except ProcessLookupError:
        print("The preview had already stopped.")
    PID_FILE.unlink(missing_ok=True)


def check_syntax(html):
    """Each inline <script> through `node --check`. Returns the number of errors."""
    node = shutil.which("node")
    if not node:
        print("SKIP  JavaScript syntax: node is not installed here.")
        return 0
    errors = 0
    for i, m in enumerate(re.finditer(r"<script([^>]*)>(.*?)</script>", html, re.S | re.I), 1):
        attrs, code = m.group(1), m.group(2)
        if "src=" in attrs or not code.strip():
            continue
        suffix = ".mjs" if "module" in attrs else ".js"
        with tempfile.NamedTemporaryFile("w", suffix=suffix, delete=False, encoding="utf-8") as f:
            f.write(code)
        r = subprocess.run([node, "--check", f.name], capture_output=True, text=True)
        os.unlink(f.name)
        if r.returncode:
            errors += 1
            # node gives the line in the script: turn it into the line in the page.
            line = re.search(r":(\d+)\n", r.stderr)
            where = f" (page line {html[:m.start(2)].count(chr(10)) + int(line.group(1))})" if line else ""
            # Keep the faulty line, the caret and the message; drop node's own stack.
            keep = [x for x in r.stderr.splitlines()[1:] if x.strip() and not x.strip().startswith(("at ", "Node.js"))]
            detail = "\n      ".join(keep)
            print(f"FAIL  script {i}: JavaScript syntax error{where}\n      {detail}")
        else:
            print(f"OK    script {i}: JavaScript syntax")
    return errors


def get(path):
    from iaso import BASE, TOKEN  # reads iaso_config.txt; not needed to --stop

    req = urllib.request.Request(BASE + path, headers={"Authorization": "Bearer " + TOKEN})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except urllib.error.URLError as e:
        return None, str(e.reason).encode()


def check_data(html):
    """Reads the data the page reads: the forms of CONFIG.forms, and the pyramid. Returns the number of errors."""
    errors = 0
    block = re.search(r"\bforms\s*:\s*\{(.*?)\}", html, re.S)
    forms = re.findall(r"(\w+)\s*:\s*(null|\d+)", re.sub(r"//[^\n]*", "", block.group(1))) if block else []
    if not forms:
        print("SKIP  forms: no `forms: {...}` block in the page's CONFIG.")
    for key, value in forms:
        if value == "null":
            print(f"WARN  form '{key}': id not set (null), the page will show nothing for it.")
            continue
        status, body = get(f"/api/instances/?form_ids={value}&parquet=true")
        if status == 200 and body[:4] == b"PAR1":
            print(f"OK    form '{key}' ({value}): {len(body):,} bytes of submissions")
        else:
            errors += 1
            print(f"FAIL  form '{key}' ({value}): HTTP {status} {body[:200].decode(errors='replace')}")
    if "/api/orgunits/" in html:
        status, body = get("/api/orgunits/?parquet=true&order=id")
        if status == 200 and body[:4] == b"PAR1":
            print(f"OK    pyramid (/api/orgunits/): {len(body):,} bytes")
        else:
            errors += 1
            print(f"FAIL  pyramid (/api/orgunits/): HTTP {status} {body[:200].decode(errors='replace')}")
    return errors


def check(page):
    html = page.read_text(encoding="utf-8")
    errors = check_syntax(html) + check_data(html)
    print("Page ready to publish." if not errors else f"{errors} problem(s): fix them before publishing.")
    sys.exit(1 if errors else 0)


def serve(page, port):
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith("/api/"):
                status, body = get(self.path)
                status = status or 502
                ctype = "application/octet-stream" if body[:4] == b"PAR1" else "application/json"
            elif self.path.split("?")[0] in ("/", "/index.html"):
                body, status, ctype = page.read_bytes(), 200, "text/html; charset=utf-8"
            else:
                body, status, ctype = b"not found", 404, "text/plain"
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt, *args):
            sys.stderr.write(fmt % args + "\n")

    from iaso import BASE

    server = http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
    PID_FILE.write_text(str(os.getpid()))
    print(f"Serving {page} on http://localhost:{port}/ (API relayed to {BASE}, read-only)")
    print("Stop it with: python3 scripts/serve_page.py --stop")
    try:
        server.serve_forever()
    finally:
        PID_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    args = sys.argv[1:]
    if args[:1] == ["--stop"]:
        stop()
    elif args[:1] == ["--check"] and len(args) == 2:
        check(pathlib.Path(args[1]))
    elif args and not args[0].startswith("-"):
        signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
        serve(pathlib.Path(args[0]), int(args[1]) if len(args) > 1 else 8770)
    else:
        sys.exit(__doc__)
