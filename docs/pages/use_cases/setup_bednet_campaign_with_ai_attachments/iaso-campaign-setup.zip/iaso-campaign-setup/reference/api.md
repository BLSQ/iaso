# IASO API payloads for a campaign setup

All calls go through `scripts/iaso.py` (`get`, `post`, `patch`, `put`, `delete`), which adds
the token. `<...>` marks values to replace. Ids are integers unless stated otherwise.

## Account and pyramid

| Purpose | Call |
|---|---|
| Who am I, account modules | `GET /api/profiles/me/` (never `DELETE` it: that deletes the user) |
| Org unit types (ids, depth, projects) | `GET /api/v2/orgunittypes/?limit=200` |
| Org units of a type | `GET /api/orgunits/?orgUnitTypeId=<id>&validation_status=VALID&limit=50&page=1` |
| Find an org unit by name | `GET /api/orgunits/?searches=[{"search":"<name>","validation_status":"VALID"}]&limit=20&page=1` |
| One org unit with its parents | `GET /api/orgunits/<id>/` |
| Feature flag catalog | `GET /api/featureflags/` |

### Importing a pyramid

`scripts/iaso.py pyramid-import` (Excel/CSV/GeoPackage) and `pyramid-dhis2` do this (see
`SKILL.md` § 3b). Both target the account's default source version:
`GET /api/profiles/me/` → `account.default_version` (`number`, `data_source.id`).

GeoPackage import (permission `iaso_sources`), a background task:

```text
POST /api/tasks/create/importgpkg/   multipart: file=@pyramid.gpkg, data_source=<source id>,
                                     version_number=<default version number>, default_valid=true,
                                     description=...
→ {"task": {"id": <task id>, "status": "QUEUED", ...}}
GET /api/tasks/<task id>/            → status QUEUED | RUNNING | SUCCESS | ERRORED, progress_message, result
```

- Format (IASO repository, `iaso/gpkg/README.md`): one layer per org unit type, named
  `level-{depth}-{type name}`, with `ref` (unique, kept as the unit's source reference),
  `name`, optional `parent_ref` (the parent's `ref`, or `iaso:<id>` for an existing unit;
  empty for a top unit), `code`, `group_refs`, `opening_date`, `closed_date`, a geometry
  (point or polygon, WGS 84, may be empty), and a `groups` table (`ref`, `name`), even empty.
- Units are matched by `ref` in the version: an import updates the units it already
  created. Missing types are created (same name and depth = same type) and attached to the
  projects of the source.

DHIS2 import (permission `iaso_sources`), with the credentials saved on the data source
(`GET /api/datasources/` → `credentials`: url, login, `is_valid`; the password is never
returned):

```json
POST /api/dhis2ouimporter/
{"source_id": <source id>, "source_version_number": <default version number>,
 "validate_status": true, "description": "..."}
→ {"task": {"id": <task id>, ...}}
```

- All levels are imported; types are named after the DHIS2 levels. With a version number,
  only the DHIS2 units missing from that version are created (existing ones are not updated).

Org unit types afterwards: `PATCH /api/v2/orgunittypes/<parent type id>/
{"sub_unit_type_ids": [<child type id>]}` chains the levels (the GeoPackage import does not).

## Projects

Create:

```json
POST /api/projects/
{
  "name": "Enumeration (net campaign 2027)",
  "app_id": "xx.itn2027.enum",
  "needs_authentication": true,
  "color": "#1565C0",
  "feature_flags": [
    {"id": <id>, "name": "<name>", "code": "REQUIRE_AUTHENTICATION"},
    {"id": <id>, "name": "<name>", "code": "ENTITY"}
  ]
}
```

Each feature flag item needs its `id`, `name` and `code` from `GET /api/featureflags/`.
`PATCH /api/projects/<id>/` with `feature_flags` **replaces the whole list**: use
`scripts/iaso.py feature-flags <id> --add X --remove Y`.

The project QR code that phones scan is in `GET /api/projects/<id>/` → `qr_code` (PNG data URL).

Attach org unit types (the list replaces the current one; the helper merges):

```bash
python3 scripts/iaso.py ou-types-add-project <project_id> <type_id> ...
# = for each type: PATCH /api/v2/orgunittypes/<type_id>/ {"project_ids": [<current ids>, <project_id>]}
```

## Forms

Create the form, then upload the XLSForm as a version:

```json
POST /api/forms/
{
  "name": "Household registration",
  "project_ids": [<enumeration project>, <distribution project>],
  "org_unit_type_ids": [],
  "period_type": null,
  "single_per_period": false,
  "periods_before_allowed": 0,
  "periods_after_allowed": 0,
  "device_field": "deviceid",
  "location_field": ""
}
```

```bash
python3 scripts/iaso.py upload-form <form_id> forms/01_household_registration.xlsx
# = POST /api/formversions/ multipart: form_id=<id>, xls_file=@file.xlsx
```

- The `form_id` setting of the XLSForm must stay the same across versions of one form.
- Add a form to another project: `scripts/iaso.py form-projects <form_id> --add <project_id>`.
  By hand: `PATCH /api/forms/<id>/` with the full `project_ids` list **and** the full
  `org_unit_type_ids` list (both are replaced; without `org_unit_type_ids` the server answers 500).
- List versions: `GET /api/formversions/?form_id=<id>&order=-created_at`
  (`xls_file` = download link of the source XLSForm).

## Entity types

```json
POST /api/entitytypes/
{
  "name": "Household",
  "account": <account id>,
  "reference_form": <form id of 01>,
  "fields_list_view": ["head_name", "id_number", "head_age"],
  "fields_detail_info_view": ["head_name", "id_number", "nets_needed", "nets_distributed", "distribution_date"],
  "fields_duplicate_search": ["qr_code"],
  "prevent_add_if_duplicate_found": true
}
```

The response does not include the id of the new type: find it by name with
`GET /api/entitytypes/`.

`PATCH /api/entitytypes/<id>/` overwrites all the `fields_*` lists: use
`scripts/iaso.py entity-type-update <id> '{"fields_list_view": [...]}'`, which sends the
rest unchanged.

What the phones will see: `GET /api/mobile/entitytypes/?app_id=<app_id>`.

## Workflows

```text
1. POST /api/workflowversions/                      {"entity_type_id": <id>, "name": "v1"}
   → {"version_id": <wv>, "status": "DRAFT", ...}
2. POST /api/workflowfollowups/?version_id=<wv>      {"order": 0, "condition": <JSONLogic or true>, "form_ids": [<form id>]}
3. POST /api/workflowchanges/?version_id=<wv>        {"form": <follow-up form id>, "mapping": {"<form field>": "<entity field>"}}
4. PATCH /api/workflowversions/<wv>/                 {"status": "PUBLISHED"}
```

- `condition` is a JSON object (JSONLogic) or `true`. Values compared are the entity's
  values as strings: compare numbers as `"0"`, not `0`.
- Edit follow-ups: `POST /api/workflowfollowups/bulkupdate/` with
  `[{"id": <followup id>, "condition": ..., "form_ids": [...], "order": 0}]`.
- Only DRAFT versions accept changes. To modify a published one:
  `POST /api/workflowversions/<wv>/copy` → new DRAFT → edit → publish. Publishing a version
  unpublishes the other published version of the same entity type.
- Status transitions: DRAFT → PUBLISHED or UNPUBLISHED; UNPUBLISHED → PUBLISHED;
  PUBLISHED → UNPUBLISHED.
- Inspect: `GET /api/workflowversions/<wv>/`, `GET /api/workflowchanges/?version_id=<wv>`,
  and as a phone sees it: `GET /api/mobile/workflows/?app_id=<app_id>`.

## Stock

```json
POST /api/stockkeepingunits/
{"name": "Nets", "short_name": "nets", "display_unit": "nets", "display_precision": 1,
 "projects": [<stock project>], "org_unit_types": [<type ids where stock is held>],
 "forms": [<stock form ids>]}

POST /api/stockrulesversions/   {"name": "v1"}            → {"name": "v1", "status": "DRAFT"} (no id in the response: take the DRAFT version from GET /api/stockrulesversions/)
POST /api/stockitemrules/       {"version": <rv>, "sku": <sku id>, "form": <form id>,
                                 "question": "rec_total_nets", "impact": "ADD", "order": 0}
PATCH /api/stockrulesversions/<rv>/   {"status": "PUBLISHED"}
```

`impact` is `ADD`, `SUBTRACT` or `RESET` (inventory count). The question must be a field
of the form whose value is the quantity.

## Users

```json
POST /api/profiles/
{
  "user_name": "enum_agent_001",
  "password": "<generated, stored locally, never in chat>",
  "first_name": "...", "last_name": "...",
  "language": "en",
  "org_units": [<org unit id where the agent works>],
  "projects": [<project ids>],
  "user_permissions": ["iaso_entities"]
}
```

`iaso_entities` is required for the users of every project with the `ENTITY` feature flag;
leave the list empty only for users of projects without entities (e.g. supervision).

Change projects or org units of an existing user: `PATCH /api/profiles/<profile id>/`
with the full `projects` / `org_units` lists. For dozens of users prefer the CSV import
of the web interface (Users → Import CSV), which the account administrator can run.

## Submissions and entities (checks, cleanup)

| Purpose | Call |
|---|---|
| Submissions of a form | `GET /api/instances/?form_ids=<id>&limit=100` |
| Same, as Parquet for dashboards | `GET /api/instances/?form_ids=<id>&parquet=true` |
| Submissions of an entity | `GET /api/instances/?entityId=<entity id>` |
| Find an entity by uuid or name | `GET /api/entities/?search=<text>` |
| Delete a test entity (soft, with its submissions, audited) | `DELETE /api/entities/<id>/` |

## Mobile reports — details in `reference/mobile-reports.md`

Use `scripts/iaso.py mobile-report-upload|mobile-report-versions|mobile-report-publish`
rather than these calls by hand. Permission *Reports* (`iaso_reports`); the first IASO release after 28 October 2026 (BLSQ/iaso#3471).

| Action | Call |
|---|---|
| Report of a project | `GET /api/reports/?project=<project id>` (a list, empty or one report) |
| Create it with its first, published version | `POST /api/reports/` multipart: `project`, `name`, `version_name`, `file` (the zip) |
| Add a version | `POST /api/reports/<id>/versions/` multipart: `name`, `publish` (`true`/`false`), `file` |
| List the versions | `GET /api/reports/<id>/versions/` (most recent first, with `status`) |
| Publish an earlier version | `POST /api/reports/<id>/publish/ {"version_id": <id>}` |
| What phones download | `GET /api/mobile/reports/?app_id=<app_id>` |

A second `POST /api/reports/` for the same project is refused (400, with the id of the
existing report). Without the upload API, `GET /api/reports/0/publish/` answers 404
instead of 405: the server is too old.

## Pages (dashboards) — details in `reference/pages.md`

```json
POST /api/pages/
{"name": "Campaign dashboard", "slug": "campaign-dashboard", "type": "RAW",
 "content": "<full HTML>", "needs_authentication": true, "users": [<user ids>]}
```

Update with `PATCH /api/pages/<id>/ {"content": "..."}`; read the page first and check
nobody changed it since you downloaded it. Served at `<IASO_URL>/pages/<slug>/`.
