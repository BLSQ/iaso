# Comment s'articule la campagne

```text
                 ┌──────────────── App Dénombrement ───────────────┐
 Ticket QR ──►   │ recherche par QR ─► Ménage (01) ──suivi──► Distribution (02)
                 │ Ménage absent/en refus (03) ──suivi──► Revisite (04)
                 │ Ménage servi en routine (05)                  │
                 └────────────────────────────────────────────────┘
                 ┌──────────────── App Distribution ───────────────┐
                 │ recherche (sans création) ─► Ménage ─► Distribution (02)
                 │                           ─► Groupement spécial ─► Distribution groupement (07)
                 └────────────────────────────────────────────────┘
                 ┌── App Groupements ─────┐  ┌── App Travailleurs ────────────────┐
                 │ Groupement spécial (06)│  │ Travailleur (08) ─suivi─► Présence (09)
                 │ └► Distribution (07)   │  └────────────────────────────────────┘
                 └────────────────────────┘
                 ┌── App Stock ───────────────────────────────────┐
                 │ Réception (10) +  Sortie (11) −  Retour (12) +   │──► solde de stock
                 │ Transfert (13) −  Perte (14) −                   │    par unité d'organisation
                 └────────────────────────────────────────────────┘
                 ┌── App Supervision ──┐
                 │ Fiche superv. (15)  │
                 └─────────────────────┘
```

## Entités et workflows

Une **entité** est un ménage, un groupement spécial ou un travailleur. Elle est créée par
son **formulaire de référence**, puis mise à jour par des **formulaires de suivi**, via le
**workflow** du type d'entité :

- la **condition** du suivi (JSONLogic sur les valeurs de l'entité) décide quand l'app
  le propose — par ex. la distribution uniquement tant que `nets_distributed` vaut `"0"` ;
- le formulaire de suivi reçoit les valeurs de l'entité pour les champs portant le même nom ;
- les **changes** (modifications) du workflow recopient les réponses du suivi dans l'entité —
  par ex. `nets_given → nets_distributed`, ce qui clôture la distribution.

## Pourquoi des applications séparées

Chaque projet est une configuration distincte sur le téléphone : ses propres formulaires,
entités, feature flags et zone de téléchargement. Séparer par rôle allège le téléphone de
chaque agent et évite les erreurs (un agent de distribution ne peut pas créer de ménages ;
un gestionnaire de stock arrive directement sur l'écran de stock). Un même téléphone peut
contenir plusieurs projets ; l'utilisateur passe de l'un à l'autre.

## Flux de données pour les tableaux de bord

Chaque soumission est disponible en Parquet : `GET /api/instances/?form_ids=<id>&parquet=true`.
Les tableaux de bord relient le dénombrement (01, 03, 05), la distribution (02, 07), les
groupements (06), le stock (10–14) et la présence (08, 09) par identifiant d'entité et par
unité d'organisation.
