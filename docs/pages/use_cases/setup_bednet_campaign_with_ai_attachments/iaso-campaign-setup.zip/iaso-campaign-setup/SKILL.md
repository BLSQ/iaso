---
name: iaso-net-campaign-setup
description: Configure a complete insecticide-treated net (ITN) mass distribution campaign in an IASO account through the API - mobile projects, household and special-group entities, enumeration/distribution workflows, worker attendance, stock and supervision forms, users. Use when someone wants to set up, extend or audit such a campaign on IASO.
---

# IASO net distribution campaign setup

You are configuring an IASO account for a door-to-door net distribution campaign. The
person you work with has an IASO account and has pasted their API token into `iaso_config.txt`
(see `README.md`, step 1). Everything is done through the IASO API with `scripts/iaso.py`.

Work in this order. Each step says what to ask, what to create and how to check it.
Never skip the checks: the API accepts many payloads that silently break the mobile app.

Read `reference/pitfalls.md` before step 4, and keep `reference/api.md` open for payloads.

## 0. Ground rules

- **Do not use any IASO MCP connector or tool**, even if one is available in your
  environment (tools with names like `iaso_*`, `list_forms`, `get_org_unit`,
  `preview_create_pyramid`…): it is not ready yet. Do everything with `scripts/iaso.py`.
- **Production data.** Treat the account as production. Before the first write, run
  `python3 scripts/iaso.py backup backups/` and tell the user where the snapshot is.
  Run it again before any risky change.
- **Never print the token.** Never put it in a URL, a file you share, or a chat message.
- **Read, merge, write.** Several endpoints replace lists wholesale (project feature flags,
  org unit type projects, entity type field lists). Use the safe commands of
  `scripts/iaso.py`, or always send the full current value plus your change.
- **Confirm before destructive or irreversible actions**: deleting, removing a form from
  a project, changing a published workflow, changing a question in a form that phones
  already use, creating users with passwords.
- **Validate every XLSForm locally** before uploading (`scripts/validate_forms.sh`).
- **Report what you did** after each step: ids created, what you checked, what is left.
- **The setup is not finished after projects, forms and workflows.** It is finished when
  everything decided in § 2b is done: QR codes shown, web pages and mobile reports published,
  test users created. Go through the checklist of § 12c before announcing the end.

## 1. Server and access

First ask the user **which IASO server they use** (the address they open in their
browser), proposing the default **`https://demo.openiaso.com`**. Check that `IASO_URL` in
`iaso_config.txt` is that address; if not, ask them to correct it (or correct it yourself:
it is not a secret). Then:

```bash
python3 scripts/iaso.py whoami
```

- If it says the token is missing or the API answers 401, walk the user through
  `README.md` step 1: give them the link `<IASO_URL>/login/?next=/api/apitoken/` built with
  their IASO address (e.g. `https://demo.openiaso.com/login/?next=/api/apitoken/`); after login
  it shows the token. They copy the `token` value, paste it after `IASO_TOKEN=` in `iaso_config.txt`, save. Do not ask them to
  paste the token in the chat.

- The account must have these four modules (`modules` in the output):
  `DATA_COLLECTION_FORMS`, `ENTITIES`, `STOCK_MANAGEMENT`, `EMBEDDED_LINKS`
  (in the IASO "Setup a new account" screen: *Data collection - Forms*, *Entities*,
  *Stock management*, *Embedded links*; plus *DHIS2 mapping* to import the pyramid from DHIS2,
  § 3b). If one is missing, stop: an IASO administrator
  must add it to the account. Without `STOCK_MANAGEMENT` there is no stock in the app;
  without `EMBEDDED_LINKS` no report pages.
- The user needs at least these permissions: `iaso_forms`, `iaso_projects`,
  `iaso_org_units`, `iaso_org_unit_types`, `iaso_entities`, `iaso_entity_type_write`, `iaso_workflows`,
  `iaso_users` (to create users), `iaso_stock_management` (stock), `iaso_sources` and
  `iaso_write_sources` (pyramid import, § 3b), `iaso_reports` (mobile reports), `iaso_page_write`
  (report pages, needs the account module `EMBEDDED_LINKS`).
  Missing permissions show up as HTTP 403: tell the user which one to request.

## 2. Collect the campaign inputs

Copy `templates/campaign.yaml` to `campaign.yaml` and fill it **with the user**, one
section at a time. Do not invent values. The essentials:

- Campaign name, country, language(s) of the forms, default language of labels.
- **Scope**: the districts (or regions) covered, by name; you will resolve them to org unit ids.
- **Pyramid levels**: which org unit types exist (national → … → village) and at which
  level households are registered (usually the health facility or the village).
- **Mobile apps**: which of the six projects of section 4 are needed, and their `app_id`
  (lowercase, dot separated, unique across the server, e.g. `xx.itn2027.enum`).
- **Allocation rule**: nets per household (default here: one net per sleeping space still
  to cover, capped at the number of people).
- **Ticket / QR codes**: are households given a QR ticket at enumeration? Are nets or
  bales QR coded?
- **Special groups** (prisons, camps, boarding schools…): registered in the field or
  imported from a plan?
- **Workers and payment**: roles, daily rates, who validates attendance.
- **Stock**: warehouses, bale size, which movements are tracked.
- **Users**: who uses which app, at which org unit.

### 2b. Decisions to confirm before writing to IASO

Before the backup and the first write, ask these questions and note the answers in the
`deliverables` section of `campaign.yaml`. Offer the defaults below; assume nothing the user
has not confirmed.

1. **Mobile reports, per app** (one report per project, § 12b). By default:

   | App | Mobile report | Map |
   |---|---|---|
   | Enumeration | Campaign progress (`campaign_progress`) | yes, with place names |
   | Distribution | Campaign progress (`campaign_progress`) | yes, with place names |
   | Special groups | none (no `REPORTS` flag) | — |
   | Workers & attendance | Team attendance (`attendance`) | — |
   | Stock | Stock (`stock`) | — |
   | Supervision | none | — |

2. **The map** in the progress reports: do they want it? with place names? with Bluesquare's
   base map (`martin.bluesquare.org`, loaded when the phone has a network; styles `light`,
   `dark`, `white`, `grayscale`, `black`) or no base map (only the households and the names,
   always works offline)? See "Maps" in `reference/mobile-reports.md`.
3. **Web pages** (§ 12): which ones to publish (campaign dashboard, attendance and payment,
   others), and **who can open each one** (named users or IASO roles). The payment page shows
   phone and ID numbers: only the people who prepare payments.
4. **Test users**: create them (one per app, or one for all)? IASO passwords must follow the
   server's policy (§ 9).
5. **QR codes**: they are generated and shown in the conversation as soon as the projects
   exist (§ 4); only ask whether they also want the printable page for the training.

Sum these decisions up for the user and have them approved before starting.

## 3. Map the account

```bash
python3 scripts/iaso.py get "/api/v2/orgunittypes/?limit=200"
python3 scripts/iaso.py get /api/projects/
python3 scripts/iaso.py get "/api/forms/?limit=500&fields=id,name,form_id,projects"
python3 scripts/iaso.py get /api/entitytypes/
```

- Note the org unit type ids per level, and the existing projects and forms. Reuse what
  exists instead of creating duplicates; ask when unsure.
- Resolve the districts of the scope (quote the whole path in single quotes):
  `python3 scripts/iaso.py get '/api/orgunits/?searches=[{"search":"<name>","validation_status":"VALID","orgUnitTypeId":"<district type id>"}]&limit=20&page=1'`.
  Write the ids into `campaign.yaml`.

### 3b. Org units (health pyramid)

Every app, user and dashboard depends on the pyramid: settle it first. Step 3 shows
whether the account already has one (org unit types with units). Ask the user **where their
org units come from**, and propose:

1. **DHIS2**, if the country has a DHIS2 with its health pyramid. IASO imports all its
   org units, every level, with their DHIS2 ids, codes, coordinates and boundaries.
2. **An Excel (or CSV) file.** Give them the template `templates/pyramid_template.xlsx`:
   one row per lowest-level unit, one column per level from the top (e.g. Country, Region,
   District, Health facility, Village; they rename the columns to their own level names,
   which become the org unit types), optional `latitude`, `longitude` (decimal degrees) and
   `code` columns. A GeoPackage already in the IASO format (for example with boundaries,
   exported from IASO or prepared in QGIS) is accepted too.
3. **A demo pyramid**, to try the campaign without real data:
   `templates/pyramid_demo.xlsx` (1 country, 2 regions, 4 districts, 12 health facilities,
   36 villages).
4. **Nothing**, if the account already has its pyramid: then only resolve the districts of
   the scope.

Both imports go into the **account's default source version**: the pyramid that projects,
users and phones use. They run as IASO background tasks; the commands follow them to the end.
The setup user needs the *Data sources* permissions (`iaso_sources`, and `iaso_write_sources`
to save DHIS2 credentials).

**From DHIS2.** The account needs the **DHIS2 mapping** module (an IASO administrator adds
it): without it IASO shows no DHIS2 field. The user enters the DHIS2 address, login and
password in IASO themselves, never in the chat: *Admin > Data Sources > Data Sources list*,
edit the account's source (gear icon), fill in *DHIS2 name*, *DHIS2 url*, *DHIS2 login*,
*DHIS2 password*, click *Test settings*, save. IASO never sends the password back,
so the command only uses it through IASO. Then:

```bash
python3 scripts/iaso.py pyramid-dhis2            # dry run: DHIS2 address, target version, units already there
python3 scripts/iaso.py pyramid-dhis2 --apply    # imports the DHIS2 org units
```

- Prefer a DHIS2 login that can only read. The org unit types are named after the DHIS2
  levels; tell the user which ones the campaign will use (step 4 attaches them to the apps).
- In a version that already has org units, only the DHIS2 units it does not have yet (by
  DHIS2 id) are added; units created another way would stay next to their DHIS2 twin. If the
  account already has a pyramid that did not come from this DHIS2, stop and ask.

**From Excel/CSV (or GeoPackage).**

```bash
python3 scripts/iaso.py pyramid-import <file.xlsx>            # dry run: counts per level, types; writes <file>.gpkg
python3 scripts/iaso.py pyramid-import <file.xlsx> --apply    # imports the GeoPackage into IASO
```

- The command converts the file to a GeoPackage in the IASO import format (one layer
  `level-{depth}-{type}` per level, points in WGS 84) and imports it with IASO's GeoPackage
  import. Show the user the dry-run summary and get their go-ahead before `--apply`; fix with
  them the problems it reports (empty levels, codes used twice, coordinates out of range,
  often latitude and longitude swapped).
- Missing org unit types are created and chained (each type's sub-type is the next level);
  units are created as `VALID`, with their code and GPS point.
- Each unit gets a stable reference (its path of names): importing the same file again,
  after a fix, updates the units instead of duplicating them. Units created another way
  (web, mobile) are not matched: if the version already has units, check with the user that
  the file does not contain them too.
- A GeoPackage given directly must follow the IASO format (`ref`, `name`, optional
  `parent_ref` and `code` per layer, a `groups` table); the dry run checks it.

## 4. Projects (one per mobile app)

A project is what a phone loads: an `app_id`, a list of forms and feature flags. The
standard campaign uses up to six (see `reference/architecture.md` for the diagram):

| Project | Forms | Feature flags |
|---|---|---|
| Enumeration | 01 household registration, 02 net distribution, 03 absent/refusal, 04 revisit, 05 served by routine | `REQUIRE_AUTHENTICATION`, `ENTITY`, `TAKE_GPS_ON_FORM`, `LIMIT_OU_DOWNLOAD_TO_ROOTS`, `MOBILE_SYNCHRONIZE_WITH_ZIP`, `SHOW_LINK_INSTANCE_REFERENCE`, `REPORTS` |
| Distribution | 01, 02, 06 special group registration, 07 special group distribution | same as Enumeration **+ `MOBILE_ENTITY_NO_CREATION`**, and **without** `MOBILE_ENTITY_LIMITED_SEARCH` |
| Special groups | 06 special group registration, 07 | same as Enumeration |
| Workers & attendance | 08 worker registration, 09 daily attendance | `REQUIRE_AUTHENTICATION`, `ENTITY`, `TAKE_GPS_ON_FORM`, `MOBILE_ENTITY_WARN_WHEN_FOUND`, `MOBILE_FINALIZED_FORM_ARE_READ`, `REPORTS` |
| Stock | 10–14 stock forms | `REQUIRE_AUTHENTICATION`, `ENTITY`, `MOBILE_ENTITY_NO_CREATION`, `MOBILE_STOCK`, `MOBILE_STOCK_HOME` (app ≥ 3.0.5), `TAKE_GPS_ON_FORM`, `REPORTS` |
| Supervision | 15 supervision | `REQUIRE_AUTHENTICATION`, `DATA_COLLECTION`, `TAKE_GPS_ON_FORM`, `MOBILE_SUBMISSION_INCOMPLETE_BY_DEFAULT` |

Add `REPORTS` only to the projects that will have a mobile report (§ 2b): a project without
a report does not need this flag.

**Project names: start with the word that differs.** On phones, project names are cut
in lists after a few characters: "Net campaign 2027 – Enumeration", "Net campaign 2027 –
Distribution"… all show as "Net campaign 20…" and agents pick the wrong app. Name them
"Enumeration", "Distribution", "Stock"…, and put the campaign after if needed
("Enumeration – net campaign 2027"). The same goes for `app_id`s, read by people configuring phones
(`xx.enum.itn2027`, not only the end changing).

Create each project (payload in `reference/api.md` § Projects), then check it with
`get /api/projects/<id>/`. Adjust feature flags afterwards only with
`scripts/iaso.py feature-flags <id> --add … --remove …`. A flag that this server does not
have (for example `MOBILE_STOCK_HOME`, missing from some IASO servers) is skipped with a
warning: tell the user, and leave it out of the project payload.

Then attach the org unit types each app must download:

```bash
python3 scripts/iaso.py ou-types-add-project <project_id> <type_id> <type_id> ...
```

- Give each project **every level** at which its forms are filled or its entities are
  registered, plus all levels above them. An entity registered at a level the app does
  not download blocks the whole synchronisation of that app (`reference/pitfalls.md` #6).
- Special groups usually need the full pyramid down to the village.

**Show the QR codes right away.** As soon as the projects are created, generate the QR codes
(`python3 scripts/iaso.py qr-codes --out qr_codes`, § 10) and show them in the conversation,
without waiting to be asked: the user can then install the app and set up a test phone while
you continue.

## 5. Forms

1. Copy the needed files from `forms/` into a working folder, and adapt them with the
   user: labels in the campaign language(s) (the templates have `label::English (en)` and
   `label::French (fr)` columns; add or remove language columns, and set
   `default_language` in the settings sheet), every cell marked `ADAPT:` (phone format,
   allocation rule, years, warehouses, bale size, roles), choice lists.
   **Keep the field names**: entity types, workflows, stock rules and dashboards refer to them.
2. Validate: `scripts/validate_forms.sh <folder>`.
3. Create each form, then upload its XLSForm (payloads in `reference/api.md` § Forms):
   ```bash
   python3 scripts/iaso.py post /api/forms/ '{"name": "Household registration", "project_ids": [<enum>, <dist>], "org_unit_type_ids": [], "period_type": null, "single_per_period": false, "periods_before_allowed": 0, "periods_after_allowed": 0}'
   python3 scripts/iaso.py upload-form <form_id> forms/01_household_registration.xlsx
   ```
4. Put each form in **every project whose app needs it**. In particular the household
   registration form (01) and the special group registration form (06) must be in the
   Distribution project too: the app only downloads the entities whose reference form is in
   its project (`MOBILE_ENTITY_NO_CREATION` still prevents creating them there). Change the
   projects of an existing form with `scripts/iaso.py form-projects <form_id> --add <project_id>`.
5. Check: `get /api/formversions/?form_id=<id>` shows the new version.

## 6. Entity types

Five entity types, each with its reference form (payloads in `reference/api.md`):

| Entity type | Reference form | List fields | Duplicate search | Block if found |
|---|---|---|---|---|
| Household | 01 | `head_name`, `id_number`, `head_age` | `qr_code` | yes |
| Household absent or refused | 03 | `household_code`, `status` | `household_code` | no |
| Household served by routine | 05 | `head_name`, `id_number`, `head_age` | `head_name` | no |
| Special group | 06 | `group_name`, `group_type` | `group_name` | no |
| Worker | 08 | `full_name`, `role` | `id_number_clean` | no |

- The duplicate search fields are what the agent searches on before creating an entity.
  For households the agent scans the QR ticket: the scanned value fills the read-only
  `qr_code` field, and "block if found" prevents registering the same ticket twice.
- Searching by name must **not** block (homonyms), it only shows matches.
- Detail fields (`fields_detail_info_view`) are what the entity screen shows: add the
  fields agents need on the spot (nets needed, nets distributed, distribution date…).
- Change these fields later only with `scripts/iaso.py entity-type-update` (a partial
  PATCH wipes the other field lists).

## 7. Workflows

A workflow says which follow-up forms the app proposes on an entity, and how a follow-up
updates the entity. Create a version, add follow-ups and changes, then publish
(payloads in `reference/api.md` § Workflows):

| Entity type | Follow-up form | Condition (JSONLogic on entity values) | Changes (form field → entity field) |
|---|---|---|---|
| Household | 02 net distribution | `{"and":[{"!=":[{"var":"nets_needed"},null]},{"==":[{"var":"nets_distributed"},"0"]}]}` | `nets_given → nets_distributed`, `distribution_date → distribution_date` |
| Household absent or refused | 04 revisit | `{"!=":[{"var":"status"},"enumerated"]}` | `status → status`, `ticket_number → enumeration_ticket` |
| Special group | 07 group distribution | `{"or":[{"==":[{"var":"nets_distributed"},null]},{"==":[{"var":"nets_distributed"},""]},{"==":[{"var":"nets_distributed"},"0"]}]}` | `nets_given → nets_distributed` |
| Worker | 09 daily attendance | `true` | — |

- The conditions make each distribution happen **once**: once `nets_distributed` is set,
  the follow-up disappears from the app.
- Follow-up forms receive the entity values whose names match their own fields: that is
  how the distribution form gets `head_name`, `nets_needed` or `qr_code`.
- Only DRAFT versions can be edited. To change a published workflow: copy it, edit the
  copy, publish it (publishing unpublishes the previous version).
- Check: `get "/api/mobile/workflows/?app_id=<app_id>"` lists the published follow-ups as
  the phone will see them.

## 8. Stock (if tracked in the app)

1. Create one stock keeping unit, e.g. "Nets (pieces)", attached to the Stock project
   (and Enumeration/Distribution if distributions must decrease the stock), to the org
   unit types where stock is held, and to the stock forms.
2. Create a rules version, add one rule per movement, publish it:

| Form | Question | Impact |
|---|---|---|
| 10 stock receipt | `rec_total_nets` | `ADD` |
| 11 stock issue | `iss_total_nets` | `SUBTRACT` |
| 12 stock return | `ret_total_nets` | `ADD` |
| 13 stock transfer | `tr_total_nets` | `SUBTRACT` |
| 14 stock loss | `loss_pieces` | `SUBTRACT` |
| 02 net distribution (optional) | `nets_given` | `SUBTRACT` |

Only count distributions here if issues to teams are **not** already subtracted:
otherwise the same nets leave the stock twice.

## 9. Users

- One user per agent (no shared accounts): username, password, org units (the area the
  agent works in; the app downloads that subtree only), projects (the apps they may open),
  permissions.
- **Every user of a project that uses entities (feature flag `ENTITY`) must have the
  permission `iaso_entities`** ("Entities" in the web interface): Enumeration, Distribution,
  Special groups, Workers & attendance and Stock in this guide. Without it the app cannot
  download or show households, groups or workers. Supervision-only users do not need it.
  Check it after creating the users with `python3 scripts/iaso.py users-check` (the list
  of `/api/profiles/` does not include permissions).
- For many users, use the CSV bulk import of the IASO web interface (Users → Import),
  which the user can do themselves (column `permissions`: `iaso_entities`); or
  `POST /api/profiles/` one by one.
- Confirm with the user before creating accounts and passwords, and never put passwords
  in chat: write them to a local file the user keeps.
- **Password policy.** IASO refuses (HTTP 400, with the reason) a password shorter than 8
  characters, too common (`test`, `password`, `12345678`…), entirely numeric, or too close to
  the username. Generate random passwords of at least 12 characters, test users included, and
  tell the user if they suggest their own.

## 10. Phones

No mobile code or build is needed: everyone uses the generic **IASO** app published by
Bluesquare on the Play Store (`com.bluesquarehub.iaso`).

**Show the QR codes in the chat.** Once the projects exist, run:

```bash
python3 scripts/iaso.py qr-codes --out qr_codes            # all projects, or list project ids / app_ids
```

It writes `qr_codes/play_store_iaso_qr.png` (installs the IASO app), one
`qr_codes/qr_<app_id>.png` per project (configures the app: server + `app_id`), and
`qr_codes/qr_codes.html`, a page with all of them and the instructions. **Present these
images directly to the user in the conversation**: attach or send the PNG files, or open
the HTML page, whatever your interface allows; name each project under its QR code. If
images cannot be shown, give the path of `qr_codes.html`. The user scans the Play Store
code first, then the project code from the app's start screen.

- On first launch the app asks how to configure it: **scan the project QR code** (the
  ones above; also in the web interface, Admin → Projects), or **manual entry** of the
  server URL and the `app_id`.
  Then log in with the user's IASO credentials.
- One phone can switch between projects by changing the `app_id` in the app: a single
  test phone can try all the apps.
- Some feature flags need a recent app version. Check the version installed (app
  settings / about) before relying on them:

| Feature | Minimum app version | Without it |
|---|---|---|
| `MOBILE_STOCK_HOME` (app opens on the stock screen) | 3.0.5 | the app opens on the usual home screen |
| `_app_id` in workflow conditions | 3.0.5 | a condition on `_app_id` is false: the follow-up is hidden |

- A dedicated branded app (own name, icon, `app_id` built in) is a separate build of the
  mobile app: ask Bluesquare.

## 11. Dry run and launch checklist

Do a full test on a phone for every app before training, with test users
(phones set up with the QR codes of § 10):

- [ ] Enumeration: scan a ticket, register a household, reopen it from the search.
- [ ] Scanning the same ticket again is blocked.
- [ ] Absent household → revisit → enumerated; it no longer proposes a revisit.
- [ ] Distribution app: cannot create households; search finds the household; scanning the
      household ticket as a net is refused; after the distribution the follow-up disappears.
- [ ] Special group: register, distribute once.
- [ ] Worker registration, attendance validated.
- [ ] Stock: receipt then issue; the stock screen shows the balance.
- [ ] Every phone synchronises without error (step "Entities" included).
- [ ] Every app with a mobile report opens it (Report button) with the right figures; the map
      shows the households and the place names, with and without network.
- [ ] **Before launch, delete all test entities and submissions** (they would count in the
      dashboards and can block synchronisation, see pitfalls #6) and test users.

## 12. Reports (web pages in IASO)

Follow `reference/pages.md`. In short:

1. Copy `templates/pages/campaign_dashboard.html`, set its `CONFIG` (form ids created above,
   title, org unit type names to group by).
2. Preview it with the real data: `python3 scripts/serve_page.py <file>` → `http://localhost:8770/`.
   Check the console, compare a few totals with the web interface.
3. Take who can open it from § 2b and have it confirmed when publishing: named users
   (`users`) or roles (`user_roles`), see `reference/pages.md`. Publish it with
   `POST /api/pages/` (type `RAW`) and give the URL `<IASO_URL>/pages/<slug>/`.

**Attendance and payment page** (template `templates/pages/attendance_payment.html`):
worker × day calendar of declared and validated days, amount due per worker, Excel
payment sheet with formulas.

1. **Agree the payment rules in writing with the user first**: daily rate per role,
   one-off allowance paid once (e.g. transport), maximum number of paid days, mobile money
   fee table, currency. Only days validated by the supervisor are paid.
2. Put them in the page's `CONFIG` with the ids of forms 08 and 09 and the org unit type
   names (`levels`). Role codes must match the `role` choices of form 08.
3. Preview with real data (`scripts/serve_page.py`), check two or three workers by hand
   against the attendance submissions, then publish it for the people who prepare payments
   only (it shows phone and ID numbers).

Other useful pages (special groups, stock, supervision) follow the same pattern;
`reference/pages.md` lists what each one reads.

### 12b. Mobile reports (offline, in the app)

Follow `reference/mobile-reports.md`. Each project gets **one** report, opened from the
app's Report button and computed on the phone, without network. Publish those decided in
§ 2b:

| Template | Apps | Shows |
|---|---|---|
| `templates/mobile_reports/campaign_progress/` | Enumeration, Distribution | households enumerated and served, nets, absent/refused, by health facility; map of households with place names |
| `templates/mobile_reports/attendance/` | Workers & attendance | today: who is validated, to validate, not recorded yet; over the campaign: days declared and validated per worker |
| `templates/mobile_reports/stock/` | Stock | balance, totals by movement, last movements |

1. Copy the template folder. Set the XLSForm `form_id`s in its config and, for the map, the
   `MAP` settings decided (map, place names, base map). Adapt labels and indicators with the
   user (what team leaders must see each evening).
2. Check it in a desktop browser at phone width: without the app it shows demo data
   (`python3 -m http.server 8000 --directory <folder>`).
3. Package it: `scripts/build_mobile_report.sh <folder> report.zip`.
4. Ask the user before publishing, then publish it:
   `python3 scripts/iaso.py mobile-report-upload <app_id> report.zip --name "<report name>" --version "<v1>"`.
   It creates the project's report or adds a published version to it. Add the `REPORTS`
   feature flag to the project and check `GET /api/mobile/reports/?app_id=<app_id>`.
   If the command says the server is too old, follow "Older IASO servers" in
   `reference/mobile-reports.md` (Django admin, Bluesquare staff).
5. Test on a real phone after a synchronisation, comparing the figures with the submissions
   listed in the app. For a map: with network (base map), then in airplane mode (the
   households and the place names must still show).

### 12c. End of the setup

Do not announce that the setup is finished before ticking, with the user, everything decided
in § 2b:

- [ ] Projects, forms, entity types, workflows, stock created and checked.
- [ ] QR codes generated and shown in the conversation (§ 4, § 10).
- [ ] Web pages published, each for the agreed people; URLs given.
- [ ] Mobile reports published for each agreed app, `REPORTS` flag added,
      `GET /api/mobile/reports/?app_id=…` checked; map and place names if asked.
- [ ] Users (and test users) created, `users-check` without problems, passwords in a local
      file.
- [ ] Checklist of § 11 given to the user for the phone test.

End with a summary: what was created (with ids), what is left, and what the user must test
on a phone.

## 13. Changing things during the campaign

The campaign will change while it runs. Before each change, re-read `reference/pitfalls.md`:
the safe way to change a deployed form, an entity type or a workflow is different from
setting them up, and the mobile app is much less forgiving than the API.
