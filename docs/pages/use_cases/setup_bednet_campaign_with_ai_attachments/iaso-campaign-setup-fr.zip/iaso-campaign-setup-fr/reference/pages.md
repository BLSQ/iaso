# Rapports : pages web IASO

IASO peut héberger des pages web pour l'équipe de campagne : tableaux de bord, fiches de
présence et de paiement, listes à imprimer. Une page est servie à l'adresse
`<IASO_URL>/pages/<slug>/`, uniquement aux utilisateurs connectés que vous choisissez, et
lit les données avec **leurs propres permissions IASO**. Un tableau de bord de départ se
trouve dans `templates/pages/campaign_dashboard.html`.

## Fonctionnement d'une page

- **Type `RAW`** : la page est un fichier HTML unique stocké dans IASO (`content`). D'autres
  types existent : `IFRAME` (intègre une URL externe), `TEXT`, `POWERBI`, `SUPERSET`.
- **Aucun jeton dans la page.** Elle est servie par IASO sur le même domaine que l'API, donc
  ses appels `fetch('/api/...', {credentials: 'include'})` transportent le cookie de session
  de l'utilisateur connecté. Chaque lecteur ne voit que les unités d'organisation et les
  formulaires auxquels il a accès.
- **Source de données** : les soumissions de chaque formulaire sous forme de fichier Parquet,
  `GET /api/instances/?form_ids=<id>&parquet=true`. Colonnes :
  - une colonne par champ du formulaire, nommée d'après le nom du champ (les groupes sont
    aplatis : `people_count`, pas `registration/people_count`) ; les groupes répétés ne
    sont pas développés ;
  - des métadonnées préfixées par `iaso_subm_` : `iaso_subm_id`, `iaso_subm_org_unit_id`,
    `iaso_subm_org_unit_name`, `iaso_subm_entity_id`, `iaso_subm_created_by_username`,
    `iaso_subm_source_created_at`, `iaso_subm_latitude`, `iaso_subm_longitude`…
- **Pyramide** : `GET /api/orgunits/?parquet=true&order=id` avec les colonnes `org_unit_id`,
  `org_unit_name`, `org_unit_type_name`, `org_unit_parent_id`. Remontez les parents pour
  regrouper les soumissions par région, district ou formation sanitaire. Contours pour les
  cartes : ajoutez `extra_fields=simplified_geom_geojson` et filtrez par type avec
  `searches=[{"orgUnitTypeId":"<id>"}]`.
- **Lire du Parquet dans le navigateur** : `hyparquet` et `hyparquet-compressors` depuis
  jsDelivr, comme dans le modèle (fixez les versions).
- **Relier les formulaires** : une distribution et le ménage qu'elle sert partagent
  `iaso_subm_entity_id` ; les formulaires de suivi d'un travailleur (présence) partagent
  l'identifiant d'entité du travailleur.

## Construire une page

1. Copiez `templates/pages/campaign_dashboard.html` et renseignez son bloc `CONFIG` : les
   identifiants des formulaires créés pendant la configuration, le titre, les noms des
   types d'unité d'organisation selon lesquels regrouper.
2. Si vous modifiez les indicateurs, conservez les noms de champs des formulaires (voir
   `forms/README.md`). Un champ masqué avec `relevant = false()` n'est pas enregistré et
   sera vide ici.
3. Prévisualisez-la en local avec les vraies données :
   ```bash
   python3 scripts/serve_page.py my_dashboard.html
   ```
   puis ouvrez `http://localhost:8770/`. Le script sert la page et relaie les appels à l'API
   avec le jeton de `iaso_config.txt`, de sorte que la page fonctionne exactement comme dans IASO, et
   en lecture seule. Vérifiez la console du navigateur pour repérer les erreurs, et
   comparez quelques totaux avec l'interface web IASO (Forms → submissions).
4. Vérifiez les modes clair et sombre, ainsi qu'une fenêtre de la largeur d'un téléphone :
   les superviseurs l'ouvrent sur leur téléphone.

## Publier

```bash
python3 scripts/iaso.py post /api/pages/ pages_payload.json
```

avec `pages_payload.json` :

```json
{
  "name": "Campaign dashboard",
  "slug": "campaign-dashboard",
  "type": "RAW",
  "needs_authentication": true,
  "content": "<the whole HTML file as one JSON string>",
  "users": [<user ids allowed to open it>]
}
```

Construire ce JSON à la main est source d'erreurs : laissez Claude lire le fichier HTML et
l'envoyer (`json.dumps` du contenu du fichier).

- Qui peut l'ouvrir : les utilisateurs listés dans `users` (**identifiants d'utilisateur**,
  `user_id` dans `GET /api/profiles/`, pas les identifiants de profil), les membres des
  rôles listés dans `user_roles`, et toutes les personnes du compte ayant la permission
  `iaso_page_write`. Les autres sont renvoyés vers la page de connexion.
- La publication nécessite la permission `iaso_page_write` et le module de compte
  **Embedded links** (`EMBEDDED_LINKS` dans `scripts/iaso.py whoami`).
- Mise à jour : lisez d'abord la page (`GET /api/pages/<id>/`) et vérifiez que `updated_at`
  et `content` n'ont pas changé depuis votre téléchargement — quelqu'un a pu la modifier
  dans l'interface web — puis `PATCH /api/pages/<id>/ {"content": "..."}`. Conservez
  l'ancien contenu dans un fichier de sauvegarde.
- La page apparaît dans l'interface web sous **Pages** et à l'adresse `<IASO_URL>/pages/<slug>/`.

## Pages typiques d'une campagne

| Page | Lit | Affiche |
|---|---|---|
| Tableau de bord de campagne (modèle fourni) | 01, 02, 03, 05 | Avancement du dénombrement et de la distribution par zone, couverture, taux de refus |
| Groupements spéciaux | 06, 07 | Groupements prévus / servis, MII |
| Stock | 10–14 (et 02) | Reçu, sorti, retourné, perdu, solde par magasin |
| Présence et paiement (modèle fourni : `attendance_payment.html`) | 08, 09 | Jours travaillés et validés par travailleur, montant dû par rôle (taux, indemnités ponctuelles, frais de mobile money), export Excel pour le paiement |
| Supervision | 15 | Résultats des fiches de supervision par zone, actions correctives |

Pour les paiements, convenez d'abord des règles par écrit (tarif journalier par rôle,
forfaits payés une seule fois, nombre maximal de jours, frais). Dans `attendance_payment.html`,
elles sont toutes dans le bloc `CONFIG` en haut de la page, pour que les finances puissent les
vérifier, et l'état de paiement Excel recalcule les montants à partir de ses onglets « Tarifs » et
« Frais mobile money » si quelqu'un y corrige un tarif. Le forfait est payé dans l'état dont la
période contient le premier jour validé du travailleur, jamais deux fois.

## Rapports dans l'application mobile

Les rapports qui fonctionnent hors ligne sur le téléphone (feature flag `REPORTS`)
fonctionnent différemment : voir `reference/mobile-reports.md`.
