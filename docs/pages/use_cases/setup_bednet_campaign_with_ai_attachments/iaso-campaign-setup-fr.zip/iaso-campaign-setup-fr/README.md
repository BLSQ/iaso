# Kit de configuration d'une campagne de distribution de MII dans IASO

Tout ce dont Claude a besoin pour configurer une campagne de distribution de moustiquaires imprégnées d'insecticide dans un
compte IASO : applications mobiles (projets), enregistrement des ménages et des groupements spéciaux,
workflows dénombrement → distribution, ménages absents ou en refus et revisites,
ménages déjà servis par la distribution de routine, enregistrement des travailleurs et présence
journalière, mouvements de stock et supervision.

Une fois les décisions de la campagne prises, une configuration prend environ 20 minutes de travail de Claude, plus
vos réponses à ses questions, et un test de chaque application sur téléphone.

Commencez par **`GUIDE.html`** (ou `GUIDE.md`) : ce que produit le kit, comment l'utiliser, la
campagne configurée et les concepts d'IASO, avec des captures d'écran.

## Contenu du kit

| Chemin | Contenu |
|---|---|
| `SKILL.md` | Le guide pas à pas que Claude suit |
| `reference/architecture.md` | Comment les applications, les entités, les workflows et le stock s'articulent |
| `reference/api.md` | Les appels à l'API IASO et les contenus de requêtes utilisés |
| `reference/pitfalls.md` | Ce qui casse les téléphones sur le terrain, et comment l'éviter — à lire |
| `templates/pyramide_modele.xlsx`, `templates/pyramide_demo.xlsx` | Unités d'organisation : modèle à remplir, et pyramide de démonstration |
| `templates/campaign.yaml` | Les décisions de la campagne à recueillir avant de commencer |
| `forms/` | 15 XLSForms d'exemple (libellés en anglais et en français), avec un catalogue dans `forms/README.md` |
| `iaso_config.txt` | Où coller votre jeton IASO (étape 1) |
| `assets/play_store_iaso_qr.png` | QR code pour installer l'application IASO depuis le Play Store |
| `scripts/iaso.py` | Petit client d'API avec des fonctions sûres de lecture-fusion-écriture et une commande de sauvegarde |
| `scripts/validate_forms.sh` | Valide les XLSForms avec pyxform avant le téléversement |
| `reference/pages.md` | Comment construire et publier des pages de rapport (tableaux de bord) dans IASO |
| `templates/pages/campaign_dashboard.html` | Une page de tableau de bord de campagne prête à configurer |
| `templates/pages/attendance_payment.html` | Page de présence et de paiement des travailleurs, avec état de paiement Excel |
| `scripts/serve_page.py` | Prévisualise une page en local avec les données réelles, en lecture seule |
| `reference/mobile-reports.md` | Rapports qui fonctionnent hors ligne dans l'application mobile : API de pont (bridge), format des données, empaquetage, publication |
| `templates/mobile_reports/` | Trois rapports mobiles prêts à adapter : avancement de la campagne (avec carte), présence de l'équipe, stock |
| `scripts/build_mobile_report.sh` | Empaquette un rapport mobile dans le zip attendu par l'application |

Les formulaires ont des libellés en anglais et en français (colonnes `label::English (en)` et
`label::French (fr)`) ; la langue est choisie dans l'application mobile.

## Avant de commencer

1. **Un compte IASO** pour la campagne, créé par un administrateur IASO (Bluesquare)
   avec l'écran **Setup a new account** (création d'un compte) d'IASO :
   - **Account name** (nom du compte), **User name** (nom d'utilisateur), prénom et nom, **Language** (langue ; English), **Email** ;
   - **Password** (mot de passe), ou cochez *Send email invitation to set password* (envoyer une invitation par e-mail pour définir le mot de passe) ;
   - **Modules** — ces quatre, plus DHIS2 mapping si la pyramide vient de DHIS2 :

     | Module | Nécessaire pour |
     |---|---|
     | Data collection - Forms | formulaires et soumissions (toujours) |
     | Entities | ménages, groupements spéciaux, travailleurs, workflows |
     | Stock management | mouvements et soldes de stock dans l'application |
     | Embedded links | pages de rapport (tableaux de bord) dans IASO |
     | DHIS2 mapping (facultatif) | importer la pyramide sanitaire depuis votre DHIS2 |

   - laissez *Create main organization unit* et *Create demo form* décochés : la campagne
     utilise sa propre pyramide sanitaire et ses propres formulaires.

   La pyramide sanitaire (régions, districts, formations sanitaires, villages) peut être importée
   par Claude pendant la configuration : depuis votre **DHIS2** (vous saisissez son adresse, son
   login et son mot de passe sur la source de données du compte dans IASO, jamais dans le chat),
   depuis un **fichier Excel** que vous remplissez (`templates/pyramide_modele.xlsx`) ou un
   **GeoPackage** (par exemple avec des contours), ou remplacée par une pyramide de démonstration
   pour essayer.

   Il vous faut aussi :
   - un utilisateur pour la configuration avec les permissions listées dans `SKILL.md` § 1. Idéalement un
     utilisateur dédié, désactivé une fois la configuration terminée.
2. **Un assistant IA capable d'exécuter du code Python et de joindre votre serveur IASO** :
   Claude ou ChatGPT dans le navigateur ou leur application, ou Claude Code (application de
   bureau ou terminal) avec Python 3 sur votre ordinateur.
3. **Les décisions de la campagne** : parcourez `templates/campaign.yaml` avec l'équipe de la campagne
   (applications nécessaires, périmètre, règle d'allocation, rôles et taux, entrepôts…).

## Étape 1 — donner à l'assistant l'accès à IASO

1. Décompressez le kit.
2. **Quel serveur IASO utilisez-vous ?** C'est l'adresse que vous ouvrez dans votre navigateur
   pour utiliser IASO. Si vous ne savez pas, prenez celle par défaut : **`https://demo.openiaso.com`**.
   Il en existe d'autres (par ex. `https://iaso.bluesquare.org`, ou celui de votre organisation).
3. Ouvrez le lien de connexion de ce serveur et connectez-vous avec l'utilisateur de configuration :
   `<adresse IASO>/login/?next=/api/apitoken/` — pour le serveur par défaut :
   **<https://demo.openiaso.com/login/?next=/api/apitoken/>**.
   Après la connexion, la page affiche `{"token": "eyJ0eXAiOiJKV1Qi…"}`.
4. Copiez la longue valeur de `token` (entre les guillemets).
5. Ouvrez `iaso_config.txt` dans le dossier du kit avec un éditeur de texte (TextEdit,
   Bloc-notes…) : mettez l'adresse du serveur après `IASO_URL=` (déjà réglée sur
   `https://demo.openiaso.com`), collez le jeton après `IASO_TOKEN=`, et enregistrez.

Claude vérifie lui-même l'accès au démarrage (`python3 scripts/iaso.py whoami`).

- Ne collez jamais le jeton dans le chat : Claude lit `iaso_config.txt` au travers des scripts.
- Le jeton donne le même accès que votre mot de passe et reste valide longtemps :
  gardez `iaso_config.txt` privé, videz-le une fois la configuration terminée, et désactivez
  l'utilisateur de configuration (ou retirez-lui ses permissions) à la fin.

## Étape 2 — lancer la configuration

Dans Claude ou ChatGPT (navigateur ou application), recompressez le dossier du kit une fois le
jeton dans `iaso_config.txt`, ouvrez une nouvelle conversation et importez le zip. Dans Claude
Code, ouvrez-le dans le dossier du kit. Envoyez ensuite ce message :

> Décompresse le kit si besoin. Lis `SKILL.md`, `reference/pitfalls.md` et `reference/architecture.md`, puis configure
> une campagne de distribution de moustiquaires dans mon compte IASO en suivant `SKILL.md` étape par étape.
> N'utilise aucun connecteur MCP IASO : uniquement les scripts du kit.
> Commence par vérifier l'accès et faire une sauvegarde, puis pose-moi les questions de la campagne de
> `templates/campaign.yaml` une section à la fois, y compris les décisions du § 2b (rapports
> mobiles par application, carte, pages web et qui y a accès, utilisateurs de test). Montre-moi les
> QR codes dès que les projets existent. Demande-moi confirmation avant chaque étape qui écrit
> dans IASO. Ne t'arrête qu'après la liste du § 12c (pages web et rapports mobiles publiés compris),
> et dis-moi à la fin ce que tu as créé et ce que je dois tester sur un téléphone.

Pour le réutiliser comme skill Claude, copiez tout le dossier dans `~/.claude/skills/iaso-net-campaign-setup/`.

## Étape 3 — tester sur les téléphones

Vous n'avez pas besoin du code de l'application mobile. Une fois les projets créés, Claude vous
présente dans le chat deux sortes de QR codes (aussi enregistrés dans `qr_codes/qr_codes.html`) :
un pour installer l'application IASO depuis le Play Store, et un par projet pour configurer l'application.
Sur un téléphone Android :

1. Scannez le QR code du Play Store avec l'appareil photo et installez **IASO** (par Bluesquare).
2. Ouvrez-la et choisissez **scanner un QR code**. Scannez le QR code du projet (aussi dans
   l'interface web IASO sous **Admin → Projects**, un QR code par application). Si le scan n'est pas
   possible, choisissez la configuration manuelle et saisissez l'URL du serveur
   (la même adresse IASO que dans `iaso_config.txt`, par ex. `https://demo.openiaso.com`) et l'`app_id` du projet.
3. Connectez-vous avec un utilisateur de test qui a ce projet et une unité d'organisation dans la zone de la campagne.
4. Pour essayer une autre application sur le même téléphone, changez l'`app_id` dans l'application.

Certaines options nécessitent une version récente de l'application (3.0.5 pour l'écran d'accueil du stock et pour
les conditions de workflow sur `_app_id`, voir `SKILL.md` § 10) : vérifiez la version affichée dans
l'application avant de les tester.

Suivez la liste de vérification de `SKILL.md` § 11 avec des utilisateurs de test, puis supprimez les données de test
avant de former les équipes de terrain.

## Étape 4 — rapports

Deux types de rapports, en général les deux :

- **Pages web IASO** pour l'équipe de coordination (`reference/pages.md`, `SKILL.md` § 12) :
  Claude les construit, les prévisualise en local avec vos données et les publie à l'adresse
  `<IASO_URL>/pages/<slug>/`, pour les utilisateurs que vous choisissez.
- **Rapports mobiles** pour les chefs d'équipe sur le terrain (`reference/mobile-reports.md`,
  `SKILL.md` § 12b) : ils fonctionnent hors ligne dans l'application, sur les données du téléphone. Claude les adapte et
  les empaquette, et les publie par l'API d'IASO (ou vous téléversez le zip dans les
  paramètres du projet dans IASO). Sur les serveurs IASO plus anciens, c'est Bluesquare qui
  le téléverse.

## Non inclus (demandez à Bluesquare)

- Une application mobile à l'image du programme (nom, icône et app id propres) : c'est un build séparé de l'application IASO.
- Le téléversement des rapports mobiles sur les serveurs IASO antérieurs à l'API de
  téléversement (admin Django d'IASO, personnel de Bluesquare), voir `reference/mobile-reports.md`.
