# Payloads de l'API IASO pour configurer une campagne

Tous les appels passent par `scripts/iaso.py` (`get`, `post`, `patch`, `put`, `delete`),
qui ajoute le jeton. `<...>` indique les valeurs à remplacer. Les identifiants sont des
entiers sauf mention contraire.

## Compte et pyramide

| Objectif | Appel |
|---|---|
| Qui suis-je, modules du compte | `GET /api/profiles/me/` (ne jamais faire de `DELETE` dessus : cela supprime l'utilisateur) |
| Types d'unité d'organisation (identifiants, profondeur, projets) | `GET /api/v2/orgunittypes/?limit=200` |
| Unités d'organisation d'un type | `GET /api/orgunits/?orgUnitTypeId=<id>&validation_status=VALID&limit=50&page=1` |
| Trouver une unité d'organisation par son nom | `GET /api/orgunits/?searches=[{"search":"<name>","validation_status":"VALID"}]&limit=20&page=1` |
| Une unité d'organisation avec ses parents | `GET /api/orgunits/<id>/` |
| Catalogue des feature flags | `GET /api/featureflags/` |

### Importer une pyramide

`scripts/iaso.py pyramid-import` (Excel/CSV/GeoPackage) et `pyramid-dhis2` le font (voir
`SKILL.md` § 3b). Les deux visent la version de source par défaut du compte :
`GET /api/profiles/me/` → `account.default_version` (`number`, `data_source.id`).

Import GeoPackage (permission `iaso_sources`), une tâche en arrière-plan :

```text
POST /api/tasks/create/importgpkg/   multipart : file=@pyramide.gpkg, data_source=<id source>,
                                     version_number=<numéro de la version par défaut>, default_valid=true,
                                     description=...
→ {"task": {"id": <id tâche>, "status": "QUEUED", ...}}
GET /api/tasks/<id tâche>/           → status QUEUED | RUNNING | SUCCESS | ERRORED, progress_message, result
```

- Format (dépôt IASO, `iaso/gpkg/README.md`) : une couche par type d'unité, nommée
  `level-{profondeur}-{nom du type}`, avec `ref` (unique, conservé comme référence source de
  l'unité), `name`, `parent_ref` facultatif (le `ref` du parent, ou `iaso:<id>` pour une unité
  existante ; vide pour une unité de premier niveau), `code`, `group_refs`, `opening_date`,
  `closed_date`, une géométrie (point ou polygone, WGS 84, peut être vide), et une table
  `groups` (`ref`, `name`), même vide.
- Les unités sont reconnues par leur `ref` dans la version : un import met à jour les unités
  qu'il a déjà créées. Les types manquants sont créés (même nom et même profondeur = même type)
  et rattachés aux projets de la source.

Import DHIS2 (permission `iaso_sources`), avec les identifiants enregistrés sur la source de
données (`GET /api/datasources/` → `credentials` : url, login, `is_valid` ; le mot de passe
n'est jamais renvoyé) :

```json
POST /api/dhis2ouimporter/
{"source_id": <id source>, "source_version_number": <numéro de la version par défaut>,
 "validate_status": true, "description": "..."}
→ {"task": {"id": <id tâche>, ...}}
```

- Tous les niveaux sont importés ; les types portent le nom des niveaux DHIS2. Avec un numéro
  de version, seules les unités DHIS2 absentes de cette version sont créées (les existantes ne
  sont pas mises à jour).

Ensuite, les types d'unités : `PATCH /api/v2/orgunittypes/<id type parent>/
{"sub_unit_type_ids": [<id type enfant>]}` enchaîne les niveaux (l'import GeoPackage ne le
fait pas).

## Projets

Création :

```json
POST /api/projects/
{
  "name": "Dénombrement (campagne MII 2027)",
  "app_id": "xx.itn2027.enum",
  "needs_authentication": true,
  "color": "#1565C0",
  "feature_flags": [
    {"id": <id>, "name": "<name>", "code": "REQUIRE_AUTHENTICATION"},
    {"id": <id>, "name": "<name>", "code": "ENTITY"}
  ]
}
```

Chaque élément de feature flag a besoin de son `id`, de son `name` et de son `code`,
obtenus via `GET /api/featureflags/`. Un `PATCH /api/projects/<id>/` avec `feature_flags`
**remplace toute la liste** : utilisez `scripts/iaso.py feature-flags <id> --add X --remove Y`.

Le code QR du projet que scannent les téléphones se trouve dans `GET /api/projects/<id>/`
→ `qr_code` (data URL PNG).

Rattacher des types d'unité d'organisation (la liste remplace la liste actuelle ; la
fonction utilitaire fusionne) :

```bash
python3 scripts/iaso.py ou-types-add-project <project_id> <type_id> ...
# = for each type: PATCH /api/v2/orgunittypes/<type_id>/ {"project_ids": [<current ids>, <project_id>]}
```

## Formulaires

Créez le formulaire, puis téléversez le XLSForm comme une version :

```json
POST /api/forms/
{
  "name": "Household registration",
  "project_ids": [<enumeration project>, <distribution project>],
  "org_unit_type_ids": [],
  "period_type": null,
  "single_per_period": false,
  "periods_before_allowed": 0,
  "periods_after_allowed": 0,
  "device_field": "deviceid",
  "location_field": ""
}
```

```bash
python3 scripts/iaso.py upload-form <form_id> forms/01_household_registration.xlsx
# = POST /api/formversions/ multipart: form_id=<id>, xls_file=@file.xlsx
```

- Le paramètre `form_id` du XLSForm doit rester identique d'une version à l'autre d'un
  même formulaire.
- Ajouter un formulaire à un autre projet : `scripts/iaso.py form-projects <form_id> --add <project_id>`.
  À la main : `PATCH /api/forms/<id>/` avec la liste `project_ids` complète **et** la liste
  `org_unit_type_ids` complète (les deux sont remplacées ; sans `org_unit_type_ids`, le serveur
  répond 500).
- Lister les versions : `GET /api/formversions/?form_id=<id>&order=-created_at`
  (`xls_file` = lien de téléchargement du XLSForm source).

## Types d'entité

```json
POST /api/entitytypes/
{
  "name": "Household",
  "account": <account id>,
  "reference_form": <form id of 01>,
  "fields_list_view": ["head_name", "id_number", "head_age"],
  "fields_detail_info_view": ["head_name", "id_number", "nets_needed", "nets_distributed", "distribution_date"],
  "fields_duplicate_search": ["qr_code"],
  "prevent_add_if_duplicate_found": true
}
```

La réponse ne contient pas l'id du nouveau type : retrouvez-le par son nom avec
`GET /api/entitytypes/`.

`PATCH /api/entitytypes/<id>/` écrase toutes les listes `fields_*` : utilisez
`scripts/iaso.py entity-type-update <id> '{"fields_list_view": [...]}'`, qui renvoie le
reste inchangé.

Ce que verront les téléphones : `GET /api/mobile/entitytypes/?app_id=<app_id>`.

## Workflows

```text
1. POST /api/workflowversions/                      {"entity_type_id": <id>, "name": "v1"}
   → {"version_id": <wv>, "status": "DRAFT", ...}
2. POST /api/workflowfollowups/?version_id=<wv>      {"order": 0, "condition": <JSONLogic or true>, "form_ids": [<form id>]}
3. POST /api/workflowchanges/?version_id=<wv>        {"form": <follow-up form id>, "mapping": {"<form field>": "<entity field>"}}
4. PATCH /api/workflowversions/<wv>/                 {"status": "PUBLISHED"}
```

- `condition` est un objet JSON (JSONLogic) ou `true`. Les valeurs comparées sont les
  valeurs de l'entité sous forme de chaînes : comparez les nombres sous la forme `"0"`,
  pas `0`.
- Modifier les suivis : `POST /api/workflowfollowups/bulkupdate/` avec
  `[{"id": <followup id>, "condition": ..., "form_ids": [...], "order": 0}]`.
- Seules les versions DRAFT acceptent des modifications. Pour modifier une version publiée :
  `POST /api/workflowversions/<wv>/copy` → nouvelle version DRAFT → modification →
  publication. Publier une version dépublie l'autre version publiée du même type d'entité.
- Transitions de statut : DRAFT → PUBLISHED ou UNPUBLISHED ; UNPUBLISHED → PUBLISHED ;
  PUBLISHED → UNPUBLISHED.
- Inspecter : `GET /api/workflowversions/<wv>/`, `GET /api/workflowchanges/?version_id=<wv>`,
  et tel que le voit un téléphone : `GET /api/mobile/workflows/?app_id=<app_id>`.

## Stock

```json
POST /api/stockkeepingunits/
{"name": "Nets", "short_name": "nets", "display_unit": "nets", "display_precision": 1,
 "projects": [<stock project>], "org_unit_types": [<type ids where stock is held>],
 "forms": [<stock form ids>]}

POST /api/stockrulesversions/   {"name": "v1"}            → {"name": "v1", "status": "DRAFT"} (pas d'id dans la réponse : prenez la version DRAFT dans GET /api/stockrulesversions/)
POST /api/stockitemrules/       {"version": <rv>, "sku": <sku id>, "form": <form id>,
                                 "question": "rec_total_nets", "impact": "ADD", "order": 0}
PATCH /api/stockrulesversions/<rv>/   {"status": "PUBLISHED"}
```

`impact` vaut `ADD`, `SUBTRACT` ou `RESET` (inventaire). La question doit être un champ
du formulaire dont la valeur est la quantité.

## Utilisateurs

```json
POST /api/profiles/
{
  "user_name": "enum_agent_001",
  "password": "<generated, stored locally, never in chat>",
  "first_name": "...", "last_name": "...",
  "language": "en",
  "org_units": [<org unit id where the agent works>],
  "projects": [<project ids>],
  "user_permissions": ["iaso_entities"]
}
```

`iaso_entities` est obligatoire pour les utilisateurs de tout projet qui a le feature flag `ENTITY` ;
ne laissez la liste vide que pour les utilisateurs de projets sans entités (par ex. supervision).

Modifier les projets ou les unités d'organisation d'un utilisateur existant :
`PATCH /api/profiles/<profile id>/` avec les listes `projects` / `org_units` complètes.
Pour des dizaines d'utilisateurs, préférez l'import CSV de l'interface web (Users →
Import CSV), que l'administrateur du compte peut lancer.

## Soumissions et entités (vérifications, nettoyage)

| Objectif | Appel |
|---|---|
| Soumissions d'un formulaire | `GET /api/instances/?form_ids=<id>&limit=100` |
| Idem, en Parquet pour les tableaux de bord | `GET /api/instances/?form_ids=<id>&parquet=true` |
| Soumissions d'une entité | `GET /api/instances/?entityId=<entity id>` |
| Trouver une entité par uuid ou par nom | `GET /api/entities/?search=<text>` |
| Supprimer une entité de test (suppression logique, avec ses soumissions, tracée) | `DELETE /api/entities/<id>/` |

## Rapports mobiles — détails dans `reference/mobile-reports.md`

Utilisez `scripts/iaso.py mobile-report-upload|mobile-report-versions|mobile-report-publish`
plutôt que ces appels à la main. Permission *Rapports* (`iaso_reports`) ; la première version d'IASO publiée après le 28 octobre 2026 (BLSQ/iaso#3471).

| Action | Appel |
|---|---|
| Rapport d'un projet | `GET /api/reports/?project=<project id>` (une liste, vide ou avec un rapport) |
| Le créer avec sa première version, publiée | `POST /api/reports/` multipart : `project`, `name`, `version_name`, `file` (le zip) |
| Ajouter une version | `POST /api/reports/<id>/versions/` multipart : `name`, `publish` (`true`/`false`), `file` |
| Lister les versions | `GET /api/reports/<id>/versions/` (la plus récente d'abord, avec `status`) |
| Publier une version précédente | `POST /api/reports/<id>/publish/ {"version_id": <id>}` |
| Ce que les téléphones téléchargent | `GET /api/mobile/reports/?app_id=<app_id>` |

Un second `POST /api/reports/` pour le même projet est refusé (400, avec l'id du rapport
existant). Sans l'API de téléversement, `GET /api/reports/0/publish/` répond 404 au lieu
de 405 : le serveur est trop ancien.

## Pages (tableaux de bord) — détails dans `reference/pages.md`

```json
POST /api/pages/
{"name": "Campaign dashboard", "slug": "campaign-dashboard", "type": "RAW",
 "content": "<full HTML>", "needs_authentication": true, "users": [<user ids>]}
```

Mise à jour avec `PATCH /api/pages/<id>/ {"content": "..."}` ; lisez d'abord la page et
vérifiez que personne ne l'a modifiée depuis votre téléchargement. Servie à l'adresse
`<IASO_URL>/pages/<slug>/`.
