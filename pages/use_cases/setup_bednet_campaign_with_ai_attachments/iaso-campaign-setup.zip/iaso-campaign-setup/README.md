# IASO net campaign setup kit

Everything Claude needs to configure an insecticide-treated net distribution campaign in an
IASO account: mobile apps (projects), household and special-group registration,
enumeration → distribution workflows, absent/refusing households and revisits,
households already served by routine distribution, worker registration and daily
attendance, stock movements and supervision.

With the campaign decisions made, a setup takes about 20 minutes of Claude's work plus
your answers to its questions, and a phone test of each app.

Start with **`GUIDE.html`** (or `GUIDE.md`): what the kit produces, how to use it, the campaign
it sets up and the IASO concepts, with screenshots.

## What is in the kit

| Path | Content |
|---|---|
| `SKILL.md` | The step-by-step runbook Claude follows |
| `reference/architecture.md` | How apps, entities, workflows and stock fit together |
| `reference/api.md` | The IASO API calls and payloads used |
| `reference/pitfalls.md` | What breaks phones in the field, and how to avoid it — read it |
| `templates/pyramid_template.xlsx`, `templates/pyramid_demo.xlsx` | Org units: template to fill in, and a demo pyramid |
| `templates/campaign.yaml` | The campaign decisions to collect before starting |
| `forms/` | 15 example XLSForms with English and French labels, with a catalog in `forms/README.md` |
| `iaso_config.txt` | Where you paste your IASO token (step 1) |
| `assets/play_store_iaso_qr.png` | QR code to install the IASO app from the Play Store |
| `assets/test_qr_codes.png` | Test QR codes (household tickets, nets, bales) to try the apps without real ones |
| `scripts/iaso.py` | Small API client with safe read-merge-write helpers and a backup command |
| `scripts/validate_forms.sh` | Validates XLSForms with pyxform before upload |
| `reference/pages.md` | How to build and publish report pages (dashboards) in IASO |
| `templates/pages/campaign_dashboard.html` | A ready-to-configure campaign dashboard page |
| `templates/pages/attendance_payment.html` | Worker attendance and payment page, with Excel payment sheet |
| `templates/pages/stock_by_region.html` | Stock movements and balance by region, district or facility |
| `scripts/serve_page.py` | Checks a page before publishing (`--check`, no browser needed), or previews it locally with the real data, read-only |
| `reference/mobile-reports.md` | Reports that run offline inside the mobile app: bridge API, data format, packaging, publishing |
| `templates/mobile_reports/` | Three mobile reports ready to adapt: campaign progress (with map), team attendance, stock |
| `scripts/build_mobile_report.sh` | Packages a mobile report into the zip the app expects |

## Before you start

1. **An IASO account** for the campaign, created by an IASO administrator (Bluesquare)
   with the **Setup a new account** screen of IASO:
   - **Account name**, **User name**, first and last name, **Language** (English), **Email**;
   - **Password**, or tick *Send email invitation to set password*;
   - **Modules** — these four, plus DHIS2 mapping if the pyramid comes from DHIS2:

     | Module | Needed for |
     |---|---|
     | Data collection - Forms | forms and submissions (always) |
     | Entities | households, special groups, workers, workflows |
     | Stock management | stock movements and balances in the app |
     | Embedded links | report pages (dashboards) in IASO |
     | DHIS2 mapping (optional) | importing the health pyramid from your DHIS2 |

   - leave *Create main organization unit* and *Create demo form* unticked: the campaign
     uses its own health pyramid and its own forms.

   The health pyramid (regions, districts, facilities, villages) can be imported by Claude
   during the setup: from your **DHIS2** (you enter its address, login and password on the
   account's data source in IASO, never in the chat), from an **Excel file** you fill in
   (`templates/pyramid_template.xlsx`) or a **GeoPackage** (for example with boundaries), or
   replaced by a demo pyramid to try things out.

   You also need:
   - a user for the setup with the permissions listed in `SKILL.md` § 1. Ideally a
     dedicated user, deactivated once the setup is done.
2. **An AI assistant that can run Python code and reach your IASO server**: Claude or ChatGPT
   in the browser or their app, or Claude Code (desktop app or terminal) with Python 3 on your
   computer.

   **Check this before you start, it can block you.** In Claude or ChatGPT in the browser or
   their app, the scripts only reach the domains allowed in the assistant's settings. To test,
   use **`app.openiaso.com`**. Any other IASO server (a staging server such as
   `app-staging.openiaso.com`, your organisation's own server…) must be added to the allowed
   domains first, and on Claude Team and Enterprise plans only an organisation owner can do it
   (see Step 1). Claude Code on your computer has no such limit.
3. **The campaign decisions**: go through `templates/campaign.yaml` with the campaign team
   (apps needed, scope, allocation rule, roles and rates, warehouses…).

## Step 1 — give the assistant access to IASO

1. Unzip the kit.
2. **Which IASO server do you use?** It is the address you open in your browser to use IASO.
   If you do not know, use the default: **`https://app.openiaso.com`**. Other servers exist
   (e.g. `https://iaso.bluesquare.org`, or your organisation's own).
3. Open the login link of that server and log in with the setup user:
   `<IASO address>/login/?next=/api/apitoken/` — for the default server:
   **<https://app.openiaso.com/login/?next=/api/apitoken/>**.
   After login the page shows `{"token": "eyJ0eXAiOiJKV1Qi…"}`.
4. Copy the long value of `token` (between the quotes).
5. Open `iaso_config.txt` in the kit folder with a text editor (TextEdit, Notepad…):
   put the server address after `IASO_URL=` (already set to `https://app.openiaso.com`),
   paste the token after `IASO_TOKEN=`, and save.
6. **Zip the kit folder again** (Claude or ChatGPT in the browser or the app): the assistant
   receives the zip, so it must contain the filled `iaso_config.txt`. Do not share this zip: it
   contains your token. Not needed in Claude Code, which reads the folder.

Claude checks the access itself when it starts (`python3 scripts/iaso.py whoami`).

- Never paste the token into the chat: Claude reads `iaso_config.txt` through the scripts.
- The token gives the same access as your password and stays valid for a long time:
  keep `iaso_config.txt` private, empty it when the setup is done, and deactivate the
  setup user (or change its permissions) at the end.
- **In Claude in the browser or the app**, the scripts only reach allowed domains: add exactly
  your IASO domain (e.g. `app.openiaso.com`) in *Settings → Capabilities*; on Team and Enterprise
  plans, ask an organisation owner (*Organization settings → Capabilities*). `GUIDE.md`, step 1,
  has a ready-to-send message. Without it the scripts say "Name or service not known".

## Step 2 — run the setup

In Claude or ChatGPT (browser or app), start a new conversation and import the zip of Step 1.
In Claude Code, open it in the kit folder. Then choose your path for the geographic data (org
units):

- **Demo**: nothing to prepare. Claude uses the kit's demo pyramid and proposes placeholder
  answers for everything in one summary. Best to discover the kit.
- **Your own data**: your org units come from DHIS2 (settings entered in IASO first), an Excel
  or GeoPackage file you attach to the conversation, or are already in IASO. Claude asks the
  campaign questions one by one.

The ready-to-copy messages for each path are in `GUIDE.md`, step 3. For a demo:

> Here is a kit to set up a net distribution campaign in IASO. Unzip it if needed, read
> `SKILL.md` and follow it step by step to guide me. Use only the kit's scripts, no IASO
> connector. This is a demo: use the kit's demo pyramid and propose placeholder answers for
> everything in one summary (demo mode). Confirm with me before each step that writes to IASO,
> and do not stop before the checklist of § 12c.

To reuse it as a Claude skill, copy the whole folder to `~/.claude/skills/iaso-net-campaign-setup/`.

## Step 3 — test on phones

You do not need the code of the mobile app. At the end of the setup, once every app is fully
configured (forms, workflows, stock, users and reports), Claude shows you in the chat two kinds of QR codes (also saved
in `qr_codes/qr_codes.html`): one to install the IASO app from the Play Store, and one per
project to configure the app. It also shows `assets/test_qr_codes.png`, fake household tickets,
nets and bales to scan during the test (print it or scan it from your screen).
On an Android phone:

1. Scan the Play Store QR code with the camera and install **IASO** (by Bluesquare).
2. Open it and choose **scan a QR code**. Scan the QR code of the project (also in the
   IASO web interface under **Admin → Projects**, one QR code per app). If scanning is not
   possible, choose manual configuration and type the server URL
   (the same IASO address as in `iaso_config.txt`, e.g. `https://app.openiaso.com`) and the project's `app_id`.
3. Log in with your own account or a test user who has that project and an org unit in the
   campaign area. **Testing is easier when your account has several campaign projects**: the
   app then lets you switch between them on one phone (multi-project mode). In demo mode Claude
   adds them to your account; with your own data it asks you. If your account cannot be
   changed by the setup user, ask your IASO administrator to add the projects.
4. To try another app on the same phone, switch project in the app (or change the `app_id`).

Some options need a recent version of the app (3.0.5 for the stock home screen and for
workflow conditions on `_app_id`, see `SKILL.md` § 10): check the version shown in the
app before testing them.

A new campaign has no data, so many screens of the app are empty at first. Claude then proposes a
**guided test of every app** (`SKILL.md` § 11a): a few minutes to register households with the test
tickets, distribute nets, register a special group and a worker, and record stock, so that every
screen and report shows something. Then follow the checklist of `SKILL.md` § 11, and delete the
test data before training the field teams.

## Step 4 — reports

Two kinds of reports, usually both:

- **Web pages in IASO** for the coordination team (`reference/pages.md`, `SKILL.md` § 12):
  the assistant builds them, checks them with your data and publishes them at
  `<IASO_URL>/pages/<slug>/`, for the users you choose.
- **Mobile reports** for team leaders in the field (`reference/mobile-reports.md`,
  `SKILL.md` § 12b): they run offline in the app on the phone's data. Claude adapts and
  packages them, and publishes them with the IASO API (or you upload the zip in the
  project settings of IASO). Older IASO servers need Bluesquare to upload it.

## Not included (ask Bluesquare)

- A branded mobile app (own name, icon and app id): it is a separate build of the IASO app.
- Uploading mobile reports on IASO servers older than the upload API (IASO Django admin,
  Bluesquare staff), see `reference/mobile-reports.md`.
