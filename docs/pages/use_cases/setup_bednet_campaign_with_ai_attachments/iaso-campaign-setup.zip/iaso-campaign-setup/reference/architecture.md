# How the campaign fits together

```text
                 ┌──────────────── Enumeration app ────────────────┐
 QR ticket ──►   │ search by QR ─► Household (01) ──follow-up──► Distribution (02)
                 │ Household absent/refused (03) ──follow-up──► Revisit (04)
                 │ Household served by routine (05)              │
                 └────────────────────────────────────────────────┘
                 ┌──────────────── Distribution app ───────────────┐
                 │ search (no creation) ─► Household ─► Distribution (02)
                 │                      ─► Special group ─► Group distribution (07)
                 └────────────────────────────────────────────────┘
                 ┌── Special groups app ──┐  ┌── Workers app ─────────────────────┐
                 │ Special group (06)     │  │ Worker (08) ─follow-up─► Attendance (09)
                 │   └► Group distrib (07)│  └────────────────────────────────────┘
                 └────────────────────────┘
                 ┌── Stock app ───────────────────────────────────┐
                 │ Receipt (10) +  Issue (11) −  Return (12) +      │──► stock balance
                 │ Transfer (13) −  Loss (14) −                     │    per org unit
                 └────────────────────────────────────────────────┘
                 ┌── Supervision app ──┐
                 │ Checklist (15)      │
                 └─────────────────────┘
```

## Entities and workflows

An **entity** is a household, a special group or a worker. It is created by its
**reference form** and later updated by **follow-up forms**, through the entity type's
**workflow**:

- the follow-up's **condition** (JSONLogic on the entity's values) decides when the app
  proposes it — e.g. distribution only while `nets_distributed` is `"0"`;
- the follow-up form receives the entity's values for the fields with the same names;
- the workflow's **changes** copy follow-up answers back into the entity —
  e.g. `nets_given → nets_distributed`, which closes the distribution.

## Why separate apps

Each project is a separate configuration on the phone: its own forms, entities, feature
flags and download area. Splitting by role keeps each agent's phone light and prevents
mistakes (a distribution agent cannot create households; a stock manager lands directly
on the stock screen). One phone can hold several projects; the user switches between them.

## Data flow for dashboards

Every submission is available as Parquet: `GET /api/instances/?form_ids=<id>&parquet=true`.
Dashboards join enumeration (01, 03, 05), distribution (02, 07), groups (06), stock (10–14)
and attendance (08, 09) by entity id and org unit.
