#!/usr/bin/env bash
# Packages a mobile report folder into the zip the IASO app expects:
# index.html at the root of the zip, plus any file it uses (JS, CSS, images).
# Usage: scripts/build_mobile_report.sh templates/mobile_reports/campaign_progress [out.zip]
set -euo pipefail
dir="${1:?folder containing index.html}"
out="${2:-$(basename "$dir").zip}"
[ -f "$dir/index.html" ] || { echo "No index.html in $dir" >&2; exit 1; }

# The report runs offline on the phone: resources loaded from the internet will be missing.
if grep -nE "<(script|link)[^>]+(src|href)=\"https?://" "$dir"/*.html; then
  echo "WARNING: the lines above load files from the internet; copy them into $dir instead." >&2
fi

out="$(cd "$(dirname "$out")" && pwd)/$(basename "$out")"
rm -f "$out"
(cd "$dir" && zip -qr "$out" . -x '.*' -x '__MACOSX/*')
echo "Built $out:"
unzip -Z1 "$out" | sed 's/^/  /'
