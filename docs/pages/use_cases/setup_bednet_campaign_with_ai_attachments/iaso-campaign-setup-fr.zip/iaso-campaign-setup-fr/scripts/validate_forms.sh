#!/usr/bin/env bash
# Validates every XLSForm of a folder with pyxform 2.0.x (installed in .venv on first run).
# Usage: scripts/validate_forms.sh [folder]   (default: forms)
set -euo pipefail
folder="${1:-forms}"
venv="$(dirname "$0")/../.venv"

if [ ! -x "$venv/bin/python" ]; then
  # pyxform does not run on the newest Python versions: pick 3.12 or 3.11 when available.
  py="$(command -v python3.12 || command -v python3.11 || command -v python3)"
  "$py" -m venv "$venv"
  "$venv/bin/pip" install -q "pyxform==2.0.3"
fi

out="$(mktemp -d)"
status=0
for f in "$folder"/*.xlsx; do
  if "$venv/bin/python" -m pyxform.xls2xform "$f" "$out/$(basename "${f%.xlsx}").xml" >"$out/log" 2>&1; then
    echo "OK    $f"
  else
    echo "ERROR $f"; sed 's/^/      /' "$out/log"; status=1
  fi
done
rm -rf "$out"
exit $status
