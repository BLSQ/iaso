#!/usr/bin/env python3
"""Small IASO API client for campaign setup. Standard library only.

Reads IASO_URL and IASO_TOKEN from iaso_config.txt at the root of the kit (see
README.md, step 1). It never prints the token.

Usage:
    python3 scripts/iaso.py whoami
    python3 scripts/iaso.py get /api/projects/
    python3 scripts/iaso.py post /api/projects/ payload.json      # or an inline JSON string
    python3 scripts/iaso.py patch /api/entitytypes/12/ '{"fields_list_view": ["head_name"]}'
    python3 scripts/iaso.py upload-form <form_id> forms/01_household_registration.xlsx
    python3 scripts/iaso.py feature-flags <project_id> --add ENTITY REPORTS --remove MOBILE_ENTITY_LIMITED_SEARCH
    python3 scripts/iaso.py ou-types-add-project <project_id> <org_unit_type_id> [...]
    python3 scripts/iaso.py form-projects <form_id> --add <project_id> [...] [--remove <project_id> ...]
    python3 scripts/iaso.py users-check            # projects, org units and iaso_entities of every user
    python3 scripts/iaso.py entity-type-update <entity_type_id> '{"fields_duplicate_search": ["qr_code"]}'
    python3 scripts/iaso.py backup backups/            # snapshot of the account configuration
    python3 scripts/iaso.py pyramid-import pyramid.xlsx|.csv|.gpkg [--apply]   # pyramid through a GeoPackage (dry run by default)
    python3 scripts/iaso.py pyramid-dhis2 [--apply]   # pyramid from DHIS2 (credentials set on the data source in IASO)
    python3 scripts/iaso.py qr-codes [project_id|app_id ...] [--out qr_codes]   # QR codes to set up phones
    python3 scripts/iaso.py mobile-report-upload <app_id> report.zip [--name "Campaign progress"] [--version v2] [--no-publish]
    python3 scripts/iaso.py mobile-report-versions <app_id>
    python3 scripts/iaso.py mobile-report-publish <app_id> <version_id>   # roll back to an earlier version

The safe commands (feature-flags, ou-types-add-project, form-projects, entity-type-update) read
the current object, change only what is asked and write it back whole: the API
replaces lists and fields wholesale, so a partial payload would wipe the rest.
"""

import datetime
import json
import os
import pathlib
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid


CONFIG = pathlib.Path(__file__).resolve().parent.parent / "iaso_config.txt"
LANG = "fr"  # language of the qr_codes.html page


def _env():
    env = {}
    # iaso_config.txt, filled in with a text editor: in the current folder or at the root of the kit.
    path = next((p for p in (pathlib.Path("iaso_config.txt"), CONFIG) if p.exists()), None)
    if path is None:
        sys.exit(f"iaso_config.txt not found (expected in {CONFIG.parent}). See README.md, step 1.")
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env.setdefault(k.strip(), v.strip())
    url = (env.get("IASO_URL") or "https://demo.openiaso.com").strip('"').strip("'")
    token = env.get("IASO_TOKEN") or ""
    # Accept what people paste from /api/apitoken/: the whole {"token": "..."} or "Bearer ...".
    if '"token"' in token:
        try:
            token = json.loads(token if token.startswith("{") else "{" + token + "}")["token"]
        except ValueError:
            pass
    token = token.strip().strip('"').strip("'").removeprefix("Bearer ").strip()
    if not token:
        login = url.strip('"').rstrip("/") + "/login/?next=/api/apitoken/"
        sys.exit(f"IASO_TOKEN missing: open {login} , log in, copy the token "
                 "and paste it after IASO_TOKEN= in iaso_config.txt (see README.md, step 1).")
    return url.rstrip("/").removesuffix("/api/apitoken").removesuffix("/dashboard"), token


BASE, TOKEN = _env()


def call(method, path, payload=None, raw=None, content_type="application/json", allow=()):
    """One API call. Returns the parsed JSON (or None for an empty body); exits on HTTP errors,
    except the status codes listed in `allow`, returned as the int."""
    url = path if path.startswith("http") else BASE + path
    # Spaces and accents in search terms would make the request invalid: encode them.
    url = urllib.parse.quote(url, safe=":/?&=,;[]{}\"'%+@!$()*~#")
    data = raw if raw is not None else (json.dumps(payload).encode() if payload is not None else None)
    headers = {"Authorization": "Bearer " + TOKEN, "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = content_type
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read()
    except urllib.error.HTTPError as e:
        if e.code in allow:
            return e.code
        sys.exit(f"{method} {path} -> HTTP {e.code}: {e.read()[:2000].decode(errors='replace')}")
    except urllib.error.URLError as e:
        sys.exit(f"Cannot reach the IASO server {BASE} ({e.reason}): check IASO_URL in iaso_config.txt "
                 "and the network connection.")
    if not body:
        return None
    try:
        return json.loads(body)
    except ValueError:
        return body.decode(errors="replace")


get = lambda p: call("GET", p)  # noqa: E731


def results(data, *keys):
    """Unwraps the list out of the various paginated shapes of the IASO API."""
    if isinstance(data, list):
        return data
    for k in keys + ("results",):
        if isinstance(data, dict) and k in data:
            return data[k]
    return data


def _payload(arg):
    if arg is None:
        return None
    p = pathlib.Path(arg)
    return json.loads(p.read_text()) if p.exists() else json.loads(arg)


def post_multipart(path, fields, file_field, file_path, file_type):
    boundary = uuid.uuid4().hex
    body = b"".join(
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
        for k, v in fields.items()
    )
    body += (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; "
        f"filename=\"{pathlib.Path(file_path).name}\"\r\nContent-Type: {file_type}\r\n\r\n"
    ).encode() + pathlib.Path(file_path).read_bytes() + f"\r\n--{boundary}--\r\n".encode()
    return call("POST", path, raw=body, content_type=f"multipart/form-data; boundary={boundary}")


def upload_form_version(form_id, xlsx):
    return post_multipart("/api/formversions/", {"form_id": form_id}, "xls_file", xlsx,
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def _report_project(app_id):
    """The project of `app_id` and its mobile report (None if it has none yet)."""
    project = next((p for p in results(get("/api/projects/"), "projects") if p["app_id"] == app_id), None)
    if project is None:
        sys.exit(f"No project with app_id {app_id} in this account.")
    # The upload API answers 405 to a GET on this POST-only route; older servers don't have the route (404).
    if call("GET", "/api/reports/0/publish/", allow=(404, 405)) != 405:
        sys.exit("This IASO server is too old for the mobile report upload API: ask a Bluesquare "
                 "administrator to publish the zip from the Django admin (see reference/mobile-reports.md).")
    reports = results(get(f"/api/reports/?project={project['id']}"), "result")
    return project, (reports[0] if reports else None)


def mobile_report_upload(app_id, zip_path, name=None, version=None, publish=True):
    import zipfile
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
    except (OSError, zipfile.BadZipFile) as e:
        sys.exit(f"{zip_path} is not a zip file ({e}).")
    if "index.html" not in names:
        sys.exit(f"{zip_path} has no index.html at its root: package it with scripts/build_mobile_report.sh.")
    project, report = _report_project(app_id)
    version = version or datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    if report is None:
        report = post_multipart("/api/reports/", {"project": project["id"], "name": name or "Report",
                                                  "version_name": version}, "file", zip_path, "application/zip")
        print(f"project {app_id}: report {report['id']} created, version {report['published_version_id']} "
              f"({version}) published")
    else:
        v = post_multipart(f"/api/reports/{report['id']}/versions/",
                           {"name": version, "publish": "true" if publish else "false"},
                           "file", zip_path, "application/zip")
        print(f"project {app_id}: report {report['id']}, new version {v['id']} ({version}) "
              + ("published" if publish else "uploaded, not published"))
    if "REPORTS" not in [f["code"] for f in project["feature_flags"]]:
        print(f"warning: project {app_id} does not have the REPORTS feature flag: the app will not show the report "
              f"(scripts/iaso.py feature-flags {project['id']} --add REPORTS).")


def mobile_report_versions(app_id):
    _, report = _report_project(app_id)
    if report is None:
        sys.exit(f"Project {app_id} has no mobile report.")
    print(f"report {report['id']} ({report['name']}), published version {report['published_version_id']}")
    for v in get(f"/api/reports/{report['id']}/versions/"):
        print(f"  {v['id']:>6}  {v['status']:<11}  {v['created_at'][:16]}  {v['name']}")


def mobile_report_publish(app_id, version_id):
    _, report = _report_project(app_id)
    if report is None:
        sys.exit(f"Project {app_id} has no mobile report.")
    r = call("POST", f"/api/reports/{report['id']}/publish/", {"version_id": int(version_id)})
    print(f"project {app_id}: report {r['id']} now serves version {r['published_version_id']} ({r['published_version']})")


def feature_flags(project_id, add=(), remove=()):
    project = get(f"/api/projects/{project_id}/")
    catalog = {f["code"]: f for f in results(get("/api/featureflags/"), "featureflags")}
    unknown = [c for c in list(add) + list(remove) if c not in catalog]
    if unknown:
        # e.g. MOBILE_STOCK_HOME is not on every server: the app then simply opens on its usual home.
        print(f"warning: feature flags not on this server, skipped: {unknown}")
        add = [c for c in add if c in catalog]
    codes = [f["code"] for f in project["feature_flags"]]
    codes = [c for c in codes if c not in remove] + [c for c in add if c not in codes]
    items = []
    for c in codes:
        current = next((f for f in project["feature_flags"] if f["code"] == c), None)
        items.append({"id": catalog[c]["id"], "name": catalog[c]["name"], "code": c,
                      "description": catalog[c].get("description") or "",
                      "configuration": (current or {}).get("configuration") or {}})
    call("PATCH", f"/api/projects/{project_id}/", {"feature_flags": items})
    after = sorted(f["code"] for f in get(f"/api/projects/{project_id}/")["feature_flags"])
    print(f"project {project_id} feature flags: {after}")


def ou_types_add_project(project_id, type_ids):
    for tid in type_ids:
        t = get(f"/api/v2/orgunittypes/{tid}/")
        ids = sorted({p["id"] for p in t["projects"]} | {int(project_id)})
        call("PATCH", f"/api/v2/orgunittypes/{tid}/", {"project_ids": ids})
        print(f"org unit type {tid} ({t['name']}): projects {ids}")


def form_projects(form_id, add=(), remove=()):
    form = get(f"/api/forms/{form_id}/")
    ids = [p["id"] for p in form["projects"] if str(p["id"]) not in remove]
    ids += [int(p) for p in add if int(p) not in ids]
    # PATCH needs org_unit_type_ids too (HTTP 500 without it), and replaces it: send the current list.
    call("PATCH", f"/api/forms/{form_id}/", {"project_ids": ids,
                                             "org_unit_type_ids": [t["id"] for t in form.get("org_unit_types") or []]})
    after = get(f"/api/forms/{form_id}/")
    print(f"form {form_id} ({after['name']}): projects {sorted(p['id'] for p in after['projects'])}")


def users_check():
    """Every user with their projects and org units; flags users of ENTITY projects without iaso_entities."""
    projects = {p["id"]: p for p in results(get("/api/projects/"), "projects")}
    entity_projects = {pid for pid, p in projects.items() if "ENTITY" in [f["code"] for f in p["feature_flags"]]}
    problems = 0
    # The list does not include permissions: read each profile.
    for row in results(get("/api/profiles/?limit=500&fields=:all"), "profiles", "results"):
        p = get(f"/api/profiles/{row['id']}/")
        pids = [x["id"] for x in p.get("projects") or []]
        perms = set(p.get("user_permissions") or []) | set(p.get("permissions") or [])
        missing = bool(set(pids) & entity_projects) and "iaso_entities" not in perms and not p.get("is_superuser")
        problems += missing
        print(f"{p['user_name']:<28} projects {[projects[i]['name'] for i in pids if i in projects]}  "
              f"org units {[o['name'] for o in p.get('org_units') or []]}"
              + ("  <- MISSING iaso_entities" if missing else ""))
    print(f"{problems} user(s) without iaso_entities on an ENTITY project")


ENTITY_TYPE_FIELDS = ["name", "reference_form", "fields_list_view", "fields_detail_info_view",
                      "fields_duplicate_search", "prevent_add_if_duplicate_found"]


def entity_type_update(et_id, changes):
    t = get(f"/api/entitytypes/{et_id}/")
    body = {k: t.get(k) for k in ENTITY_TYPE_FIELDS}
    if isinstance(body["reference_form"], dict):
        body["reference_form"] = body["reference_form"]["id"]
    body.update(changes)
    call("PATCH", f"/api/entitytypes/{et_id}/", body)
    after = get(f"/api/entitytypes/{et_id}/")
    print(json.dumps({k: after.get(k) for k in ENTITY_TYPE_FIELDS[2:]}, indent=1, ensure_ascii=False))


def backup(folder):
    out = pathlib.Path(folder) / datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    snapshot = {
        "projects": "/api/projects/",
        "forms": "/api/forms/?limit=1000&fields=id,name,form_id,projects,org_unit_type_ids,latest_form_version",
        "entity_types": "/api/entitytypes/",
        "org_unit_types": "/api/v2/orgunittypes/?limit=200",
        "workflow_versions": "/api/workflowversions/?limit=500",
        "stock_keeping_units": "/api/stockkeepingunits/?limit=200",
        "stock_rules_versions": "/api/stockrulesversions/?limit=200",
        "pages": "/api/pages/?limit=200",
    }
    for name, path in snapshot.items():
        (out / f"{name}.json").write_text(json.dumps(get(path), indent=1, ensure_ascii=False))
    for wv in results(get("/api/workflowversions/?limit=500"), "workflow_versions"):
        vid = wv.get("version_id") or wv.get("id")
        detail = get(f"/api/workflowversions/{vid}/")
        detail["changes"] = get(f"/api/workflowchanges/?version_id={vid}")
        (out / f"workflow_version_{vid}.json").write_text(json.dumps(detail, indent=1, ensure_ascii=False))
    print(f"backup written to {out}")



# --------------------------------------------------------------------------- pyramid

def read_table(path):
    """Rows of the first sheet of an .xlsx (standard library only) or of a .csv, as lists of strings."""
    import csv
    import io
    import re
    import zipfile
    import xml.etree.ElementTree as ET
    path = pathlib.Path(path)
    if path.suffix.lower() == ".csv":
        text = path.read_text(encoding="utf-8-sig")
        dialect = csv.Sniffer().sniff(text[:2000], delimiters=",;\t")
        return [[c.strip() for c in row] for row in csv.reader(io.StringIO(text), dialect)]
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
        # First sheet in workbook order.
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rid = wb.find("m:sheets/m:sheet", ns).get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        target = next(r.get("Target") for r in rels if r.get("Id") == rid)
        sheet = ET.fromstring(z.read("xl/" + target.lstrip("/").removeprefix("xl/")))
    rows = []
    for row in sheet.iter("{%s}row" % ns["m"]):
        cells = {}
        for c in row.findall("m:c", ns):
            col = 0
            for ch in re.match(r"[A-Z]+", c.get("r")).group(0):
                col = col * 26 + ord(ch) - 64
            t, v = c.get("t"), c.find("m:v", ns)
            if t == "s" and v is not None:
                value = shared[int(v.text)]
            elif t == "inlineStr":
                value = "".join(x.text or "" for x in c.iter("{%s}t" % ns["m"]))
            else:
                value = v.text if v is not None else ""
                if value and re.fullmatch(r"-?\d+\.0", value):
                    value = value[:-2]
            cells[col - 1] = (value or "").strip()
        if cells:
            rows.append([cells.get(i, "") for i in range(max(cells) + 1)])
    return rows


SPECIAL = {"latitude": "lat", "lat": "lat", "longitude": "lon", "lon": "lon", "lng": "lon", "code": "code"}


def read_pyramid_table(path):
    """Levels and org units of an Excel/CSV pyramid file.

    One row per lowest-level unit; one column per level, top to bottom (e.g. Country,
    Region, District, Health facility, Village); optional columns latitude, longitude
    and code, which apply to the deepest unit of the row.
    Returns (level names, {(depth, path tuple): {"name", "lat", "lon", "code"}}).
    """
    rows = [r for r in read_table(path) if any(r)]
    header = rows[0]
    levels = [(i, h) for i, h in enumerate(header) if h and h.lower() not in SPECIAL]
    extra = {SPECIAL[h.lower()]: i for i, h in enumerate(header) if h and h.lower() in SPECIAL}
    if not levels:
        sys.exit("No level column found in the first row.")
    units = {}
    for n, r in enumerate(rows[1:], start=2):
        names = [r[i] if i < len(r) else "" for i, _ in levels]
        if not any(names):
            continue
        if "" in names[: max(k for k, v in enumerate(names) if v) + 1]:
            sys.exit(f"Row {n}: a level is empty above a filled one: {names}")
        deepest = max(k for k, v in enumerate(names) if v)
        for k in range(deepest + 1):
            units.setdefault((k, tuple(names[: k + 1])), {"name": names[k]})
        cell = lambda key: r[extra[key]] if key in extra and extra[key] < len(r) else ""  # noqa: E731
        info = units[(deepest, tuple(names[: deepest + 1]))]
        if cell("lat") and cell("lon"):
            try:
                info["lat"], info["lon"] = float(cell("lat").replace(",", ".")), float(cell("lon").replace(",", "."))
            except ValueError:
                sys.exit(f"Row {n}: latitude/longitude are not numbers: {cell('lat')!r}, {cell('lon')!r}")
            if not (-90 <= info["lat"] <= 90 and -180 <= info["lon"] <= 180):
                sys.exit(f"Row {n}: latitude/longitude out of range (swapped?): {info['lat']}, {info['lon']}")
        if cell("code"):
            info["code"] = cell("code")
    codes = {}
    for (k, names), info in units.items():
        if info.get("code"):
            codes.setdefault(info["code"], []).append(info["name"])
    twice = [f"code {c!r} used twice in the file: {n}" for c, n in codes.items() if len(n) > 1]
    if twice:
        sys.exit("Fix these codes in the file:\n  " + "\n  ".join(twice))
    return [name for _, name in levels], units


WGS84 = ('GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],'
         'PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]')


def write_gpkg(out, levels, units):
    """Writes the pyramid as a GeoPackage in the IASO import format (iaso/gpkg/README.md in the IASO
    repository): one layer "level-{depth}-{type}" per level with ref, name, parent_ref and code, points
    in WGS 84, and an empty "groups" table. Standard library only (sqlite3)."""
    import sqlite3
    import struct
    out = pathlib.Path(out)
    out.unlink(missing_ok=True)
    con = sqlite3.connect(out)
    con.execute("PRAGMA application_id = 1196444487")  # "GPKG"
    con.execute("PRAGMA user_version = 10200")
    con.executescript("""
        CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT NOT NULL, srs_id INTEGER PRIMARY KEY,
            organization TEXT NOT NULL, organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL,
            description TEXT);
        CREATE TABLE gpkg_contents (table_name TEXT NOT NULL PRIMARY KEY, data_type TEXT NOT NULL,
            identifier TEXT UNIQUE, description TEXT DEFAULT '',
            last_change DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE,
            srs_id INTEGER REFERENCES gpkg_spatial_ref_sys(srs_id));
        CREATE TABLE gpkg_geometry_columns (table_name TEXT NOT NULL, column_name TEXT NOT NULL,
            geometry_type_name TEXT NOT NULL, srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL,
            CONSTRAINT pk_geom_cols PRIMARY KEY (table_name, column_name));
        CREATE TABLE groups (fid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ref TEXT NOT NULL, name TEXT NOT NULL);
    """)
    con.executemany("INSERT INTO gpkg_spatial_ref_sys VALUES (?, ?, ?, ?, ?, ?)", [
        ("Undefined cartesian SRS", -1, "NONE", -1, "undefined", None),
        ("Undefined geographic SRS", 0, "NONE", 0, "undefined", None),
        ("WGS 84 geodetic", 4326, "EPSG", 4326, WGS84, "longitude/latitude coordinates in decimal degrees"),
    ])
    con.execute("INSERT INTO gpkg_contents (table_name, data_type, identifier) VALUES ('groups', 'attributes', 'groups')")
    ref = lambda names: "/".join(names)  # noqa: E731  stable across runs: re-importing updates, never duplicates
    for depth, level in enumerate(levels):
        table = f"level-{depth}-{level}"
        rows = [(names, info) for (k, names), info in sorted(units.items()) if k == depth]
        columns = "ref TEXT NOT NULL, name TEXT NOT NULL, code TEXT" + (", parent_ref TEXT NOT NULL" if depth else "")
        con.execute(f'CREATE TABLE "{table}" (fid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, geom POINT, {columns})')
        points = [(info["lon"], info["lat"]) for _, info in rows if "lat" in info]
        bbox = (min(p[0] for p in points), min(p[1] for p in points),
                max(p[0] for p in points), max(p[1] for p in points)) if points else (None,) * 4
        con.execute("INSERT INTO gpkg_contents VALUES (?, 'features', ?, '', strftime('%Y-%m-%dT%H:%M:%fZ','now'), "
                    "?, ?, ?, ?, 4326)", (table, table, *bbox))
        con.execute("INSERT INTO gpkg_geometry_columns VALUES (?, 'geom', 'POINT', 4326, 0, 0)", (table,))
        for names, info in rows:
            # GeoPackage binary header (little endian, no envelope, SRS 4326) + WKB point.
            geom = (struct.pack("<2sBBi", b"GP", 0, 1, 4326) + struct.pack("<BIdd", 1, 1, info["lon"], info["lat"])
                    if "lat" in info else None)
            values = [geom, ref(names), info["name"], info.get("code")] + ([ref(names[:-1])] if depth else [])
            con.execute(f'INSERT INTO "{table}" (geom, ref, name, code{", parent_ref" if depth else ""}) '
                        f'VALUES ({", ".join("?" * len(values))})', values)
    con.commit()
    con.close()


def read_gpkg(path):
    """Levels (layer names) and unit counts of a GeoPackage, checked against the IASO import format."""
    import sqlite3
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    tables = [r[0] for r in con.execute("SELECT table_name FROM gpkg_contents")]
    layers = sorted((t for t in tables if t.startswith("level-")), key=lambda t: int(t.split("-")[1]))
    problems = []
    if "groups" not in tables:
        problems.append('no "groups" table (required, even empty)')
    if not layers:
        problems.append('no layer named "level-{depth}-{type name}"')
    counts = {}
    for t in layers:
        cols = {r[1] for r in con.execute(f'PRAGMA table_info("{t}")')}
        for col in ("ref", "name"):
            if col not in cols:
                problems.append(f"layer {t}: no {col!r} column")
            else:
                empty = con.execute(f'SELECT count(*) FROM "{t}" WHERE trim(coalesce("{col}", \'\')) = \'\'').fetchone()[0]
                if empty:
                    problems.append(f"layer {t}: {empty} unit(s) with an empty {col!r}")
        if "parent_ref" in cols:
            # Empty (NULL or '') means a top unit; only spaces are refused by IASO.
            blank = f"parent_ref <> '' AND trim(parent_ref) = ''"
            empty = con.execute(f'SELECT count(*) FROM "{t}" WHERE {blank}').fetchone()[0]
            if empty:
                problems.append(f"layer {t}: {empty} unit(s) with a 'parent_ref' made of spaces (leave it empty for a top unit)")
        counts[t] = con.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0]
    con.close()
    if problems:
        sys.exit(f"{path} is not in the IASO GeoPackage format:\n  " + "\n  ".join(problems))
    return layers, counts


def default_version():
    """(data source, version number, org unit count) of the account's default source version: the pyramid
    that projects, users and phones use."""
    dv = (get("/api/profiles/me/").get("account") or {}).get("default_version")
    if not dv:
        sys.exit("The account has no default source version: ask an IASO administrator to set one.")
    source_id = dv["data_source"]["id"]
    source = next(s for s in results(get("/api/datasources/"), "sources") if s["id"] == source_id)
    count = next((v.get("org_units_count") for v in source.get("versions", []) if v["number"] == dv["number"]), None)
    return source, dv["number"], count


def wait_task(task, label):
    """Follows an IASO background task until it ends; exits if it fails."""
    import time
    last = None
    while task["status"] not in ("SUCCESS", "ERRORED", "KILLED", "SKIPPED"):
        time.sleep(3)
        task = get(f"/api/tasks/{task['id']}/")
        if task.get("progress_message") != last:
            last = task.get("progress_message")
            print(f"  {label}: {task['status'].lower()} {last or ''}")
    if task["status"] != "SUCCESS":
        sys.exit(f"{label} {task['status']}: {task.get('result')}")
    return task


def chain_types(level_names):
    """Sets each level type as the sub-type of the level above (the web uses it to create org units)."""
    types = {t["name"]: t for t in results(get("/api/v2/orgunittypes/?limit=500"), "orgUnitTypes")}
    ids = [types[n]["id"] for n in level_names if n in types]
    for parent, child in zip(ids, ids[1:]):
        current = get(f"/api/v2/orgunittypes/{parent}/")
        subs = sorted({s["id"] for s in current.get("sub_unit_types", [])} | {child})
        call("PATCH", f"/api/v2/orgunittypes/{parent}/", {"sub_unit_type_ids": subs})
    for n in level_names:
        if n in types:
            count = get(f"/api/orgunits/?orgUnitTypeId={types[n]['id']}&validation_status=all&limit=1&page=1")
            print(f"  type {n!r} (id {types[n]['id']}): {count.get('count')} org units")


def pyramid_import(path, apply=False):
    """Imports a pyramid into the account's default source version with the IASO GeoPackage import.

    An Excel/CSV file (see read_pyramid_table) is first converted to a GeoPackage written next to it;
    a GeoPackage in the IASO format (e.g. with boundaries) is imported as is. Without --apply nothing
    is sent. Units get stable references (their path of names): importing the same file again updates
    them instead of creating duplicates.
    """
    path = pathlib.Path(path)
    if path.suffix.lower() == ".gpkg":
        gpkg = path
        layers, counts = read_gpkg(gpkg)
        level_names = [t.split("-", 2)[2] for t in layers]
        print(f"{gpkg}: GeoPackage, {sum(counts.values())} org units")
        for t in layers:
            print(f"  {t}: {counts[t]} units")
    else:
        level_names, units = read_pyramid_table(path)
        gpkg = path.with_suffix(".gpkg")
        write_gpkg(gpkg, level_names, units)
        located = sum(1 for u in units.values() if "lat" in u)
        print(f"{path}: {len(units)} org units ({located} with GPS coordinates) -> {gpkg}")
        for k, name in enumerate(level_names):
            print(f"  level {k} {name!r}: {sum(1 for key in units if key[0] == k)} units")
    source, number, count = default_version()
    print(f"target: source {source['name']!r} (id {source['id']}), version {number} "
          f"(the account's default), {count} org units already")
    types = {t["name"] for t in results(get("/api/v2/orgunittypes/?limit=500"), "orgUnitTypes")}
    for name in level_names:
        print(f"  type {name!r}: {'exists' if name in types else 'will be created'}")
    if count:
        print("  The version already has org units. Units of this file with the same reference are updated; "
              "units created another way (web, mobile, old import) are not matched and would be duplicated if "
              "the file contains them too. Check the top of the pyramid in IASO before --apply.")
    if not apply:
        print("Dry run: nothing sent. Add --apply to import.")
        return
    r = post_multipart("/api/tasks/create/importgpkg/", {
        "data_source": source["id"], "version_number": number, "default_valid": "true",
        "description": f"campaign kit: {path.name}"}, "file", gpkg, "application/geopackage+sqlite3")
    wait_task(r["task"], "GeoPackage import")
    print("imported. Org unit types:")
    chain_types(level_names)


def pyramid_dhis2(apply=False):
    """Imports the DHIS2 org units into the account's default source version (IASO DHIS2 importer).

    The DHIS2 address, login and password are set by the user on the data source in the IASO web
    interface: this command never sees the password. In a version that already has org units, only
    the DHIS2 units it does not have yet (by DHIS2 id) are added.
    """
    source, number, count = default_version()
    creds = source.get("credentials") or {}
    if not creds.get("is_valid"):
        sys.exit(f"The data source {source['name']!r} has no DHIS2 credentials. In IASO, open Admin > Data Sources > "
                 "Data Sources list, edit this source (gear icon), fill in DHIS2 name, url, login and password, check "
                 "with 'Test settings', and save. Then run this again. The DHIS2 fields only show when the "
                 "account has the 'DHIS2 mapping' module.")
    print(f"DHIS2 {creds.get('url')} (login {creds.get('login')}) -> source {source['name']!r} "
          f"(id {source['id']}), version {number} (the account's default), {count} org units already")
    if count:
        print("  The version already has org units: only the DHIS2 org units missing from it are added, existing "
              "ones are not updated, and units created another way would stay next to their DHIS2 twin.")
    print("  All the DHIS2 org units are imported (every level); org unit types are named after the DHIS2 levels.")
    if not apply:
        print("Dry run: nothing sent. Add --apply to import.")
        return
    r = call("POST", "/api/dhis2ouimporter/", {"source_id": source["id"], "source_version_number": number,
                                               "validate_status": True, "description": "campaign kit: DHIS2"})
    wait_task(r["task"], "DHIS2 import")
    # The DHIS2 import names the types after the DHIS2 levels but does not chain them.
    project_ids = {p["id"] for group in source.get("projects", []) for p in (group if isinstance(group, list) else [group])}
    levels = sorted((t for t in results(get("/api/v2/orgunittypes/?limit=500"), "orgUnitTypes")
                     if t.get("depth") is not None and project_ids & {p["id"] for p in t.get("projects", [])}),
                    key=lambda t: t["depth"])
    print("imported. Org unit types (DHIS2 levels):")
    chain_types([t["name"] for t in levels])


PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=com.bluesquarehub.iaso"
QR_TEXT = {
    "en": {"title": "Set up the IASO app", "step1": "1. Install the IASO app",
           "step1n": "Scan with the phone camera, or search “IASO” by Bluesquare in the Play Store.",
           "step2": "2. Configure the app for a project",
           "step2n": "Open the app, choose “Scan a QR code” and scan the code of the project. "
                     "Then log in with the user's IASO username and password.",
           "manual": "Manual entry: server", "app_id": "app_id"},
    "fr": {"title": "Configurer l'application IASO", "step1": "1. Installer l'application IASO",
           "step1n": "Scannez avec l'appareil photo du téléphone, ou cherchez « IASO » (Bluesquare) dans le Play Store.",
           "step2": "2. Configurer l'application pour un projet",
           "step2n": "Ouvrez l'application, choisissez « Scanner un code QR » et scannez le code du projet. "
                     "Connectez-vous ensuite avec l'identifiant et le mot de passe IASO de l'utilisateur.",
           "manual": "Saisie manuelle : serveur", "app_id": "app_id"},
}


def qr_codes(project_ids, folder):
    """Writes the QR code images (Play Store + one per project) and qr_codes.html that shows them."""
    import base64
    import html
    import shutil
    out = pathlib.Path(folder)
    out.mkdir(parents=True, exist_ok=True)
    t = QR_TEXT[LANG]
    shutil.copy(CONFIG.parent / "assets" / "play_store_iaso_qr.png", out / "play_store_iaso_qr.png")
    projects = results(get("/api/projects/"), "projects")
    if project_ids:
        projects = [p for p in projects if str(p["id"]) in project_ids or p["app_id"] in project_ids]
    cards = []
    for p in projects:
        detail = get(f"/api/projects/{p['id']}/")
        data = detail.get("qr_code") or ""
        if "," not in data:
            print(f"project {p['id']}: no QR code returned")
            continue
        name = f"qr_{p['app_id']}.png"
        (out / name).write_bytes(base64.b64decode(data.split(",", 1)[1]))
        cards.append(f'<figure><img src="{name}" alt="{html.escape(p["app_id"])}"><figcaption><b>{html.escape(p["name"])}</b>'
                     f'<br>{t["app_id"]}: <code>{html.escape(p["app_id"])}</code></figcaption></figure>')
        print(f"project {p['id']} {p['name']}: {out / name}")
    page = f"""<!doctype html><html lang="{LANG}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{t['title']}</title>
<style>body{{font:15px/1.5 system-ui,sans-serif;margin:0;padding:16px;background:#fff;color:#1b1b19}}
h1{{font-size:20px}}h2{{font-size:16px;margin-top:24px}}.grid{{display:flex;flex-wrap:wrap;gap:16px}}
figure{{margin:0;border:1px solid #ddd;border-radius:8px;padding:8px;text-align:center;width:260px;max-width:100%}}
figcaption{{overflow-wrap:anywhere;font-size:13px}}
img{{width:240px;max-width:100%;height:auto;image-rendering:pixelated}}p{{max-width:640px;color:#444}}</style></head><body>
<h1>{t['title']}</h1>
<h2>{t['step1']}</h2><p>{t['step1n']}</p>
<div class="grid"><figure><img src="play_store_iaso_qr.png" alt="Play Store"><figcaption>
<a href="{PLAY_STORE_URL}">{PLAY_STORE_URL}</a></figcaption></figure></div>
<h2>{t['step2']}</h2><p>{t['step2n']}</p>
<div class="grid">{''.join(cards)}</div>
<p>{t['manual']} <code>{html.escape(BASE)}</code></p>
</body></html>"""
    (out / "qr_codes.html").write_text(page, encoding="utf-8")
    print(f"page: {out / 'qr_codes.html'}")


def main(argv):
    if not argv:
        sys.exit(__doc__)
    cmd, args = argv[0], argv[1:]
    if cmd == "whoami":
        me = get("/api/profiles/me/")
        account = me.get("account") or {}
        print(json.dumps({"server": BASE, "user": me.get("user_name"),
                          "account": {"id": account.get("id"), "name": account.get("name")},
                          "modules": account.get("modules"),
                          "permissions": sorted(me.get("permissions") or [])}, indent=1, ensure_ascii=False))
    elif cmd in ("get", "delete"):
        print(json.dumps(call(cmd.upper(), args[0]), indent=1, ensure_ascii=False))
    elif cmd in ("post", "patch", "put"):
        print(json.dumps(call(cmd.upper(), args[0], _payload(args[1] if len(args) > 1 else "{}")),
                         indent=1, ensure_ascii=False))
    elif cmd == "upload-form":
        r = upload_form_version(args[0], args[1])
        print(f"form {args[0]}: new version {r.get('version_id')} (id {r.get('id')})")
    elif cmd == "feature-flags":
        pid, add, remove, mode = args[0], [], [], None
        for a in args[1:]:
            if a in ("--add", "--remove"):
                mode = a
            elif mode == "--add":
                add.append(a)
            elif mode == "--remove":
                remove.append(a)
        feature_flags(pid, add, remove)
    elif cmd == "ou-types-add-project":
        ou_types_add_project(args[0], args[1:])
    elif cmd == "form-projects":
        fid, add, remove, mode = args[0], [], [], None
        for a in args[1:]:
            if a in ("--add", "--remove"):
                mode = a
            elif mode == "--add":
                add.append(a)
            elif mode == "--remove":
                remove.append(a)
        form_projects(fid, add, remove)
    elif cmd == "users-check":
        users_check()
    elif cmd == "entity-type-update":
        entity_type_update(args[0], _payload(args[1]))
    elif cmd == "pyramid-dhis2":
        pyramid_dhis2(apply="--apply" in args)
    elif cmd == "pyramid-import":
        pyramid_import(args[0], apply="--apply" in args)
    elif cmd == "qr-codes":
        folder = args[args.index("--out") + 1] if "--out" in args else "qr_codes"
        ids = [a for i, a in enumerate(args) if a != "--out" and (i == 0 or args[i - 1] != "--out")]
        qr_codes(ids, folder)
    elif cmd == "mobile-report-upload":
        opt = lambda flag: args[args.index(flag) + 1] if flag in args else None  # noqa: E731
        mobile_report_upload(args[0], args[1], name=opt("--name"), version=opt("--version"),
                             publish="--no-publish" not in args)
    elif cmd == "mobile-report-versions":
        mobile_report_versions(args[0])
    elif cmd == "mobile-report-publish":
        mobile_report_publish(args[0], args[1])
    elif cmd == "backup":
        backup(args[0] if args else "backups")
    else:
        sys.exit(f"unknown command {cmd}\n{__doc__}")


if __name__ == "__main__":
    main(sys.argv[1:])
