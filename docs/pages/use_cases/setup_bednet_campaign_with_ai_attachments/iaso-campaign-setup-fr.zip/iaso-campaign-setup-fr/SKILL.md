---
name: iaso-net-campaign-setup
description: Configurer une campagne complète de distribution de masse de moustiquaires imprégnées d'insecticide (MII) dans un compte IASO via l'API - projets mobiles, entités ménages et groupements spéciaux, workflows de dénombrement et de distribution, présence des travailleurs, formulaires de stock et de supervision, utilisateurs. À utiliser lorsque quelqu'un veut mettre en place, étendre ou auditer une telle campagne sur IASO.
---

# Configuration d'une campagne de distribution de MII dans IASO

Vous configurez un compte IASO pour une campagne de distribution de moustiquaires en porte-à-porte. La
personne avec qui vous travaillez a un compte IASO et a collé son jeton (token) d'API dans `iaso_config.txt`
(voir `README.md`, étape 1). Tout se fait via l'API IASO avec `scripts/iaso.py`.

Travaillez dans cet ordre. Chaque étape indique quoi demander, quoi créer et comment le vérifier.
Ne sautez jamais les vérifications : l'API accepte beaucoup de contenus qui cassent silencieusement l'application mobile.

Lisez `reference/pitfalls.md` avant l'étape 4, et gardez `reference/api.md` ouvert pour les contenus des requêtes.

## 0. Règles de base

- **N'utilisez aucun connecteur ni outil MCP IASO**, même s'il est disponible dans votre
  environnement (outils nommés par exemple `iaso_*`, `list_forms`, `get_org_unit`,
  `preview_create_pyramid`…) : il n'est pas encore prêt. Faites tout avec `scripts/iaso.py`.
- **Données de production.** Traitez le compte comme un compte de production. Avant la première écriture, lancez
  `python3 scripts/iaso.py backup backups/` et indiquez à l'utilisateur où se trouve la sauvegarde.
  Relancez-la avant tout changement risqué.
- **N'affichez jamais le jeton.** Ne le mettez jamais dans une URL, un fichier partagé ou un message du chat.
- **Lire, fusionner, écrire.** Plusieurs endpoints remplacent des listes en entier (feature flags du projet,
  projets d'un type d'unité d'organisation, listes de champs d'un type d'entité). Utilisez les commandes sûres de
  `scripts/iaso.py`, ou envoyez toujours la valeur actuelle complète plus votre modification.
- **Demandez confirmation avant toute action destructive ou irréversible** : suppression, retrait d'un formulaire
  d'un projet, modification d'un workflow publié, modification d'une question dans un formulaire déjà utilisé
  par les téléphones, création d'utilisateurs avec mot de passe.
- **Validez chaque XLSForm en local** avant de le téléverser (`scripts/validate_forms.sh`).
- **Rendez compte de ce que vous avez fait** après chaque étape : ids créés, ce que vous avez vérifié, ce qui reste à faire.
- **La configuration n'est pas terminée après les projets, formulaires et workflows.** Elle l'est
  quand tout ce qui a été décidé au § 2b est fait : QR codes montrés, pages web et rapports
  mobiles publiés, utilisateurs de test créés. Suivez la liste du § 12c avant d'annoncer la fin.

## 1. Serveur et accès

Demandez d'abord à l'utilisateur **quel serveur IASO il utilise** (l'adresse qu'il ouvre dans
son navigateur), en proposant par défaut **`https://demo.openiaso.com`**. Vérifiez que
`IASO_URL` dans `iaso_config.txt` est bien cette adresse ; sinon, demandez-lui de la corriger
(ou corrigez-la vous-même : ce n'est pas un secret). Ensuite :

```bash
python3 scripts/iaso.py whoami
```

- Si le jeton est signalé comme manquant ou si l'API répond 401, guidez l'utilisateur dans
  l'étape 1 du `README.md` : donnez-lui le lien `<IASO_URL>/login/?next=/api/apitoken/` construit avec
  son adresse IASO (par ex. `https://demo.openiaso.com/login/?next=/api/apitoken/`) ; après la
  connexion il affiche le jeton. Il copie la valeur de `token`, la coller après `IASO_TOKEN=` dans `iaso_config.txt`, enregistrer.
  Ne lui demandez pas de coller le jeton dans le chat.

- Le compte doit avoir ces quatre modules (`modules` dans la sortie) :
  `DATA_COLLECTION_FORMS`, `ENTITIES`, `STOCK_MANAGEMENT`, `EMBEDDED_LINKS`
  (dans l'écran IASO "Setup a new account" (création d'un compte) : *Data collection - Forms*, *Entities*,
  *Stock management*, *Embedded links* ; plus *DHIS2 mapping* pour importer la pyramide depuis
  DHIS2, § 3b). S'il en manque un, arrêtez-vous : un administrateur IASO
  doit l'ajouter au compte. Sans `STOCK_MANAGEMENT`, pas de stock dans l'application ;
  sans `EMBEDDED_LINKS`, pas de pages de rapport.
- L'utilisateur a besoin au minimum de ces permissions : `iaso_forms`, `iaso_projects`,
  `iaso_org_units`, `iaso_org_unit_types`, `iaso_entities`, `iaso_entity_type_write`, `iaso_workflows`,
  `iaso_users` (pour créer des utilisateurs), `iaso_stock_management` (stock), `iaso_sources` et
  `iaso_write_sources` (import de la pyramide, § 3b), `iaso_reports` (rapports mobiles), `iaso_page_write`
  (pages de rapport, nécessite le module de compte `EMBEDDED_LINKS`).
  Les permissions manquantes se traduisent par une erreur HTTP 403 : indiquez à l'utilisateur laquelle demander.

## 2. Recueillir les paramètres de la campagne

Copiez `templates/campaign.yaml` vers `campaign.yaml` et remplissez-le **avec l'utilisateur**, une
section à la fois. N'inventez aucune valeur. L'essentiel :

- Nom de la campagne, pays, langue(s) des formulaires, langue par défaut des libellés.
- **Périmètre** : les districts (ou régions) couverts, par leur nom ; vous les convertirez en ids d'unités d'organisation.
- **Niveaux de la pyramide** : quels types d'unités d'organisation existent (national → … → village) et à quel
  niveau les ménages sont enregistrés (en général la formation sanitaire ou le village).
- **Applications mobiles** : lesquels des six projets de la section 4 sont nécessaires, et leur `app_id`
  (en minuscules, séparé par des points, unique sur le serveur, ex. `xx.itn2027.enum`).
- **Règle d'allocation** : moustiquaires par ménage (par défaut ici : une moustiquaire par espace de couchage
  restant à couvrir, plafonnée au nombre de personnes).
- **Tickets / QR codes** : les ménages reçoivent-ils un ticket QR au dénombrement ? Les moustiquaires ou
  les ballots portent-ils un QR code ?
- **Groupements spéciaux** (prisons, camps, internats…) : enregistrés sur le terrain ou
  importés depuis un plan ?
- **Travailleurs et paiement** : rôles, taux journaliers, qui valide la présence.
- **Stock** : entrepôts, taille des ballots, mouvements suivis.
- **Utilisateurs** : qui utilise quelle application, à quelle unité d'organisation.

### 2b. Décisions à confirmer avant d'écrire dans IASO

Avant la sauvegarde et la première écriture, posez ces questions et notez les réponses dans la
section `deliverables` de `campaign.yaml`. Proposez les valeurs par défaut ci-dessous ; ne
supposez rien que l'utilisateur n'a pas confirmé.

1. **Rapports mobiles, par application** (un seul rapport par projet, § 12b). Par défaut :

   | Application | Rapport mobile | Carte |
   |---|---|---|
   | Dénombrement | Avancement de la campagne (`campaign_progress`) | oui, avec les noms des lieux |
   | Distribution | Avancement de la campagne (`campaign_progress`) | oui, avec les noms des lieux |
   | Groupements spéciaux | aucun (pas de flag `REPORTS`) | — |
   | Travailleurs et présence | Présence de l'équipe (`attendance`) | — |
   | Stock | Stock (`stock`) | — |
   | Supervision | aucun | — |

2. **La carte** dans les rapports d'avancement : la veut-il ? avec les noms des lieux ? avec le
   fond de carte de Bluesquare (`martin.bluesquare.org`, chargé quand le téléphone a du réseau ;
   styles `light`, `dark`, `white`, `grayscale`, `black`) ou sans fond (seulement les ménages
   et les noms, fonctionne toujours hors ligne) ? Voir « Cartes » dans
   `reference/mobile-reports.md`.
3. **Pages web** (§ 12) : lesquelles publier (tableau de bord de la campagne, présence et
   paiement, autres), et **qui peut ouvrir chacune** (utilisateurs nommés ou rôles IASO). La
   page de paiement affiche des numéros de téléphone et de pièce d'identité : seulement les
   personnes qui préparent les paiements.
4. **Utilisateurs de test** : en créer (un par application, ou un seul pour toutes) ? Les
   mots de passe IASO doivent respecter la politique du serveur (§ 9).
5. **QR codes** : ils sont générés et montrés dans la conversation dès que les projets
   existent (§ 4) ; demandez seulement s'il veut aussi la page imprimable pour la formation.

Récapitulez ces décisions à l'utilisateur et faites-les valider avant de commencer.

## 3. Cartographier le compte

```bash
python3 scripts/iaso.py get "/api/v2/orgunittypes/?limit=200"
python3 scripts/iaso.py get /api/projects/
python3 scripts/iaso.py get "/api/forms/?limit=500&fields=id,name,form_id,projects"
python3 scripts/iaso.py get /api/entitytypes/
```

- Notez les ids des types d'unités d'organisation par niveau, ainsi que les projets et formulaires existants. Réutilisez
  l'existant au lieu de créer des doublons ; demandez en cas de doute.
- Résolvez les districts du périmètre (mettez tout le chemin entre apostrophes simples) :
  `python3 scripts/iaso.py get '/api/orgunits/?searches=[{"search":"<name>","validation_status":"VALID","orgUnitTypeId":"<district type id>"}]&limit=20&page=1'`.
  Inscrivez les ids dans `campaign.yaml`.

### 3b. Unités d'organisation (pyramide sanitaire)

Les applications, les utilisateurs et les tableaux de bord dépendent tous de la pyramide :
réglez-la en premier. L'étape 3 montre si le compte en a déjà une (des types d'unités
d'organisation avec des unités). Demandez à l'utilisateur **d'où viennent ses unités
d'organisation**, en proposant :

1. **DHIS2**, si le pays a un DHIS2 avec sa pyramide sanitaire. IASO importe toutes ses
   unités, à tous les niveaux, avec leurs identifiants DHIS2, codes, coordonnées et contours.
2. **Un fichier Excel (ou CSV).** Donnez-lui le modèle `templates/pyramide_modele.xlsx` : une
   ligne par unité du niveau le plus bas, une colonne par niveau en partant du haut (par ex.
   Pays, Région, District, Formation sanitaire, Village ; il renomme les colonnes avec ses
   propres noms de niveaux, qui deviennent les types d'unités d'organisation), et les colonnes
   facultatives `latitude`, `longitude` (en degrés décimaux) et `code`. Un GeoPackage déjà au
   format IASO (par exemple avec des contours, exporté d'IASO ou préparé dans QGIS) est
   aussi accepté.
3. **Une pyramide de démonstration**, pour essayer la campagne sans données réelles :
   `templates/pyramide_demo.xlsx` (1 pays, 2 régions, 4 districts, 12 formations sanitaires,
   36 villages).
4. **Rien**, si le compte a déjà sa pyramide : il suffit alors de retrouver les districts du
   périmètre.

Les deux imports se font dans la **version de source par défaut du compte** : la pyramide
qu'utilisent les projets, les utilisateurs et les téléphones. Ce sont des tâches IASO en
arrière-plan ; les commandes les suivent jusqu'au bout. L'utilisateur de configuration a besoin
des permissions *Sources de données* (`iaso_sources`, et `iaso_write_sources` pour
enregistrer les identifiants DHIS2).

**Depuis DHIS2.** Le compte doit avoir le module **DHIS2 mapping** (un administrateur IASO
l'ajoute) : sans lui, IASO n'affiche aucun champ DHIS2. L'utilisateur saisit lui-même
l'adresse, le login et le mot de passe DHIS2 dans IASO, jamais dans le chat : *Admin >
Sources de données > Liste des sources de données*, modifier la source du compte (roue
dentée), remplir *Nom de la source DHIS2*, *Url DHIS2*, *Login DHIS2*, *Mot de passe DHIS2*,
cliquer sur *Vérifier la configuration*, sauver. IASO ne renvoie jamais le mot de passe : la
commande ne l'utilise qu'au travers d'IASO. Ensuite :

```bash
python3 scripts/iaso.py pyramid-dhis2            # simulation : adresse DHIS2, version cible, unités déjà présentes
python3 scripts/iaso.py pyramid-dhis2 --apply    # importe les unités de DHIS2
```

- Préférez un login DHIS2 en lecture seule. Les types d'unités portent le nom des niveaux
  DHIS2 ; dites à l'utilisateur lesquels la campagne utilisera (l'étape 4 les rattache aux
  applications).
- Dans une version qui a déjà des unités, seules les unités DHIS2 qu'elle n'a pas encore
  (par identifiant DHIS2) sont ajoutées ; des unités créées autrement resteraient à côté de
  leur jumelle DHIS2. Si le compte a déjà une pyramide qui ne vient pas de ce DHIS2,
  arrêtez-vous et demandez.

**Depuis Excel/CSV (ou un GeoPackage).**

```bash
python3 scripts/iaso.py pyramid-import <fichier.xlsx>            # simulation : unités par niveau, types ; écrit <fichier>.gpkg
python3 scripts/iaso.py pyramid-import <fichier.xlsx> --apply    # importe le GeoPackage dans IASO
```

- La commande convertit le fichier en GeoPackage au format d'import d'IASO (une couche
  `level-{profondeur}-{type}` par niveau, points en WGS 84) et l'importe avec l'import
  GeoPackage d'IASO. Montrez à l'utilisateur le résumé de la simulation et obtenez son accord
  avant `--apply` ; corrigez avec lui les problèmes signalés (niveaux vides, codes en double,
  coordonnées hors limites, souvent latitude et longitude inversées).
- Les types d'unités manquants sont créés et enchaînés (le sous-type de chaque type est le
  niveau suivant) ; les unités sont créées en `VALID`, avec leur code et leur point GPS.
- Chaque unité reçoit une référence stable (son chemin de noms) : réimporter le même
  fichier après une correction met à jour les unités au lieu de les dupliquer. Les unités
  créées autrement (web, mobile) ne sont pas reconnues : si la version a déjà des unités,
  vérifiez avec l'utilisateur que le fichier ne les contient pas aussi.
- Un GeoPackage fourni directement doit suivre le format IASO (`ref`, `name`, `parent_ref`
  et `code` facultatifs par couche, une table `groups`) ; la simulation le vérifie.

## 4. Projets (un par application mobile)

Un projet est ce que charge un téléphone : un `app_id`, une liste de formulaires et des feature flags. La
campagne standard en utilise jusqu'à six (voir `reference/architecture.md` pour le schéma) :

| Projet | Formulaires | Feature flags |
|---|---|---|
| Dénombrement | 01 enregistrement du ménage, 02 distribution de MII, 03 absent/refus, 04 revisite, 05 servi en routine | `REQUIRE_AUTHENTICATION`, `ENTITY`, `TAKE_GPS_ON_FORM`, `LIMIT_OU_DOWNLOAD_TO_ROOTS`, `MOBILE_SYNCHRONIZE_WITH_ZIP`, `SHOW_LINK_INSTANCE_REFERENCE`, `REPORTS` |
| Distribution | 01, 02, 06 enregistrement des groupements spéciaux, 07 distribution aux groupements spéciaux | comme Dénombrement **+ `MOBILE_ENTITY_NO_CREATION`**, et **sans** `MOBILE_ENTITY_LIMITED_SEARCH` |
| Groupements spéciaux | 06 enregistrement des groupements spéciaux, 07 | comme Dénombrement |
| Travailleurs et présence | 08 enregistrement des travailleurs, 09 présence journalière | `REQUIRE_AUTHENTICATION`, `ENTITY`, `TAKE_GPS_ON_FORM`, `MOBILE_ENTITY_WARN_WHEN_FOUND`, `MOBILE_FINALIZED_FORM_ARE_READ`, `REPORTS` |
| Stock | 10–14 formulaires de stock | `REQUIRE_AUTHENTICATION`, `ENTITY`, `MOBILE_ENTITY_NO_CREATION`, `MOBILE_STOCK`, `MOBILE_STOCK_HOME` (app ≥ 3.0.5), `TAKE_GPS_ON_FORM`, `REPORTS` |
| Supervision | 15 supervision | `REQUIRE_AUTHENTICATION`, `DATA_COLLECTION`, `TAKE_GPS_ON_FORM`, `MOBILE_SUBMISSION_INCOMPLETE_BY_DEFAULT` |

N'ajoutez `REPORTS` qu'aux projets qui auront un rapport mobile (§ 2b) : un projet sans
rapport n'a pas besoin de ce flag.

**Noms des projets : commencez par le mot qui change.** Sur les téléphones, les noms de projets
sont tronqués dans les listes après quelques caractères : « Campagne MII 2027 – Dénombrement »,
« Campagne MII 2027 – Distribution »… s'affichent tous « Campagne MII 20… » et les agents se trompent
d'application. Nommez-les « Dénombrement », « Distribution », « Stock »…, et mettez la campagne après
si besoin (« Dénombrement – campagne MII 2027 »). Même chose pour les `app_id`, lus par ceux qui
configurent les téléphones (`xx.denombrement.mii2027`, pas seulement la fin qui change).

Créez chaque projet (contenu de la requête dans `reference/api.md` § Projects), puis vérifiez-le avec
`get /api/projects/<id>/`. Par la suite, modifiez les feature flags uniquement avec
`scripts/iaso.py feature-flags <id> --add … --remove …`. Un flag que ce serveur n'a pas (par
exemple `MOBILE_STOCK_HOME`, absent de certains serveurs IASO) est ignoré avec un
avertissement : prévenez l'utilisateur, et retirez-le du contenu de création du projet.

Ensuite, rattachez les types d'unités d'organisation que chaque application doit télécharger :

```bash
python3 scripts/iaso.py ou-types-add-project <project_id> <type_id> <type_id> ...
```

- Donnez à chaque projet **chaque niveau** où ses formulaires sont remplis ou ses entités
  enregistrées, plus tous les niveaux au-dessus. Une entité enregistrée à un niveau que l'application ne
  télécharge pas bloque toute la synchronisation de cette application (`reference/pitfalls.md` #6).
- Les groupements spéciaux ont en général besoin de toute la pyramide jusqu'au village.

**Montrez les QR codes tout de suite.** Dès que les projets sont créés, générez les QR codes
(`python3 scripts/iaso.py qr-codes --out qr_codes`, § 10) et présentez-les dans la conversation,
sans attendre qu'on vous le demande : l'utilisateur peut alors installer l'application et
configurer un téléphone de test pendant que vous continuez.

## 5. Formulaires

1. Copiez les fichiers nécessaires de `forms/` dans un dossier de travail, et adaptez-les avec
   l'utilisateur : libellés dans la ou les langues de la campagne, chaque cellule marquée `ADAPT:` (format
   du téléphone, règle d'allocation, années, entrepôts, taille des ballots, rôles), listes de choix.
   Les formulaires ont des libellés en anglais et en français (colonnes `label::English (en)` et
   `label::French (fr)`) ; la langue est choisie dans l'application mobile.
   **Conservez les noms de champs** : les types d'entités, les workflows, les règles de stock et les tableaux de bord s'y réfèrent.
2. Validez : `scripts/validate_forms.sh <folder>`.
3. Créez chaque formulaire, puis téléversez son XLSForm (contenus des requêtes dans `reference/api.md` § Forms) :
   ```bash
   python3 scripts/iaso.py post /api/forms/ '{"name": "Household registration", "project_ids": [<enum>, <dist>], "org_unit_type_ids": [], "period_type": null, "single_per_period": false, "periods_before_allowed": 0, "periods_after_allowed": 0}'
   python3 scripts/iaso.py upload-form <form_id> forms/01_household_registration.xlsx
   ```
4. Placez chaque formulaire dans **chaque projet dont l'application en a besoin**. En particulier, le formulaire
   d'enregistrement du ménage (01) et celui des groupements spéciaux (06) doivent aussi être dans le projet
   Distribution : l'application ne télécharge que les entités dont le formulaire de référence est dans son
   projet (`MOBILE_ENTITY_NO_CREATION` empêche toujours d'y en créer). Modifiez les projets d'un
   formulaire existant avec `scripts/iaso.py form-projects <form_id> --add <project_id>`.
5. Vérifiez : `get /api/formversions/?form_id=<id>` affiche la nouvelle version.

## 6. Types d'entités

Cinq types d'entités, chacun avec son formulaire de référence (contenus des requêtes dans `reference/api.md`) :

| Type d'entité | Formulaire de référence | Champs de liste | Recherche de doublons | Bloquer si trouvé |
|---|---|---|---|---|
| Ménage | 01 | `head_name`, `id_number`, `head_age` | `qr_code` | oui |
| Ménage absent ou en refus | 03 | `household_code`, `status` | `household_code` | non |
| Ménage servi en routine | 05 | `head_name`, `id_number`, `head_age` | `head_name` | non |
| Groupement spécial | 06 | `group_name`, `group_type` | `group_name` | non |
| Travailleur | 08 | `full_name`, `role` | `id_number_clean` | non |

- Les champs de recherche de doublons sont ceux sur lesquels l'agent cherche avant de créer une entité.
  Pour les ménages, l'agent scanne le ticket QR : la valeur scannée remplit le champ en lecture seule
  `qr_code`, et "bloquer si trouvé" empêche d'enregistrer deux fois le même ticket.
- La recherche par nom ne doit **pas** bloquer (homonymes), elle affiche seulement les correspondances.
- Les champs de détail (`fields_detail_info_view`) sont ceux qu'affiche l'écran de l'entité : ajoutez les
  champs dont les agents ont besoin sur place (moustiquaires nécessaires, moustiquaires distribuées, date de distribution…).
- Par la suite, modifiez ces champs uniquement avec `scripts/iaso.py entity-type-update` (un PATCH
  partiel efface les autres listes de champs).

## 7. Workflows

Un workflow indique quels formulaires de suivi l'application propose sur une entité, et comment un formulaire de suivi
met à jour l'entité. Créez une version, ajoutez les suivis et les modifications, puis publiez
(contenus des requêtes dans `reference/api.md` § Workflows) :

| Type d'entité | Formulaire de suivi | Condition (JSONLogic sur les valeurs de l'entité) | Modifications (champ du formulaire → champ de l'entité) |
|---|---|---|---|
| Ménage | 02 distribution de MII | `{"and":[{"!=":[{"var":"nets_needed"},null]},{"==":[{"var":"nets_distributed"},"0"]}]}` | `nets_given → nets_distributed`, `distribution_date → distribution_date` |
| Ménage absent ou en refus | 04 revisite | `{"!=":[{"var":"status"},"enumerated"]}` | `status → status`, `ticket_number → enumeration_ticket` |
| Groupement spécial | 07 distribution au groupement | `{"or":[{"==":[{"var":"nets_distributed"},null]},{"==":[{"var":"nets_distributed"},""]},{"==":[{"var":"nets_distributed"},"0"]}]}` | `nets_given → nets_distributed` |
| Travailleur | 09 présence journalière | `true` | — |

- Les conditions font que chaque distribution n'a lieu **qu'une fois** : dès que `nets_distributed` est renseigné,
  le formulaire de suivi disparaît de l'application.
- Les formulaires de suivi reçoivent les valeurs de l'entité dont les noms correspondent à leurs propres champs : c'est
  ainsi que le formulaire de distribution obtient `head_name`, `nets_needed` ou `qr_code`.
- Seules les versions DRAFT (brouillon) sont modifiables. Pour modifier un workflow publié : copiez-le, modifiez la
  copie, publiez-la (la publication dépublie la version précédente).
- Vérifiez : `get "/api/mobile/workflows/?app_id=<app_id>"` liste les suivis publiés tels que
  le téléphone les verra.

## 8. Stock (s'il est suivi dans l'application)

1. Créez une unité de gestion de stock, ex. "Moustiquaires (pièces)", rattachée au projet Stock
   (et Dénombrement/Distribution si les distributions doivent diminuer le stock), aux types d'unités
   d'organisation où le stock est détenu, et aux formulaires de stock.
2. Créez une version de règles, ajoutez une règle par mouvement, publiez-la :

| Formulaire | Question | Impact |
|---|---|---|
| 10 réception de stock | `rec_total_nets` | `ADD` |
| 11 sortie de stock | `iss_total_nets` | `SUBTRACT` |
| 12 retour de stock | `ret_total_nets` | `ADD` |
| 13 transfert de stock | `tr_total_nets` | `SUBTRACT` |
| 14 perte de stock | `loss_pieces` | `SUBTRACT` |
| 02 distribution de MII (facultatif) | `nets_given` | `SUBTRACT` |

Ne comptez les distributions ici que si les sorties vers les équipes ne sont **pas** déjà soustraites :
sinon les mêmes moustiquaires sortent deux fois du stock.

## 9. Utilisateurs

- Un utilisateur par agent (pas de comptes partagés) : nom d'utilisateur, mot de passe, unités d'organisation (la zone où
  l'agent travaille ; l'application ne télécharge que ce sous-arbre), projets (les applications qu'il peut ouvrir),
  permissions.
- **Tout utilisateur d'un projet qui utilise des entités (feature flag `ENTITY`) doit avoir la
  permission `iaso_entities`** (« Entities » / « Entités » dans l'interface web) : Dénombrement,
  Distribution, Groupements spéciaux, Travailleurs et présences, et Stock dans ce guide. Sans elle,
  l'application ne peut ni télécharger ni afficher les ménages, groupements ou travailleurs. Les
  utilisateurs de la seule Supervision n'en ont pas besoin. Vérifiez-le après la création des
  utilisateurs avec `python3 scripts/iaso.py users-check` (la liste de `/api/profiles/` ne contient pas
  les permissions).
- Pour beaucoup d'utilisateurs, utilisez l'import CSV en masse de l'interface web IASO (Users → Import, soit Utilisateurs → Importer),
  que l'utilisateur peut faire lui-même (colonne `permissions` : `iaso_entities`) ; ou
  `POST /api/profiles/` un par un.
- Demandez confirmation à l'utilisateur avant de créer des comptes et des mots de passe, et ne mettez jamais de mots de passe
  dans le chat : écrivez-les dans un fichier local que l'utilisateur conserve.
- **Politique de mot de passe.** IASO refuse (HTTP 400, avec la raison) un mot de passe de moins
  de 8 caractères, trop courant (`test`, `password`, `12345678`…), uniquement numérique, ou trop
  proche du nom d'utilisateur. Générez des mots de passe aléatoires d'au moins 12 caractères,
  y compris pour les utilisateurs de test, et dites-le à l'utilisateur s'il propose le sien.

## 10. Téléphones

Aucun code ni build mobile n'est nécessaire : tout le monde utilise l'application générique **IASO** publiée par
Bluesquare sur le Play Store (`com.bluesquarehub.iaso`).

**Présentez les QR codes dans le chat.** Une fois les projets créés, lancez :

```bash
python3 scripts/iaso.py qr-codes --out qr_codes            # tous les projets, ou liste d'ids / d'app_id
```

La commande écrit `qr_codes/play_store_iaso_qr.png` (installe l'application IASO), un
`qr_codes/qr_<app_id>.png` par projet (configure l'application : serveur + `app_id`), et
`qr_codes/qr_codes.html`, une page qui les réunit avec les instructions. **Présentez ces
images directement à l'utilisateur dans la conversation** : joignez ou envoyez les fichiers PNG,
ou ouvrez la page HTML, selon ce que votre interface permet ; indiquez le nom de chaque projet
sous son QR code. Si les images ne peuvent pas être affichées, donnez le chemin de `qr_codes.html`.
L'utilisateur scanne d'abord le code du Play Store, puis celui du projet depuis l'écran d'accueil de l'application.

- Au premier lancement, l'application demande comment la configurer : **scanner le QR code du projet** (ceux
  ci-dessus ; aussi dans l'interface web, Admin → Projects), ou **saisie manuelle** de l'URL du serveur et de l'`app_id`.
  Connectez-vous ensuite avec les identifiants IASO de l'utilisateur.
- Un même téléphone peut passer d'un projet à l'autre en changeant l'`app_id` dans l'application : un seul
  téléphone de test peut essayer toutes les applications.
- Certains feature flags nécessitent une version récente de l'application. Vérifiez la version installée (paramètres
  de l'application / à propos) avant de compter sur eux :

| Fonctionnalité | Version minimale de l'application | Sans elle |
|---|---|---|
| `MOBILE_STOCK_HOME` (l'application s'ouvre sur l'écran de stock) | 3.0.5 | l'application s'ouvre sur l'écran d'accueil habituel |
| `_app_id` dans les conditions de workflow | 3.0.5 | une condition sur `_app_id` est fausse : le formulaire de suivi est masqué |

- Une application dédiée à l'image du programme (nom, icône et `app_id` intégré propres) est un build séparé de
  l'application mobile : demandez à Bluesquare.

## 11. Test complet et liste de vérification avant le lancement

Faites un test complet sur téléphone pour chaque application avant la formation, avec des utilisateurs de test
(téléphones configurés avec les QR codes du § 10) :

- [ ] Dénombrement : scanner un ticket, enregistrer un ménage, le rouvrir depuis la recherche.
- [ ] Scanner à nouveau le même ticket est bloqué.
- [ ] Ménage absent → revisite → dénombré ; il ne propose plus de revisite.
- [ ] Application Distribution : impossible de créer des ménages ; la recherche trouve le ménage ; scanner le
      ticket du ménage comme une moustiquaire est refusé ; après la distribution, le formulaire de suivi disparaît.
- [ ] Groupement spécial : enregistrer, distribuer une seule fois.
- [ ] Enregistrement d'un travailleur, présence validée.
- [ ] Stock : réception puis sortie ; l'écran de stock affiche le solde.
- [ ] Chaque téléphone se synchronise sans erreur (étape "Entities" (entités) comprise).
- [ ] Chaque application avec un rapport mobile l'ouvre (bouton Report) avec des chiffres
      justes ; la carte affiche les ménages et les noms des lieux, avec et sans réseau.
- [ ] **Avant le lancement, supprimez toutes les entités et soumissions de test** (elles compteraient dans les
      tableaux de bord et peuvent bloquer la synchronisation, voir pièges #6) ainsi que les utilisateurs de test.

## 12. Rapports (pages web IASO)

Suivez `reference/pages.md`. En résumé :

1. Copiez `templates/pages/campaign_dashboard.html`, réglez son `CONFIG` (ids des formulaires créés ci-dessus,
   titre, noms des types d'unités d'organisation pour le regroupement).
2. Prévisualisez-la avec les données réelles : `python3 scripts/serve_page.py <file>` → `http://localhost:8770/`.
   Vérifiez la console, comparez quelques totaux avec l'interface web.
3. Reprenez qui peut l'ouvrir (§ 2b) et faites-le confirmer au moment de publier : utilisateurs
   nommés (`users`) ou rôles (`user_roles`), voir `reference/pages.md`. Publiez-la avec
   `POST /api/pages/` (type `RAW`) et donnez l'URL `<IASO_URL>/pages/<slug>/`.

**Page de présence et de paiement** (modèle `templates/pages/attendance_payment.html`) :
calendrier travailleur × jour des journées déclarées et validées, montant dû par travailleur,
état de paiement Excel avec formules.

1. **Convenez d'abord des règles de paiement par écrit avec l'utilisateur** : tarif journalier
   par rôle, forfait payé une seule fois (par ex. le transport), nombre maximal de jours payés,
   barème des frais de mobile money, devise. Seules les journées validées par le superviseur sont payées.
2. Reportez-les dans le `CONFIG` de la page, avec les ids des formulaires 08 et 09 et les noms des
   types d'unités d'organisation (`levels`). Les codes de rôles doivent correspondre aux choix `role`
   du formulaire 08.
3. Prévisualisez avec les vraies données (`scripts/serve_page.py`), vérifiez à la main deux ou trois
   travailleurs par rapport aux soumissions de présence, puis publiez-la uniquement pour les personnes
   qui préparent les paiements (elle affiche les numéros de téléphone et de pièce d'identité).

Les autres pages utiles (groupements spéciaux, stock, supervision) suivent le même principe ;
`reference/pages.md` indique ce que chacune lit.

### 12b. Rapports mobiles (hors ligne, dans l'application)

Suivez `reference/mobile-reports.md`. Chaque projet reçoit **un** rapport, ouvert depuis le
bouton Report (Rapport) de l'application et calculé sur le téléphone, sans réseau. Publiez
ceux décidés au § 2b :

| Modèle | Applications | Montre |
|---|---|---|
| `templates/mobile_reports/campaign_progress/` | Dénombrement, Distribution | ménages dénombrés et servis, MII, absents/refus, par formation sanitaire ; carte des ménages avec les noms des lieux |
| `templates/mobile_reports/attendance/` | Travailleurs et présence | aujourd'hui : qui est validé, à valider, pas encore saisi ; sur la campagne : journées déclarées et validées par travailleur |
| `templates/mobile_reports/stock/` | Stock | solde, totaux par mouvement, derniers mouvements |

1. Copiez le dossier du modèle. Renseignez les `form_id` XLSForm dans sa configuration, et
   pour la carte les réglages `MAP` décidés (carte, noms des lieux, fond de carte). Adaptez les
   libellés et indicateurs avec l'utilisateur (ce que les chefs d'équipe doivent voir chaque soir).
2. Vérifiez-le dans un navigateur de bureau à la largeur d'un téléphone : sans l'application, il affiche des données de démonstration
   (`python3 -m http.server 8000 --directory <folder>`).
3. Empaquetez-le : `scripts/build_mobile_report.sh <folder> report.zip`.
4. Demandez l'accord de l'utilisateur, puis publiez-le :
   `python3 scripts/iaso.py mobile-report-upload <app_id> report.zip --name "<nom du rapport>" --version "<v1>"`.
   La commande crée le rapport du projet ou lui ajoute une version publiée. Ajoutez le
   feature flag `REPORTS` au projet et vérifiez `GET /api/mobile/reports/?app_id=<app_id>`.
   Si la commande indique que le serveur est trop ancien, suivez « Serveurs IASO plus
   anciens » dans `reference/mobile-reports.md` (admin Django, personnel de Bluesquare).
5. Testez sur un vrai téléphone après une synchronisation, en comparant les chiffres avec les
   soumissions listées dans l'application. Pour une carte : avec du réseau (fond de carte), puis
   en mode avion (les ménages et les noms des lieux doivent rester affichés).

### 12c. Fin de la configuration

N'annoncez pas que la configuration est terminée avant d'avoir coché, avec l'utilisateur, tout
ce qui a été décidé au § 2b :

- [ ] Projets, formulaires, types d'entités, workflows, stock créés et vérifiés.
- [ ] QR codes générés et montrés dans la conversation (§ 4, § 10).
- [ ] Pages web publiées, chacune pour les personnes convenues ; URL données.
- [ ] Rapports mobiles publiés pour chaque application convenue, flag `REPORTS` ajouté,
      `GET /api/mobile/reports/?app_id=…` vérifié ; carte et noms des lieux si demandés.
- [ ] Utilisateurs (et utilisateurs de test) créés, `users-check` sans problème, mots de
      passe dans un fichier local.
- [ ] Liste de vérification du § 11 donnée à l'utilisateur pour le test sur téléphone.

Terminez par un récapitulatif : ce qui a été créé (avec les ids), ce qui reste à faire, et
ce que l'utilisateur doit tester sur un téléphone.

## 13. Modifications en cours de campagne

La campagne évoluera pendant son déroulement. Avant chaque modification, relisez `reference/pitfalls.md` :
la bonne manière de modifier un formulaire déployé, un type d'entité ou un workflow est différente de
leur mise en place, et l'application mobile est beaucoup moins tolérante que l'API.
