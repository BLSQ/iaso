# Reports: web pages in IASO

IASO can host web pages for the campaign team: dashboards, attendance and payment
sheets, lists to print. A page is served at `<IASO_URL>/pages/<slug>/`, only to logged-in
users you choose, and reads the data with **their own IASO permissions**. A starting
dashboard is in `templates/pages/campaign_dashboard.html`.

## How a page works

- **Type `RAW`**: the page is one HTML file stored in IASO (`content`). Other types exist:
  `IFRAME` (embeds an external URL), `TEXT`, `POWERBI`, `SUPERSET`.
- **No token in the page.** It is served by IASO on the same domain as the API, so its
  `fetch('/api/...', {credentials: 'include'})` calls carry the session cookie of the
  logged-in user. Each viewer sees only the org units and forms they have access to.
- **Data source**: every form's submissions as a Parquet file,
  `GET /api/instances/?form_ids=<id>&parquet=true`. Columns:
  - one column per form field, by field name (groups are flattened: `people_count`, not
    `registration/people_count`); repeat groups are not expanded;
  - metadata prefixed with `iaso_subm_`: `iaso_subm_id`, `iaso_subm_org_unit_id`,
    `iaso_subm_org_unit_name`, `iaso_subm_entity_id`, `iaso_subm_created_by_username`,
    `iaso_subm_source_created_at`, `iaso_subm_latitude`, `iaso_subm_longitude`…
- **Pyramid**: `GET /api/orgunits/?parquet=true&order=id` with columns `org_unit_id`,
  `org_unit_name`, `org_unit_type_name`, `org_unit_parent_id`. Walk up the parents to group
  submissions by region, district or facility. Shapes for maps:
  add `extra_fields=simplified_geom_geojson` and filter by type with
  `searches=[{"orgUnitTypeId":"<id>"}]`.
- **Reading Parquet in the browser**: `hyparquet` and `hyparquet-compressors` from jsDelivr,
  as in the template (pin the versions).
- **Linking forms**: a distribution and the household it serves share
  `iaso_subm_entity_id`; follow-ups of a worker (attendance) share the worker's entity id.

## Maps

Pages about households show them on a map, as the campaign dashboard does (`CONFIG.map`): the
households come from the Parquet files (the geopoint question, e.g. `household_gps`, as
`"lat lon alt accuracy"`, else `iaso_subm_latitude` / `iaso_subm_longitude`), drawn with
MapLibre GL on the vector tiles of `https://martin.bluesquare.org/osm`, with a style built by
the page (`baseStyle()`, light or dark) and the place names of the chosen level drawn above
their households. See "Maps" in `reference/mobile-reports.md` for why martin's ready-made
styles are not used. Pages about workers or stock have no map.

## Build a page

1. Copy `templates/pages/campaign_dashboard.html` and set its `CONFIG` block: the form ids
   created during the setup, the title, the org unit type names to group by.
2. If you change the indicators, keep the field names of the forms (see `forms/README.md`).
   A field hidden with `relevant = false()` is not saved and will be empty here.
3. Check it, without a browser, before every publication:
   ```bash
   python3 scripts/serve_page.py --check my_dashboard.html
   ```
   It checks the JavaScript syntax (with `node`) and reads, with the token, every form of the
   page's `CONFIG.forms` and the pyramid. An editing slip (a table half deleted, a missing comma)
   leaves a page stuck on "Loading…": this check catches it.

   Where localhost can be opened (Claude Code, your own computer), also preview it with the real
   data: `python3 scripts/serve_page.py my_dashboard.html`, then open `http://localhost:8770/`
   and stop it with `python3 scripts/serve_page.py --stop`. Claude or ChatGPT in the browser
   cannot open localhost. The script serves the page and relays the API calls
   with the token of `iaso_config.txt`, so the page runs exactly as it will in IASO, and only reads.
   Check the browser console for errors, and compare a few totals with the IASO web
   interface (Forms → submissions).
4. Check light and dark mode, and a phone-width window: supervisors open it on phones.

## Publish

```bash
python3 scripts/iaso.py post /api/pages/ pages_payload.json
```

with `pages_payload.json`:

```json
{
  "name": "Campaign dashboard",
  "slug": "campaign-dashboard",
  "type": "RAW",
  "needs_authentication": true,
  "content": "<the whole HTML file as one JSON string>",
  "users": [<user ids allowed to open it>]
}
```

Building that JSON by hand is error-prone: let Claude read the HTML file and send it
(`json.dumps` of the file content).

- Who can open it: the users listed in `users` (**user ids**, `user_id` in
  `GET /api/profiles/`, not profile ids), the members of the roles listed in `user_roles`,
  and everyone in the account with the `iaso_page_write` permission. Others are sent to the
  login page.
- Publishing needs the `iaso_page_write` permission and the account module **Embedded links**
  (`EMBEDDED_LINKS` in `scripts/iaso.py whoami`).
- Update: read the page first (`GET /api/pages/<id>/`) and check `updated_at` and `content`
  did not change since you downloaded it — someone may have edited it in the web interface —
  then `PATCH /api/pages/<id>/ {"content": "..."}`. Keep the previous content as a backup file.
- The page appears in the web interface under **Pages** and at `<IASO_URL>/pages/<slug>/`.

## Typical campaign pages

| Page | Reads | Shows |
|---|---|---|
| Campaign dashboard (template provided) | 01, 02, 03, 05 | Enumeration and distribution progress by area, coverage, refusal rate |
| Special groups | 06, 07 | Groups planned / served, nets |
| Stock | 10–14 | Received, returned, issued, transferred, lost, balance by area; last movements (template `templates/pages/stock_by_region.html`) |
| Attendance and payment (template provided: `attendance_payment.html`) | 08, 09 | Days worked and validated per worker, amount due per role (rates, one-off allowances, mobile money fees), Excel export for payment |
| Supervision | 15 | Checklist results by area, corrective actions |

For payments, agree the rules in writing first (daily rate per role, allowances paid
once, maximum number of days, fees). In `attendance_payment.html` they all sit in the
`CONFIG` block at the top of the page, so finance can check them, and the Excel payment
sheet recomputes the amounts from its "Rates" and "Mobile money fees" sheets when
someone corrects a rate there. The one-off allowance is paid in the sheet whose period
contains the worker's first validated day, never twice.

## Reports in the mobile app

Reports that run offline on the phone (feature flag `REPORTS`) work differently: see
`reference/mobile-reports.md`.
