#!/usr/bin/env python3
"""Previews an IASO page locally, with the real data, before publishing it.

Usage: python3 scripts/serve_page.py templates/pages/campaign_dashboard.html [port]
Then open http://localhost:8770/

The page is served at / and every /api/ request is relayed to IASO_URL with the token
of iaso_config.txt added on the way. The browser never sees the token, and the page works exactly
as it will once served by IASO (same-origin calls to /api/...). Only GET is relayed:
a page under development cannot change anything in IASO.
"""

import http.server
import pathlib
import sys
import urllib.error
import urllib.request

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from iaso import BASE, TOKEN  # noqa: E402  (reads iaso_config.txt)

PAGE = pathlib.Path(sys.argv[1])
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8770


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/api/"):
            req = urllib.request.Request(BASE + self.path, headers={"Authorization": "Bearer " + TOKEN})
            try:
                with urllib.request.urlopen(req) as r:
                    body, status, ctype = r.read(), r.status, r.headers.get("Content-Type", "application/octet-stream")
            except urllib.error.HTTPError as e:
                body, status, ctype = e.read(), e.code, e.headers.get("Content-Type", "text/plain")
        elif self.path.split("?")[0] in ("/", "/index.html"):
            body, status, ctype = PAGE.read_bytes(), 200, "text/html; charset=utf-8"
        else:
            body, status, ctype = b"not found", 404, "text/plain"
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write(fmt % args + "\n")


print(f"Serving {PAGE} on http://localhost:{PORT}/ (API relayed to {BASE}, read-only)")
http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
